# Skills de Matt Pocock em português do Brasil para OpenClaw

Este pacote contém a tradução para português do Brasil das skills do repositório original:

<https://github.com/mattpocock/skills>

Foram incluídas 38 skills e os documentos Markdown de apoio. Os nomes das pastas, os identificadores das skills, comandos, caminhos, URLs, blocos de código e scripts foram preservados para evitar que a instalação quebre.

## Instalação no OpenClaw

Copie o conteúdo da pasta `skills` para o diretório de skills do seu agente ou workspace do OpenClaw. Exemplo:

```bash
mkdir -p ~/.openclaw/workspace/skills
cp -R skills/* ~/.openclaw/workspace/skills/
```

Em uma instalação com workspace diferente, use o caminho configurado para o agente. Depois, reinicie o OpenClaw ou recarregue as skills.

## Skills mais importantes

- `productivity/grill-me`: entrevista o usuário para esclarecer uma ideia ou plano.
- `engineering/grill-with-docs`: entrevista e registra decisões no modelo de domínio e nos ADRs.
- `engineering/tdd`: conduz desenvolvimento orientado por testes.
- `engineering/diagnosing-bugs`: organiza o diagnóstico de bugs em etapas verificáveis.
- `engineering/code-review`: revisa o código contra padrões e especificações.
- `engineering/research`: pesquisa fontes confiáveis e registra as descobertas.

As skills que ainda estão em desenvolvimento foram mantidas dentro de `in-progress`, como no repositório original.

## Observação

Algumas skills foram criadas originalmente para o Claude Code e podem mencionar recursos específicos dele, como subagentes, issue trackers ou a ferramenta Skill. A tradução preserva a intenção, mas essas partes podem exigir adaptação caso o OpenClaw tenha nomes ou capacidades diferentes.
