# Obsoleto

Habilidades que não uso mais. Este bucket está vazio no momento: uma habilidade descontinuada é excluída e o conjunto de alterações que a remove nomeia tudo o que a substituiu.