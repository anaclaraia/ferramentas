---
name: wait-what
description: "Pare. Essa última mensagem não chegou: lance-a novamente."
disable-model-invocation: true
---

Espere, não entendo onde você chegou aqui. Repita isso: dê-me um pouco de contexto, fale em inglês técnico simplificado ASD-STE100 e use a linguagem onipresente de `CONTEXT.md` (siga `CONTEXT-MAP.md` para a direita se o repo tiver mais de um).