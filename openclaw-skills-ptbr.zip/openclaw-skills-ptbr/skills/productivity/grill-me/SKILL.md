---
name: grill-me
description: Uma entrevista incansável para aprimorar um plano ou projeto.
disable-model-invocation: true
---

Ative a skill de "grilling".