# Mecânica de habilidades

O ramo específico da habilidade de [`writing-for-agents`](SKILL.md): o que muda quando o documento é uma habilidade (frontmatter, a escolha de invocação e habilidades do roteador). Todo o resto sobre escrevê-lo é a referência universal em `SKILL.md`.

## Invocação

Duas escolhas, negociando as duas cargas:

- Uma habilidade **invocada por modelo** mantém um `description`, para que o agente possa dispará-lo de forma autônoma e outras habilidades possam alcançá-lo. Você ainda pode digitar seu nome: model-invocation sempre _inclui_ o alcance do usuário; uma descrição apenas acrescenta a descoberta do agente, nunca remove a do humano. A descrição é o ponteiro de contexto de nível superior da habilidade, forçado a permanecer carregado o tempo todo: carga de contexto permanente em troca de capacidade de descoberta. Uma habilidade invocada por modelo cujo conteúdo é todo referência também é um local para referência compartilhada: outra habilidade pode invocá-la, portanto, a referência necessária para várias habilidades fica em um só lugar. Mecânica: omita `disable-model-invocation` e escreva uma descrição voltada para o modelo carregando as ramificações do gatilho (as regras de escrita de ponteiro em `SKILL.md` se aplicam integralmente).
- Uma habilidade **invocada pelo usuário** tira a descrição do alcance do agente: somente o humano que digita seu nome pode invocá-la, e nenhuma outra habilidade pode. Carga de contexto zero, mas gasta carga cognitiva: você é o índice que deve lembrar que ele existe. Mecânica: conjunto `disable-model-invocation: true`; o `description` torna-se voltado para o ser humano: um resumo de uma linha, listas de gatilhos removidas.

Escolha invocação de modelo somente quando o agente precisar alcançar a habilidade por conta própria ou outra habilidade precisar. Se ele for acionado manualmente, torne-o invocado pelo usuário e não pague nenhuma carga de contexto.

A referência compartilhada de que duas habilidades invocadas pelo usuário precisam não pode existir em nenhuma delas: sem descrições, nenhuma delas pode disparar a outra. Envie-o para um arquivo simples fora do sistema de habilidades: referência externa para a qual qualquer habilidade pode apontar.

## Divisão por invocação

O corte de invocação de divisão (o corte de sequência reside em `SKILL.md`): divida uma habilidade invocada por modelo quando você tem uma palavra inicial distinta que deve ativá-la por conta própria (uma palavra acionadora que você realmente usa em seus prompts) ou outra habilidade deve alcançá-la. Você paga a carga de contexto pela nova descrição sempre carregada, de modo que o alcance independente vale a pena.

## Habilidades de roteador

Quando as habilidades invocadas pelo usuário se multiplicam além do que você consegue lembrar, essa carga cognitiva acumulada é curada por uma **habilidade de roteador**: uma habilidade invocada pelo usuário que nomeia as outras e quando recorrer a cada uma, de modo que o humano tenha uma habilidade para lembrar em vez de muitas. Ele só pode sugerir, nunca dispará-los: as habilidades invocadas pelo usuário não têm descrição, então nada além do humano pode alcançá-las.