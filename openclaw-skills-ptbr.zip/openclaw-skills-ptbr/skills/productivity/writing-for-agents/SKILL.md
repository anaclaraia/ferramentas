---
name: writing-for-agents
description: Redação de documentos para agentes. Use ao criar ou editar habilidades ou modificar AGENTS.md ou CLAUDE.md.
---

Referência para escrever qualquer documento que um agente consuma: uma habilidade, um `AGENTS.md` / `CLAUDE.md`, um documento alcançado por um ponteiro. A embalagem é diferente; a escrita não: as mesmas alavancas tornam cada uma delas previsível, uma vez que o agente executa o mesmo _processo_ em cada execução, em vez de produzir a mesma saída.

Quando o documento que você está escrevendo for uma habilidade, leia [`SKILL-MECHANICS.md`](SKILL-MECHANICS.md) para frontmatter, escolha de invocação e habilidades de roteador.

## Ponteiros de contexto

Um **ponteiro de contexto** é uma referência mantida no contexto do agente que nomeia algum material fora de contexto e codifica a condição para alcançá-lo. A descrição de uma habilidade é uma delas; uma linha em `AGENTS.md` nomeando um documento é o mesmo objeto. O _texto_ do ponteiro, e não o seu alvo, decide quando o agente alcança o material e com que confiabilidade. Um alvo obrigatório por trás de um ponteiro com palavras fracas é um bug de variação: aprimore o texto primeiro e incorpore o material somente se a nitidez falhar.

Um ponteiro faz duas tarefas: indicar qual é o material e listar as **ramificações** que devem acionar o acesso a ele (uma ramificação é um caso distinto que o documento trata, portanto, execuções diferentes seguem caminhos diferentes através dele). Cada palavra de um ponteiro sempre carregado custa a cada turno, por isso ganha uma poda ainda mais difícil do que o corpo:

- **Carregue a palavra inicial**: o ponteiro é onde ele faz seu trabalho de acionamento.
- **Um gatilho por ramificação.** Sinônimos que renomeiam uma única ramificação são uma ramificação escrita duas vezes; desmoroná-los e manter apenas ramos genuinamente distintos.
- **Corte a identidade que o corpo já carrega.**

## As duas cargas

Cada documento e ponteiro adicionado gasta um de dois orçamentos:

- **Carga de contexto** é o custo do material sempre carregado na janela do agente: uma linha `AGENTS.md`, uma descrição de habilidade, qualquer coisa que esteja no contexto a cada turno, gastando tokens e atenção, independentemente de ser acionado ou não.
- **Carga cognitiva** é o custo para o ser humano: quais documentos existem e quando recorrer a cada um. O humano é o índice. Não é um custo a minimizar: é o preço da agência humana; gaste-o onde o julgamento humano é importante, remova-o onde não importa.

O material alcançado apenas através de um ponteiro escapa da carga de contexto ao preço da própria linha do ponteiro; o material sem nenhum ponteiro depende inteiramente da carga cognitiva.

## Hierarquia de informações

Um documento é construído a partir de dois tipos de conteúdo: **etapas** (as ações ordenadas que o agente executa) e **referência** (definições, regras, fatos consultados sob demanda). Os dois se misturam livremente: todas as etapas (uma receita), todas as referências (as regras de uma revisão, esta habilidade) ou ambas. A decisão central é onde cada peça se situa na **hierarquia de informações**, uma escada classificada de acordo com a rapidez com que o agente precisa do material:

1. **Etapa no arquivo** é a camada principal: o que o agente faz, em ordem.
2. **Referência no arquivo** é consultada sob demanda. Freqüentemente, um conjunto de pares legitimamente plano (cada regra de uma revisão em um degrau), que é um bom arranjo, não um cheiro.
3. **Referência divulgada** é enviada para um arquivo separado, alcançado por um ponteiro de contexto, carregado somente quando o ponteiro é acionado. Abrange um arquivo irmão na mesma pasta por meio de referência totalmente externa que fica em qualquer lugar e para a qual qualquer documento pode apontar.

Empurre muito pouco para baixo e a parte superior incha; empurre demais e você esconderá o material que o agente realmente precisa. Essa tensão é toda a decisão.

**Divulgação progressiva** é o movimento descendente da escada (fora do arquivo principal e atrás de um ponteiro) para que o topo permaneça legível. Não é principalmente uma otimização de token: é como a hierarquia é protegida. A ramificação é o teste de divulgação mais limpo: insere o que cada filial precisa e coloca atrás de um ponteiro o que apenas algumas filiais alcançam. Quando um documento tem etapas, a referência no arquivo que deveria ser divulgada as enterra e transforma o atendimento a elas em um lançamento de moeda: uma alavanca de variação, não apenas uma alavanca de legibilidade.

**Co-localização** é o companheiro dentro do arquivo: onde a escada decide _a que distância_ uma peça fica, a co-localização decide _o que fica ao lado dela_ uma vez lá. Mantenha a definição, as regras e as advertências de um conceito em um único título, em vez de espalhadas, para que a leitura de uma parte traga consigo as vizinhas. O teste: o documento deve ser semelhante à documentação escrita para o agente. O material agrupado é lido dessa forma; o material espalhado não. (Distinto de duplicação: que repete um significado em dois lugares; espalha fragmentos de um significado em muitos.)

**Sprawl** é o modo de falha aqui: um documento simplesmente muito longo, mesmo quando cada linha é ativa e única. A atenção diminui no excesso, e cada linha extra é mais uma para se manter relevante. A cura é a escada: divulgue a referência por trás dos ponteiros e divida por ramificação ou sequência para que cada caminho carregue apenas o que precisa.

## Etapas e critérios de conclusão

Cada etapa termina com um **critério de conclusão**, a condição que informa ao agente que o trabalho foi concluído. Duas propriedades fazem dela uma alavanca:

- **Clareza**: o agente consegue distinguir o que foi feito do que não foi feito? Um limite vago (“compreensão alcançada”) convida à **conclusão prematura**: encerrar a etapa antes que ela seja genuinamente concluída, a atenção voltando-se para _estar concluída_. As etapas visíveis que ainda estão por vir (as **etapas pós-conclusão**) fornecem a atração; a clareza do critério é a resistência. Defenda na ordem: **afie o limite primeiro** (local e barato); somente se estiver irredutivelmente confuso _e_ você observar a pressa, oculte as etapas posteriores dividindo a sequência. A ocultação só funciona através de um limite de contexto real (uma transferência ou despacho de subagente; uma chamada in-line deixa as etapas posteriores no contexto e não limpa nada).
- **Demanda**: quanto é necessário. "Cada modelo modificado contabilizado" força um trabalho completo, onde "produzir uma lista de alterações" não. A demanda impulsiona o **trabalho braçal** (a escavação que o agente faz dentro do trabalho, latente no texto, em vez de escrita como sua própria etapa), e não é limitada por etapas: "cada regra aplicada" vincula um corpo de referência plana, assim como "cada etapa realizada" vincula uma sequência, que é como um documento com todas as referências ainda carrega uma barra de exaustividade.

Os critérios mais fortes são verificáveis ​​e exaustivos.

## Quando dividir

Dividir um documento em dois gasta uma das duas cargas, então divida apenas quando o corte valer a pena:

- **Por sequência**: divida uma série de etapas em que as etapas pós-conclusão tentam o agente a apressar a que está à sua frente. Mantê-los fora da vista gera mais trabalho braçal na tarefa atual. Cuidado com o inverso: a fusão de sequências expõe as etapas posteriores de cada etapa às seguintes, convidando à conclusão prematura.
- **Por invocação**, específico da habilidade: consulte [`SKILL-MECHANICS.md`](SKILL-MECHANICS.md).

## Palavras principais

Uma **palavra principal** é um conceito compacto que já existe no pré-treinamento do modelo com o qual o agente pensa enquanto executa o documento (_lição_, _névoa de guerra_, _balas traçadoras_). Repetido como um token, nunca como uma frase, ele acumula uma definição distribuída e ancora toda uma região de comportamento no menor número de tokens, recrutando anteriores que o modelo já possui. Cunhar seus próprios trabalhos se você os definir claramente, mas uma palavra inventada não recruta antecedentes: você paga em fichas de definição o que uma palavra pré-treinada dá de graça; procure primeiro uma palavra existente.

Ele ancora duas vezes. No corpo, _execução_: o agente busca o mesmo comportamento toda vez que a palavra aparece, e dentro da referência plana ele concentra a atenção em uma classe de coisa a ser procurada. Em um ponteiro, _invocação_: quando a mesma palavra reside em seus prompts, seus documentos e sua base de código, o agente vincula essa linguagem compartilhada ao material e o alcança de maneira mais confiável.

Procure oportunidades de refatorar com palavras importantes. Uma tríade explicada em três locais, um ponteiro gastando uma frase para indicar uma ideia. Cada uma é uma passagem implorando para se transformar em um único símbolo:

- "rápido, determinístico, de baixa sobrecarga" → _tight_ (um loop _tight_).
- "um loop em que você acredita" → _vermelho_, transformando uma porta difusa em um estado binário observável (o loop fica _vermelho_ no bug, ou não).

Você ganha duas vezes: menos fichas e um gancho mais preciso para o agente se concentrar. Suponha que cada documento contenha reformulações de que as palavras iniciais são retiradas. Vá encontrá-los.

**Negação** é o modo de falha ao lado desta alavanca: direcionar pela proibição arrasta o comportamento proibido para o contexto e o torna _mais_ disponível, e não menos. _Não pense em um elefante_, e o elefante é tudo que existe; a negação é um modificador fraco que ultrapassa o conceito fortemente ativado, então a proibição é interpretada pela metade como uma instrução para fazer a coisa. Avise o **positivo**: indique o comportamento alvo ("escreva comentários de uma linha") para que o comportamento banido nunca seja falado. Uma proibição só ganha seu lugar como uma barreira de proteção rígida que você não pode expressar de forma positiva; mesmo assim, combine-o com o alvo positivo para que a atenção se concentre no que fazer.

## Poda

- Mantenha cada significado em uma **única fonte de verdade**: um local de autoridade, portanto, mudar o comportamento é uma edição em um só lugar. **Duplicação** (o mesmo significado em mais de um lugar) custa manutenção e tokens, e aumenta a proeminência de um significado na escada além de sua classificação real. (O inverso acidental de uma palavra inicial, que repete um símbolo propositalmente, nunca o significado.)
- O **ambiente** também é uma fonte de verdade (scripts `package.json`, arquivos de configuração, o layout do diretório, saída `--help`) e um documento que reafirma que é um **cache**: uma cópia de uma pesquisa, ganhando sua carga apenas quando a pesquisa é cara. Armazene em cache o que o agente não consegue encontrar olhando: a convenção não escrita, a razão por trás de uma escolha, a pegadinha que nenhuma configuração confessa. Deixe as pesquisas de um arquivo e um comando para o ambiente, onde elas não podem ficar obsoletas.
- Verifique a **relevância** de cada linha: ela ainda tem relação com o que o documento faz? Uma linha perde relevância por nunca se relacionar com a tarefa (mera exposição, ou um ramo que deveria ser divulgado) ou por ficar obsoleta à medida que o comportamento ou o mundo que ela descreve muda. Documentos mais curtos são mais fáceis de manter relevantes. Sem uma disciplina de poda, o destino padrão é **sedimento**: camadas obsoletas que se assentam porque adicionar parece seguro e remover parece arriscado, até que você precise percorrê-las para encontrar o que ainda está vivo.
- Hunt **no-ops** frase por frase: uma instrução que o modelo já obedece por padrão paga carga para não dizer nada. O teste (ele muda o comportamento em relação ao padrão?) É relativo ao modelo, não ao leitor: duas pessoas que discordam sobre um ambiente autônomo discordam sobre o padrão e resolvem o problema executando o documento, não por meio de debate. Quando uma frase falhar, exclua a frase inteira em vez de cortar palavras dela. O teste também avalia palavras principais: uma palavra muito fraca para superar o padrão (_ser completo_ quando o agente já é completo) é um ambiente autônomo, e a correção é uma palavra mais forte (_implacável_), não uma técnica diferente.