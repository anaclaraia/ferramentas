# Produtividade

Ferramentas gerais de fluxo de trabalho, não específicas de código.

## Invocado pelo usuário

Acessível apenas quando você os digita (Código Claude: `disable-model-invocation: true`; Codex: `policy.allow_implicit_invocation: false` em `agents/openai.yaml`).

- **[grill-me](./grill-me/SKILL.md)**: Seja entrevistado incansavelmente sobre um plano ou projeto até que cada ramo da árvore de projeto seja resolvido.
- **[handoff](./handoff/SKILL.md)**: Compacte a conversa atual em um documento de transferência para que outro agente possa continuar o trabalho.
- **[teach](./teach/SKILL.md)**: Ensine ao usuário uma nova habilidade ou conceito em várias sessões, usando o diretório atual como um espaço de trabalho de ensino com estado.
- **[to-questionnaire](./to-questionnaire/SKILL.md)**: Transforme uma decisão que você não pode responder sozinho em um questionário Markdown para a única pessoa que pode (preenchido de forma assíncrona ou em conjunto durante uma reunião).
- **[wait-what](./wait-what/SKILL.md)**: Dispara no momento em que uma mensagem não chega. O agente apresenta novamente o contexto que está faltando, em inglês simples, usando seu vocabulário `CONTEXT.md`.

## Invocado por modelo

Acessível pelo modelo ou pelo usuário (frases de gatilho ricas para que o modelo possa alcançá-los).

- **[grilling](./grilling/SKILL.md)**: Entreviste o usuário incansavelmente sobre um plano, decisão ou ideia até que cada ramo da árvore de design seja resolvido.
- **[writing-for-agents](./writing-for-agents/SKILL.md)**: Escrever documentos para agentes: habilidades, AGENTS.md/CLAUDE.md e qualquer documento que um agente alcance por meio de um ponteiro.