---
name: to-questionnaire
description: Transforme uma decisão que você não consegue responder completamente em um questionário para outra pessoa preencher.
disable-model-invocation: true
---

Transforme algo que o usuário não consegue responder sozinho em um **questionário**: um documento Markdown que ele entrega a uma pessoa para preencher de forma assíncrona ou preencher juntos durante uma reunião. O destinatário detém o conhecimento que falta ao usuário; o questionário tira isso deles.

**Pergunte o envio, não o assunto.** Entreviste o usuário apenas sobre o _envio_, que ele sempre poderá responder: para quem vai e o que ele precisa de volta. As perguntas no documento visam a **lacuna** entre o que o destinatário sabe e o que o usuário precisa.


1. **Para quem vai?** Pergunte, em uma troca, a função, a experiência e o relacionamento do destinatário com o usuário. Isso fixa o tom do questionário e quanto contexto ele deve conter. Feito quando você sabe quem é o destinatário e o que ele sabe que o usuário não sabe.

2. **O que você precisa de volta?** Pergunte, em uma única troca, as decisões ou fatos específicos que o usuário não consegue resolver sozinho e precisa dessa pessoa. Feito quando você tem uma lista concreta do que o usuário deve poder fazer ou decidir.

3. **Escreva o questionário.** Rascunhe as perguntas voltadas para a lacuna das etapas 1 a 2, seguindo a estrutura do documento abaixo. Escreva em `to-questionnaire-<slug>.md` no diretório atual (slug do tópico) e informe o caminho. Feito quando o arquivo existe e cada item nomeado pelo usuário na etapa 2 é coberto por uma pergunta.

## Estrutura do documento

Enquadre o documento como um **questionário de descoberta**: o usuário não tem contexto, o destinatário o detém. Ordene as perguntas mais importantes primeiro, já que assíncronas significam que você só pode obter uma passagem e agrupe-as nos títulos `##` por tema, quando houver mais de um punhado. Escreva usando o modelo abaixo.

<modelo de questionário>

# <Título do questionário>

**Objetivo:** por que este questionário existe e a decisão que depende dele.

**De:** <o usuário>, **Para:** <o destinatário>, **Como suas respostas serão usadas:** <para onde elas vão>

## Contexto

Um parágrafo orientando um destinatário que não estava na cabeça do usuário. O suficiente para responder bem, não uma página.

## Como responder

Prazo e esforço difícil. Respostas parciais e "Não sei" são úteis: sinalize qualquer coisa sobre a qual você não tenha certeza, em vez de ignorá-la.

## <Título do tema>

Uma seção `##` por tema. Abaixo de cada uma, suas perguntas, as mais importantes primeiro. Cada pergunta é uma ideia, nunca composta, com um esboço de resposta logo abaixo e uma linha _por que isso é importante_ somente quando a pergunta puder ser mal interpretada ou convidar a uma resposta descartável.

<pergunta-exemplo>
### Qual carga o sistema deverá suportar no lançamento?

_Por que isso é importante: ele decide se provisionamos o tráfego intermitente agora ou adiamos._

>
</question-exemplo>

## Mais alguma coisa?

Um resumo final: alguma coisa que não perguntamos e que deveríamos saber?

</questionário-modelo>