---
name: handoff
description: Compacte a conversa atual em um documento de transferência para outro agente atender.
argument-hint: "Para que será usada a próxima sessão?"
disable-model-invocation: true
---

Escreva um documento de transferência resumindo a conversa atual para que um novo agente possa continuar o trabalho. Salve no diretório temporário do sistema operacional do usuário - não no espaço de trabalho atual.

Inclua uma seção de “habilidades sugeridas” no documento, nomeando quais habilidades o próximo agente deve chamar a habilidades.

Não duplique conteúdo já capturado em outros artefatos (especificações, planos, ADRs, problemas, commits, diffs). Referencie-os por caminho ou URL.

Edite quaisquer informações confidenciais, como chaves de API, senhas ou informações de identificação pessoal.

Se o usuário passou argumentos, trate-os como uma descrição do foco da próxima sessão e adapte o documento de acordo.