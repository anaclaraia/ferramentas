# GLOSSÁRIO.md Formato

`GLOSSARY.md` é a linguagem canônica para este espaço de trabalho de ensino. Todos os explicadores, exercícios e registros de aprendizagem devem aderir à sua terminologia. Construí-lo faz parte do aprendizado: comprimir um conceito em uma definição precisa é uma prova de que o usuário o compreende.

## Estrutura

```md
# {Topic} Glossary

{One or two sentence description of the topic this glossary covers.}

## Terms

**Hypertrophy**:
Muscle growth driven by mechanical tension and metabolic stress over repeated training sessions.
_Avoid_: Bulking, getting big

**Progressive overload**:
Systematically increasing the demand on a muscle over time, via load, volume, or intensity.
_Avoid_: Pushing harder, levelling up

**RPE (Rate of Perceived Exertion)**:
A 1–10 self-rating of how hard a set felt, where 10 is failure and 8 means two reps left in the tank.
_Avoid_: Effort score, intensity rating
```

## Regras

- **Adicione um termo somente quando o usuário o compreender.** O glossário é um registro de conhecimento compactado, não um dicionário que o usuário lê para aprender. Se o usuário acabou de conhecer um conceito, espere até que ele possa usá-lo corretamente antes de promovê-lo aqui.
- **Seja opinativo.** Quando existirem várias palavras para o mesmo conceito, escolha a melhor e liste as demais como apelidos a serem evitados. É assim que a linguagem se comprime.
- **Mantenha as definições restritas.** Uma ou duas frases. Defina o que é o termo, não o que ele faz ou como fazê-lo.
- **Use os próprios termos do glossário dentro das definições.** Quando um termo estiver no glossário, dê preferência a ele em todos os lugares, inclusive dentro de outras definições. Isso é o que torna os termos complexos mais fáceis de entender posteriormente.
- **Agrupar em subtítulos** quando surgem clusters naturais (por exemplo, `## Anatomy`, `## Programming`). Uma lista simples é adequada quando os termos são coerentes.
- **Sinalize ambigüidades explicitamente.** Se um termo for usado livremente em um campo mais amplo, observe a resolução: "Neste espaço de trabalho, 'conjunto' sempre significa um conjunto de trabalho; os aquecimentos são rastreados separadamente."
- **Revise à medida que a compreensão se aprofunda.** Uma definição que o usuário escreveu na primeira semana pode estar errada na sexta semana. Atualização em vigor; não deixe entradas obsoletas.