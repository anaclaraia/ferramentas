# Formato MISSÃO.md

`MISSION.md` reside na raiz da área de trabalho. Ele captura o _motivo_ pelo qual o usuário está aprendendo este tópico. Cada decisão de ensino (o que ensinar a seguir, que recursos apresentar, que exercícios conceber) deve basear-se neste documento.

## Modelo

```md
# Mission: {Topic}

## Why
{1-3 sentences. The concrete real-world goal the user is chasing. What changes in their life or work when they have this skill? Avoid abstract framings like "to understand X"; push for the underlying outcome.}

## Success looks like
- {A specific, observable thing the user will be able to do}
- {Another specific thing}
- {…}

## Constraints
- {Time, budget, prior commitments, learning preferences, anything that bounds the approach}

## Out of scope
- {Adjacent topics the user explicitly does not want to chase right now, protecting the zone of proximal development}
```

## Regras

- **Uma missão por espaço de trabalho.** Se o usuário quiser aprender duas coisas não relacionadas, isso significa dois espaços de trabalho.
- **Concreto sobre abstrato.** "Correr uma meia maratona até outubro" é melhor do que "ficar em forma". “Enviar um Rust CLI para minha equipe” é melhor do que “aprender Rust”.
- **Evite a imprecisão.** Se o usuário não conseguir articular o motivo, entreviste-o antes de escrever qualquer coisa. Uma missão ruim é pior do que nenhuma missão.
- **Revisar quando a realidade mudar.** As missões mudam. Quando o objetivo do usuário mudar, atualize este arquivo: não deixe uma missão obsoleta para orientar sessões futuras.
- **Seja breve.** Se `MISSION.md` passar por uma tela, ele deixou de ser uma bússola e passou a ser um plano.