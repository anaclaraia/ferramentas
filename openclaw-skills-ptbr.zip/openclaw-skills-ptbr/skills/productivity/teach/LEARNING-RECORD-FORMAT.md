# Formato de registro de aprendizagem

Os registros de aprendizagem ficam em `./learning-records/` e usam numeração sequencial: `0001-slug.md`, `0002-slug.md`, etc. Crie o diretório preguiçosamente: somente quando o primeiro registro for gravado.

Eles são o equivalente didático das ADRs: capturam lições não óbvias, insights importantes e conhecimentos prévios declarados que orientarão sessões futuras. Eles são usados ​​para calcular a zona de desenvolvimento proximal.

## Modelo

```md
# {Short title of what was learned or established}

{1-3 sentences: what was learned (or what prior knowledge was established), and why it matters for future sessions.}
```

Esse é todo o formato. Um registro de aprendizagem pode ser um único parágrafo. O valor é registrar _que_ isso agora é conhecido e _por que_ muda o que ensinar a seguir, não no preenchimento das seções.

## Seções opcionais

Inclua-os apenas quando agregarem valor genuíno. A maioria dos registros não precisará deles.

- **Status** frontmatter (`active | superseded by LR-NNNN`): útil quando um entendimento anterior se revela errado e é substituído.
- **Evidência**: como o usuário demonstrou compreensão (uma pergunta respondida, um exercício concluído, experiência anterior citada). Útil quando a reivindicação pode ser revisada.
- **Implicações**: o que isso desbloqueia ou descarta para sessões futuras. Vale a pena registrar quando não for óbvio.

## Numeração

Digitalize `./learning-records/` para obter o maior número existente e aumente em um.

## Quando escrever um registro de aprendizagem

Escreva um quando alguma destas situações for verdadeira:

1. **O usuário demonstrou compreensão genuína de algo não trivial**: não apenas exposição, mas evidência de que pode usar o conceito corretamente. Isso estabelece um novo patamar para o que ensinar a seguir.
2. **O usuário divulgou conhecimento prévio**: “Já conheço X.” Grave-o para que sessões futuras não o ensinem novamente. Registre também a _profundidade_ reivindicada.
3. **Um equívoco foi corrigido**: o usuário anteriormente acreditava em algo errado e agora entende o porquê. São de alto valor: prevêem obstáculos futuros para tópicos relacionados.
4. **A missão mudou em resposta ao aprendizado**: o usuário descobriu que se importava com algo diferente do que pensava. Faça um link cruzado para [[MISSION.md]] e atualize-o.

### O que _não_ se qualifica

- Material que foi meramente coberto. Cobertura não é aprendizado. Espere por evidências.
- Qualquer coisa já capturada concisamente em [[GLOSSARY.md]] como uma definição de termo. Não duplique.
- Logs de atividades sessão por sessão. Os registros de aprendizagem não são um diário: são percepções de nível de decisão.

## Supersessão

Quando um registro posterior contradizer um anterior (a compreensão do usuário foi aprofundada ou corrigida), marque o registro antigo como `Status: superseded by LR-NNNN` em vez de excluí-lo. A história de como a compreensão evoluiu é em si um sinal útil.