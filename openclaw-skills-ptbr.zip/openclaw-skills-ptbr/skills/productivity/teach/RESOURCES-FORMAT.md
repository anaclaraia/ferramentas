# Formato RECURSOS.md

`RESOURCES.md` é o conjunto selecionado de fontes confiáveis para este tópico. O conhecimento para os explicadores deve ser extraído daqui, e não de suposições paramétricas. A sabedoria vem das comunidades listadas aqui.

## Estrutura

```md
# {Topic} Resources

## Knowledge

- [Book: _The Science and Practice of Strength Training_ by Zatsiorsky & Kraemer](https://example.com)
  Foundational text on programming and adaptation. Use for: anything to do with periodisation, recovery, intensity zones.
- [Article: "How Much Should I Train?" by Greg Nuckols (Stronger By Science)](https://example.com)
  Evidence-based review of volume landmarks. Use for: weekly set targets per muscle group.

## Wisdom (Communities)

- [r/weightroom](https://reddit.com/r/weightroom)
  High-signal subreddit, moderated against bro-science. Use for: programme critique, plateau troubleshooting.
- Local: Tuesday strength class at {gym name}
  Use for: real-time coaching feedback on lifts.
```

## Regras

- **Somente alta confiança.** Prefira fontes primárias, especialistas reconhecidos, trabalhos revisados por pares e comunidades com forte moderação. Se um recurso for marketing disfarçado de educação, deixe-o de fora.
- **Anote cada entrada.** Um link simples é inútil em três meses. Adicione uma linha: o que cobre e quando alcançá-lo.
- **Agrupar por Conhecimento/Sabedoria.** Espelha a filosofia em [SKILL.md](./SKILL.md). É normal que um recurso apareça em apenas um grupo.
- **Superfície de lacunas explicitamente.** Se não existir nenhum bom recurso para uma área que a missão precisa, escreva uma seção `## Gaps` listando o que está faltando. Isso impulsiona pesquisas futuras.
- **Podar implacavelmente.** Um recurso que se revelou errado, superficial ou fora da missão deve ser removido, não enterrado. Melhor cinco fontes afiadas do que trinta medíocres.
- **Registre as preferências da comunidade.** Se o usuário optou por não participar das comunidades, anote aqui para que sessões futuras não continuem propondo-as.