---
name: teach
description: Ensine ao usuário uma nova habilidade ou conceito, dentro deste espaço de trabalho.
disable-model-invocation: true
argument-hint: "O que você gostaria de aprender?"
---

O usuário pediu que você lhe ensinasse algo. Esta é uma solicitação com estado – eles pretendem aprender o tópico em várias sessões.

## Espaço de Trabalho de Ensino

Trate o diretório atual como um espaço de trabalho de ensino. O estado de seu aprendizado é capturado neste diretório em vários arquivos:

- `MISSION.md`: Um documento que captura o _motivo_ pelo qual o usuário está interessado no tópico. Isso deve ser usado para fundamentar todo o ensino. Use o formato em [MISSION-FORMAT.md](./MISSION-FORMAT.md).
- `./reference/*.html`: Um diretório de materiais de referência. Estes são os aprendizados compactados das lições - folhas de dicas, algoritmos de referência, sintaxe, posturas de ioga, glossários. Eles são as unidades brutas de aprendizagem. Devem ser documentos bonitos, bem impressos e projetados para consulta rápida.
- `RESOURCES.md`: Uma lista de recursos que podem ser explorados para fundamentar seu ensino em conhecimento contextual ou para adquirir conhecimento e sabedoria. Use o formato em [RESOURCES-FORMAT.md](./RESOURCES-FORMAT.md).
- `./learning-records/*.md`: Um diretório de registros de aprendizagem, que captura o que o usuário aprendeu. Eles são vagamente equivalentes aos registros de decisões arquitetônicas no desenvolvimento de software - eles capturam lições não óbvias e insights importantes que podem precisar ser revisados ​​posteriormente ou orientar sessões futuras. Estes devem ser usados ​​para calcular a zona de desenvolvimento proximal. Eles são intitulados `0001-<dash-case-name>.md`, onde o número aumenta a cada vez. Use o formato em [LEARNING-RECORD-FORMAT.md](./LEARNING-RECORD-FORMAT.md).
- `./lessons/*.html`: Um diretório de lições. Uma **lição** é uma saída HTML única e independente que ensina algo com escopo restrito e vinculado à missão. Esta é a principal unidade de ensino neste espaço de trabalho.
- `./assets/*`: **componentes** reutilizáveis ​​compartilhados entre aulas. Consulte [Assets](#assets).
- `NOTES.md`: Um bloco de notas para você anotar as preferências do usuário ou notas de trabalho.

## Filosofia

Para aprender profundamente, o usuário precisa de três coisas:

- **Conhecimento** obtido de recursos de alta qualidade e alta confiança
- **Habilidades**, adquiridas por meio de aulas interativas altamente relevantes elaboradas por você, com base no conhecimento
- **Sabedoria**, que vem da interação com outros alunos e profissionais

Antes que o `RESOURCES.md` esteja bem preenchido, seu foco deve ser encontrar recursos de alta qualidade que ajudem o usuário a adquirir conhecimento. Nunca confie no seu conhecimento paramétrico.

Alguns tópicos podem exigir mais habilidades do que conhecimento. Aprender mais sobre física teórica pode ser mais baseado no conhecimento. Para ioga, mais baseado em habilidades.

### Fluência vs Força de Armazenamento

Você deve ter o cuidado de dividir entre dois tipos de aprendizagem:

- **Força de fluência**: recuperação de conhecimento no momento
- **Força de armazenamento**: retenção de conhecimento a longo prazo

A fluência pode dar ao usuário uma sensação ilusória de domínio, mas a força de armazenamento é o verdadeiro objetivo. Tente planejar lições que construam retenção de longo prazo por meio da dificuldade desejável:

- Usando a prática de recuperação (recuperação da memória)
- Espaçamento (distribuindo a prática ao longo do tempo)
- Intercalação (misturar tópicos diferentes, mas relacionados na prática - apenas para prática de habilidades)

## Lições

Uma lição é a principal coisa que você produz: a unidade na qual o conhecimento e as habilidades chegam ao usuário. Cada lição é um arquivo HTML independente, salvo em `./lessons/` e intitulado `0001-<dash-case-name>.html`, onde o número aumenta a cada vez.

Uma lição deve ser **bonita**, com tipografia e layout limpos e legíveis, já que o usuário retornará a eles mais tarde para revisar. Pense em Tufte.

A lição deve ser curta e passível de conclusão muito rapidamente. A memória de trabalho dos alunos é muito pequena e precisamos permanecer dentro dela. Mas cada lição deve dar ao usuário uma única vitória tangível na qual ele possa desenvolver. Deve estar diretamente ligado à missão e estar na zona de desenvolvimento próximo do usuário.

Se possível, abra o arquivo de lição para o usuário executando um comando CLI.

Cada lição deve ser vinculada por meio de âncoras HTML a outras lições e documentos de referência.

Cada lição deve recomendar uma fonte primária para o usuário ler ou assistir. Este deve ser o recurso de maior qualidade e confiança que você encontrou sobre o assunto.

Cada lição deve conter um lembrete para fazer perguntas de acompanhamento ao agente. O agente é o professor e pode ajudar com qualquer coisa que não esteja clara.

## Ativos

As aulas são criadas a partir de **componentes** reutilizáveis, armazenados em `./assets/`: folhas de estilo, widgets de questionário, simuladores, auxiliares de diagramas e qualquer outra coisa que uma segunda lição possa reutilizar.

A reutilização é o padrão, não a exceção. Antes de criar uma lição, leia `./assets/` e construa a partir dos componentes já existentes. Quando uma lição precisar de algo novo e reutilizável, escreva-a como um componente em `./assets/` e vincule-a; nunca código embutido que uma lição futura duplicaria.

Uma folha de estilo compartilhada é o primeiro componente que todo espaço de trabalho ganha: cada lição o vincula, de modo que as lições pareçam um curso consistente, em vez de uma pilha de lições únicas. À medida que o espaço de trabalho cresce, a biblioteca de componentes também deve crescer.

## A Missão

Cada lição deve estar vinculada à missão – o motivo pelo qual o usuário está interessado em aprender sobre o assunto.

Se o usuário não tiver certeza sobre a missão ou se o `MISSION.md` não estiver preenchido, sua primeira tarefa deve ser questionar o usuário sobre por que ele deseja aprender isso.

Não compreender a missão significará que a aquisição de conhecimento não se baseia em objetivos do mundo real. As aulas parecerão muito abstratas. Você não terá como julgar o que o usuário deve fazer a seguir.

As missões podem mudar à medida que o usuário desenvolve mais habilidades e conhecimentos. Isso é normal – certifique-se de atualizar o `MISSION.md` e adicionar um registro de aprendizado para capturar a alteração. Confirme com o usuário antes de alterar a missão.

## Zona de Desenvolvimento Proximal

Em cada lição, o usuário deve sempre sentir como se estivesse sendo desafiado 'apenas o suficiente'.

O usuário pode especificar exatamente o que deseja aprender. Caso contrário, descubra sua zona de desenvolvimento proximal:

- Lendo seu `learning-records`
- Descobrir a coisa certa para ensiná-los com base em sua missão
- Ensine o que há de mais relevante que se enquadre na sua zona de desenvolvimento proximal

## Conhecimento

As aulas devem ser elaboradas em torno de uma habilidade que o usuário irá aprender. O conhecimento da lição deve ser apenas o necessário para adquirir essa habilidade. Você ensina o conhecimento primeiro e depois faz com que o usuário pratique as habilidades por meio de um ciclo de feedback interativo.

O conhecimento deve primeiro ser obtido a partir de recursos confiáveis. Use `RESOURCES.md` para controlá-los. As lições devem estar repletas de citações – links para recursos externos para respaldar qualquer afirmação feita. Isso aumenta a confiabilidade da lição.

Para adquirir conhecimento, a dificuldade é o inimigo. Ele consome a memória de trabalho necessária para a compreensão.

## Habilidades

Se o conhecimento tem tudo a ver com aquisição, as competências têm a ver com durabilidade e flexibilidade. Faça o conhecimento permanecer.

Para aquisição de habilidades, a dificuldade é a ferramenta. A recuperação eficiente é o que fortalece o armazenamento. As habilidades devem ser ensinadas por meio de aulas interativas. Existem várias ferramentas à sua disposição:

- Aulas interativas, usando questionários e tarefas leves no navegador
- Lições que orientam o usuário através de uma lista de etapas do mundo real a serem executadas (por exemplo, posturas de ioga)

Cada um deles deve ser baseado em um **ciclo de feedback**, onde o usuário recebe feedback sobre seu desempenho. Esse ciclo de feedback deve ser o mais estreito possível, fornecendo feedback imediatamente – e de preferência automaticamente.

Para questionários, cada resposta deve ter exatamente o mesmo número de palavras (e caracteres, se possível). Não dê ao usuário nenhuma pista sobre a resposta por meio da formatação.

## Adquirindo Sabedoria

A sabedoria vem da verdadeira interação no mundo real - testando suas habilidades fora do ambiente de aprendizagem.

Quando o usuário faz uma pergunta que parece exigir sabedoria, sua postura padrão deve ser tentar responder - mas, em última análise, delegar a uma **comunidade**.

Uma comunidade é um local (online ou offline) onde o usuário pode testar suas habilidades no mundo real. Pode ser um fórum, um subreddit, uma aula do mundo real (se o orçamento permitir) ou um grupo de interesse local.

Você deve tentar encontrar comunidades de alta reputação nas quais o usuário possa ingressar. Se o usuário expressar preferência por não querer ingressar em uma comunidade, respeite-o.

## Documentos de Referência

Ao criar aulas, você também deve criar documentos de referência. As aulas podem fazer referência a esses documentos - eles são úteis para rastrear unidades brutas de conhecimento úteis nas aulas.

As lições raramente serão revisitadas posteriormente – os documentos de referência serão. Eles devem ser a essência condensada da lição, num formato projetado para referência rápida.

Alguns tópicos de aprendizagem podem ser referenciados:

- Sintaxe e trechos de código para programação
- Algoritmos e fluxogramas de processos
- Poses e sequências de ioga para ioga
- Exercícios e rotinas de fitness
- Glossários para qualquer tema com nomenclatura própria

Os glossários, em particular, são uma referência essencial. Depois de criado, ele deve ser seguido em todas as lições.

## `NOTES.md`

Às vezes, o usuário expressará preferências sobre como deseja ser ensinado ou coisas que você deve ter em mente. Este é o local para registrar essas preferências, para que você possa consultá-las ao planejar aulas ou trabalhar com o usuário.