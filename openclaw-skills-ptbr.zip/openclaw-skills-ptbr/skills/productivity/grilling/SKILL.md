---
name: grilling
description: questione o usuário incansavelmente sobre um plano, decisão ou ideia. Use quando o usuário quiser testar seu pensamento ou usar qualquer frase de gatilho 'grill'.
---

Entreviste o usuário incansavelmente até chegar a um entendimento compartilhado. Mapeie isso como uma **árvore de design**: cada decisão se ramifica nas decisões que dependem dela.

Trabalhe a árvore em **rodadas**. A **fronteira** é toda decisão cujos pré-requisitos já foram definidos: as perguntas que você pode fazer _agora_ sem adivinhar respostas que ainda não ouviu. Pergunte toda a fronteira de uma só vez: numere cada pergunta e dê a resposta recomendada. Em seguida, aguarde as respostas do usuário antes da próxima rodada.

Formate uma rodada assim:

```
❓ **Q1** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>

➡️ <your recommended answer>

---

❓ **Q2** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>

➡️ <your recommended answer>
```

Cada rodada que o usuário responde remodela a árvore: decisões acertadas empurram a fronteira para fora e desbloqueiam questões que dependiam delas. Recalcule a fronteira e pergunte a próxima rodada. Uma questão cuja resposta depende de outra questão ainda em aberto nesta rodada pertence a uma rodada _posterior_, não a esta.

Encontrar _fatos_ é seu trabalho, nunca do usuário. Quando uma questão de fronteira precisar de um fato do ambiente (sistema de arquivos, ferramentas, etc.), envie um subagente para encontrá-lo; não peça ao usuário nada que você possa pesquisar sozinho. Não bloqueie: uma exploração em execução é um pré-requisito não resolvido, portanto, apenas as questões posteriores aguardam o relatório do subagente; pergunte ao resto da fronteira agora. As _decisões_ são do usuário: coloque cada uma nelas e espere.

A sessão é concluída quando a fronteira está vazia: cada ramo da árvore de projeto visitado, nada deixado silenciosamente assumido. Não aja até que o usuário confirme que você alcançou um entendimento compartilhado.