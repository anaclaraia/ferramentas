# Quando zombar

Zombar apenas de **limites do sistema**:

- APIs externas (pagamento, email, etc.)
- Bancos de dados (às vezes - prefira banco de dados de teste)
- Tempo/aleatoriedade
- Sistema de arquivos (às vezes)

Não zombe:

- Suas próprias aulas/módulos
- Colaboradores internos
- Qualquer coisa que você controle

## Projetando para Mockability

Nos limites do sistema, projete interfaces que sejam fáceis de simular:

**1. Use injeção de dependência**

Passe dependências externas em vez de criá-las internamente:

```typescript
// Easy to mock
function processPayment(order, paymentClient) {
  return paymentClient.charge(order.total);
}

// Hard to mock
function processPayment(order) {
  const client = new StripeClient(process.env.STRIPE_KEY);
  return client.charge(order.total);
}
```

**2. Prefira interfaces estilo SDK em vez de buscadores genéricos**

Crie funções específicas para cada operação externa em vez de uma função genérica com lógica condicional:

```typescript
// GOOD: Each function is independently mockable
const api = {
  getUser: (id) => fetch(`/users/${id}`),
  getOrders: (userId) => fetch(`/users/${userId}/orders`),
  createOrder: (data) => fetch('/orders', { method: 'POST', body: data }),
};

// BAD: Mocking requires conditional logic inside the mock
const api = {
  fetch: (endpoint, options) => fetch(endpoint, options),
};
```

A abordagem SDK significa:
- Cada simulação retorna uma forma específica
- Nenhuma lógica condicional na configuração do teste
- Mais fácil de ver quais endpoints um teste exerce
- Digite segurança por endpoint