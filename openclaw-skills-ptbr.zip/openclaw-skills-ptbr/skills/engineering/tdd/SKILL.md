---
name: tdd
description: Desenvolvimento orientado a testes. Use quando o usuário deseja construir recursos ou corrigir bugs testando primeiro, menciona "red-green-refactor" ou deseja testes de integração.
---

# Desenvolvimento orientado a testes

TDD é o loop vermelho → verde. Essa habilidade é a referência que faz aquele loop produzir testes que valem a pena manter: o que é um bom teste, para onde vão os testes, os antipadrões e as regras do loop. Cada seção se aplica a todos os ciclos: consulte-as antes e durante o loop, não depois.

Ao explorar a base de código, leia `CONTEXT.md` (se existir) para que os nomes dos testes e o vocabulário da interface correspondam ao idioma de domínio do projeto e respeite os ADRs na área que você está tocando.

## O que é um bom teste

Os testes verificam o comportamento através de interfaces públicas, não de detalhes de implementação. O código pode mudar completamente; os testes não deveriam. Um bom teste parece uma especificação: "o usuário pode finalizar a compra com um carrinho válido" informa exatamente qual capacidade existe e sobrevive a refatorações porque não se importa com a estrutura interna.

Consulte [tests.md](tests.md) para exemplos e [mocking.md](mocking.md) para diretrizes de simulação.

## Costuras: para onde vão os testes

Uma **seam** é o limite público em que você testa: a interface onde você observa o comportamento sem chegar lá dentro. Os testes vivem nas costuras, nunca contra os internos.

**Teste apenas em costuras pré-acordadas.** Antes de escrever qualquer teste, anote as costuras em teste e confirme-as com o usuário. Nenhum teste é escrito em uma costura não confirmada. Você não pode testar tudo, então concordar antecipadamente é como o esforço de teste chega aos caminhos críticos e à lógica complexa, em vez de em todos os casos extremos.

Pergunte: "Qual é a interface pública e quais emendas devemos testar?"

Quando a forma dessa interface for questionada (qual a profundidade do módulo, onde a costura pertence, o que a interface deve expor), ative a skill com "codebase-design" para o vocabulário. É a fonte compartilhada dos termos de módulo, interface, profundidade, costura, adaptador, alavancagem e localidade, e é uma referência para consultar, não uma sessão para executar.

## Antipadrões

- **Acoplado à implementação**: zomba de colaboradores internos, testa métodos privados ou verifica através de um canal lateral (consultando o banco de dados em vez de usar a interface). A dica: o teste é interrompido quando você refatora, mas o comportamento não muda.
- **Tautológico**: a asserção recalcula o valor esperado da mesma forma que o código (`expect(add(a, b)).toBe(a + b)`, um instantâneo derivado manualmente da mesma maneira, uma constante afirmada igual a si mesma), portanto ela passa por construção e nunca pode discordar do código. Os valores esperados devem vir de uma fonte independente de verdade: um literal válido, um exemplo prático, a especificação.
- **Fatiamento horizontal**: escrever primeiro todos os testes e depois toda a implementação. Os testes em massa verificam o comportamento _imaginado_: você testa a _forma_ das coisas em vez do comportamento voltado para o usuário, os testes tornam-se insensíveis a mudanças reais e você se compromete com a estrutura de teste antes de entender a implementação. Em vez disso, trabalhe em **fatias verticais**: um teste → uma implementação → repita, cada teste um **marcador** que responde ao que o último ciclo lhe ensinou.

## Regras do loop

- **Vermelho antes do verde.** Escreva primeiro o teste com falha e, em seguida, apenas o código suficiente para aprová-lo. Não antecipe testes futuros nem adicione recursos especulativos.
- **Uma fatia de cada vez.** Uma emenda, um teste, uma implementação mínima por ciclo.
- **A refatoração não faz parte do loop.** Ela pertence ao estágio de revisão (consulte a habilidade `code-review`), não ao ciclo de implementação vermelho → verde.