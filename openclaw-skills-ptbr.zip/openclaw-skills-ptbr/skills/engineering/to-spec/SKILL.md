---
name: to-spec
description: "Transforme a conversa atual em uma especificação e publique-a no rastreador de problemas do projeto: sem entrevista, apenas uma síntese do que você já discutiu."
disable-model-invocation: true
---

Essa habilidade pega o contexto atual da conversa e a compreensão da base de código e produz uma especificação. NÃO entreviste o usuário; apenas sintetize o que você já sabe.

O vocabulário do rastreador de problemas e do rótulo de triagem deveria ter sido fornecido a você. Caso contrário, diga ao usuário para executar `/setup-matt-pocock-skills`.

## Processo

1. Explore o repositório para entender o estado atual da base de código, caso ainda não o tenha feito. Use o vocabulário do glossário de domínio do projeto em toda a especificação e respeite quaisquer ADRs na área que você está tocando.

2. Esboce as costuras nas quais você testará o recurso. As costuras existentes devem ser preferidas às novas. Use a costura mais alta possível. Se forem necessárias novas costuras, proponha-as no ponto mais alto que puder. Quanto menos emendas na base de código, melhor – o número ideal é um.

Verifique com o usuário se essas costuras atendem às suas expectativas.

3. Escreva a especificação usando o modelo abaixo e publique-a no rastreador de problemas do projeto. Aplique a etiqueta de triagem `ready-for-agent` - não há necessidade de triagem adicional.

<modelo de especificação>

## Declaração do problema

O problema que o usuário está enfrentando, da perspectiva do usuário.

## Solução

A solução para o problema, na perspectiva do usuário.

## Histórias de usuários

Uma lista LONGA e numerada de histórias de usuários. Cada história de usuário deve estar no formato de:

1. Como <ator>, quero um <recurso>, para que <benefício>

<exemplo de história de usuário>
1. Como cliente de banco móvel, quero ver o saldo das minhas contas, para poder tomar decisões mais informadas sobre meus gastos
</user-story-example>

Esta lista de histórias de usuários deve ser extremamente extensa e cobrir todos os aspectos do recurso.

## Decisões de implementação

Uma lista de decisões de implementação que foram tomadas. Isso pode incluir:

- Os módulos que serão construídos/modificados
- As interfaces dos módulos que serão modificados
- Esclarecimentos técnicos do desenvolvedor
- Decisões arquitetônicas
- Mudanças de esquema
- Contratos de API
- Interações específicas

NÃO inclua caminhos de arquivo ou trechos de código específicos. Eles podem acabar ficando desatualizados muito rapidamente.

Exceção: se um protótipo produziu um trecho que codifica uma decisão com mais precisão do que a prosa (máquina de estado, redutor, esquema, forma de tipo), incorpore-o na decisão relevante e observe brevemente que ele veio de um protótipo. Corte para as partes ricas em decisões, não para uma demonstração funcional, apenas para as partes importantes.

## Decisões de teste

Uma lista de decisões de teste que foram tomadas. Incluir:

- Uma descrição do que constitui um bom teste (teste apenas o comportamento externo, não detalhes de implementação)
- Quais módulos serão testados
- Técnica anterior para os testes (ou seja, tipos semelhantes de testes na base de código)

## Fora do escopo

Uma descrição das coisas que estão fora do escopo desta especificação.

## Notas Adicionais

Quaisquer notas adicionais sobre o recurso.

</spec-template>