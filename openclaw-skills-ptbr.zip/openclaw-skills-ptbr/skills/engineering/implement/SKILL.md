---
name: implement
description: "Implementar um trabalho baseado em uma especificação ou conjunto de tickets."
disable-model-invocation: true
---

Implemente o trabalho descrito pelo usuário nas especificações ou tickets.

Use /tdd sempre que possível, em costuras pré-acordadas.

Execute a verificação de tipo regularmente, arquivos de teste únicos regularmente e o conjunto de testes completo uma vez no final.

Uma vez feito isso, use /code-review para revisar o trabalho.

Confirme seu trabalho no branch atual.