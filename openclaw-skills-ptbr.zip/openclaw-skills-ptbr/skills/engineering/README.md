# Engenharia

Habilidades que uso diariamente para trabalhar com código.

## Invocado pelo usuário

Acessível apenas quando você os digita (Código Claude: `disable-model-invocation: true`; Codex: `policy.allow_implicit_invocation: false` em `agents/openai.yaml`).

- **[ask-matt](./ask-matt/SKILL.md)**: Pergunte qual habilidade ou fluxo se adapta à sua situação. Um roteador sobre as habilidades invocadas pelo usuário neste repositório.
- **[grill-with-docs](./grill-with-docs/SKILL.md)**: Sessão de grilling que também constrói o modelo de domínio do seu projeto, aprimorando a terminologia e atualizando `CONTEXT.md` e ADRs inline.
- **[triage](./triage/SKILL.md)**: mova os problemas por meio de uma máquina de estado de funções de triagem.
- **[improve-codebase-architecture](./improve-codebase-architecture/SKILL.md)**: escaneie uma base de código para aprofundar oportunidades, apresente-as como um relatório HTML visual e, em seguida, analise o que você escolher.
- **[setup-matt-pocock-skills](./setup-matt-pocock-skills/SKILL.md)**: Configure este repositório para as habilidades de engenharia (rastreador de problemas, rótulos de triagem, layout de documento de domínio). Execute uma vez por repositório.
- **[to-spec](./to-spec/SKILL.md)**: Transforme a conversa atual em uma especificação e publique-a no rastreador de problemas.
- **[to-tickets](./to-tickets/SKILL.md)**: divida qualquer plano, especificação ou conversa em um conjunto de tickets de rastreador, cada um declarando suas bordas de bloqueio, seja como texto em um arquivo local ou como links de bloqueio nativos em um rastreador real.
- **[implement](./implement/SKILL.md)**: Crie o trabalho descrito por uma especificação ou conjunto de tickets, conduzindo `/tdd` em costuras pré-acordadas e fechando com `/code-review` antes de confirmar.
- **[wayfinder](./wayfinder/SKILL.md)**: planeje uma grande parte do trabalho (mais de uma sessão de agente pode conter) como um mapa compartilhado de tickets de decisão no rastreador de problemas, resolvido um de cada vez até que o caminho para o destino esteja livre.

## Invocado por modelo

Acessível pelo modelo ou pelo usuário (frases de gatilho ricas para que o modelo possa alcançá-los).

- **[prototype](./prototype/SKILL.md)**: crie um protótipo descartável para responder a uma questão de design: um único arquivo HTML compartilhável para estado/lógica ou diversas variações de UI alternáveis.

- **[diagnosing-bugs](./diagnosing-bugs/SKILL.md)**: Ciclo de diagnóstico disciplinado para bugs difíceis e regressões de desempenho: crie um ciclo de feedback que fica vermelho neste bug → minimizar → formular hipóteses → instrumento → corrigir → teste de regressão.
- **[research](./research/SKILL.md)**: investigue uma questão em fontes primárias de alta confiança e capture as descobertas como um arquivo Markdown citado no repositório, executado como um agente em segundo plano.
- **[tdd](./tdd/SKILL.md)**: Desenvolvimento orientado a testes com um loop de refatoração vermelho-verde. Cria recursos ou corrige bugs, uma fatia vertical de cada vez.
- **[domain-modeling](./domain-modeling/SKILL.md)**: crie e aprimore ativamente o modelo de domínio de um projeto desafiando termos, testes de estresse com cenários e atualizando `CONTEXT.md` e ADRs inline.
- **[codebase-design](./codebase-design/SKILL.md)**: Disciplina e vocabulário compartilhados para projetar módulos profundos: interfaces pequenas, costuras limpas, testáveis ​​por meio da interface.
- **[code-review](./code-review/SKILL.md)**: revisão de dois eixos da diferença desde um ponto fixo: **Padrões** (segue os padrões de codificação do repo, além de uma linha de base do cheiro de Fowler?) e **Spec** (segue fielmente implementa o problema/especificação de origem?), executados como subagentes paralelos.
- **[resolving-merge-conflicts](./resolving-merge-conflicts/SKILL.md)**: Trabalhe em uma mesclagem git em andamento ou rebase o conflito pedaço por pedaço, resolvendo por intenção rastreada para a fonte primária de cada lado e, em seguida, conclua a operação, nunca `--abort`.
- **[wizard](./wizard/SKILL.md)**: Gere um assistente bash interativo que orienta um ser humano pelas etapas que somente ele pode executar: provisionamento de infraestrutura, configuração de credenciais ou segredos de CI, navegação em um painel de terceiros desconhecido ou execução de uma migração ou transição única.