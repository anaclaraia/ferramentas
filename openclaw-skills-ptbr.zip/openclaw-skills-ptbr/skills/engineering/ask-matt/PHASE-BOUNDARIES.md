# Limites de fase

Uma **fase** é uma parte do trabalho dentro de uma sessão: a grelha, a implementação, o controle de qualidade. A definição é propositalmente confusa: uma fase termina quando você pensa *"ok, terminamos com isso"*.

O **limite de fase** é a lacuna entre duas fases e é o único lugar onde esta decisão pertence. No meio da fase não há decisão a tomar: continuar ou dividir o trabalho restante em subagentes. A compactação no meio da fase faz com que o agente perca o fio.

## As cinco opções

| Opção | O que faz |
| ------------ | -------------------------------------------------------------------------- |
| **Continuar** | Fique na sessão. Nenhuma mudança de contexto.                    |
| **`/clear`** | Esvazie a janela de contexto e comece do nada.                  |
| **`/handoff`** | Escreva um arquivo markdown portátil e propague uma sessão em qualquer lugar com ele. |
| **Subagente** | Envie a tarefa para sua própria janela de contexto e receba um relatório.     |
| **`/compact`** | Comprima esse contexto e crie uma nova sessão com o resumo.  |

## A árvore

Trabalhe de cima para baixo no limite. O primeiro **sim** vence.

**1. Você pode continuar nesta sessão?** Duas coisas tornam a resposta sim: a próxima fase precisa desta fase como uma **fonte primária** ou você tem [smart zone](https://www.aihero.dev/ai-coding-dictionary/smart-zone) suficiente restante (~150 mil tokens) para a próxima fase caber. Grelhar → implementação é o padrão sim: a implementação quer o raciocínio literalmente, não um resumo dele. Continuar não custa nada e não perde nada, então descarte antes de qualquer coisa.

**2. O contexto é irrelevante para o que vem a seguir?** Tudo nesta sessão (a exploração, as decisões, os becos sem saída) é descartável? Nesse caso, **`/clear`**. É a jogada mais barata do tabuleiro: não demora e devolve toda a janela. `/clear` também não é terminal: a sessão antiga permanece recuperável.

O custo de errar é unilateral. Limpe um contexto *relevante* e você perderá o **porquê** por trás do que construiu, e nenhuma quantidade de leitura da diferença o retornará.

**3. Você precisa transferir?** `/handoff` é estreito. Você precisa disso apenas quando estiver:

- trocando por um **novo arnês** (Claude → Codex),
- mudar para um **novo diretório** ou repositório,
- enviar o trabalho para um **colega**,
- ou bifurcar uma tarefa paralela que você encontrou **no meio da fase** sem atrapalhar o que está fazendo.

Essa lista é a cláusula completa. O que `/handoff` compra é **portabilidade**: um arquivo que viaja. Se nada estiver viajando, você não precisa disso.

**4. A tarefa pode ser realizada AFK? ** O escopo é apertado o suficiente para correr com você para longe do teclado, sem direção? Em seguida, envie-o para um **subagente** e deixe esta sessão intacta. A revisão automatizada é o caso padrão: o agente lê a comparação e os relatórios, e você não é necessário enquanto isso acontece.

**5. Caso contrário, `/compact`.** Contexto relevante, mesmo equipamento, mesmo diretório, e você precisa ficar por dentro: é aqui que a árvore pousa, e ela pousa aqui com frequência. Passe uma instrução (`/compact we're going to QA this area`) para que o resumo guarde o que a próxima fase precisa.

`/compact` é o **padrão, não o primeiro alcance**. Fica na parte inferior porque as quatro perguntas acima são todas mais baratas ou mais precisas. O modo de fracasso quando as pessoas começam aqui é uma nova sessão que está confiantemente errada sobre uma decisão que o resumo nivelou.

## Fontes primárias e secundárias

Cada movimento, exceto **Continuar**, transforma uma **fonte primária** em uma **fonte secundária**: a sessão como ela aconteceu, substituída por um resumo dela. O comércio é sempre o mesmo formato:

| Fonte | Informação | Ruído | Espaço para se movimentar |
| --------------------------------- | ----------- | ----- | ------------ |
| Primário (Continuar) | Completo | Lotes | Pouco |
| Secundário (`/compact`, `/handoff`) | Com perdas | Menos | Lotes |

É por isso que a pergunta 1 vem em primeiro lugar. Você só paga as perdas quando ficar custa mais do que economiza.

## Estas são decisões judiciais

As perguntas não são objetivas: cada um tem gosto e a mesma fronteira pode percorrer dois caminhos em dois dias. O valor está em perguntar-lhes **em ordem**, no limite e não no meio do trabalho.