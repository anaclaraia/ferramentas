# Aprofundamento

Como aprofundar um cluster de módulos rasos com segurança, dadas as suas dependências. Assume o vocabulário em [SKILL.md](SKILL.md): **módulo**, **interface**, **costura**, **adaptador**.

## Categorias de dependência

Ao avaliar um candidato ao aprofundamento, classifique suas dependências. A categoria determina como o módulo aprofundado é testado em toda a sua costura.

### 1. Em processo

Computação pura, estado na memória, sem E/S. Sempre aprofundável: mescle os módulos e teste diretamente através da nova interface. Não é necessário adaptador.

### 2. Substituível localmente

Dependências que possuem substitutos de teste locais (PGLite para Postgres, sistema de arquivos na memória). Aprofundável se o substituto existir. O módulo aprofundado é testado com o substituto em execução no conjunto de testes. A costura é interna; nenhuma porta na interface externa do módulo.

### 3. Remoto, mas próprio (portas e adaptadores)

Seus próprios serviços através dos limites da rede (microsserviços, APIs internas). Defina uma **porta** (interface) na junção. O módulo profundo possui a lógica; o transporte é injetado como um **adaptador**. Os testes usam um adaptador na memória. A produção usa um adaptador HTTP/gRPC/fila.

Formato de recomendação: *"Defina uma porta na costura, implemente um adaptador HTTP para produção e um adaptador na memória para teste, para que a lógica fique em um módulo profundo, mesmo que seja implantado em uma rede."*

### 4. Externo verdadeiro (simulado)

Serviços de terceiros (Stripe, Twilio, etc.) que você não controla. O módulo aprofundado considera a dependência externa como uma porta injetada; os testes fornecem um adaptador simulado.

## Disciplina de costura

- **Um adaptador significa uma costura hipotética. Dois adaptadores significam um verdadeiro.** Não introduza uma porta a menos que pelo menos dois adaptadores sejam justificados (normalmente produção + teste). Uma costura de adaptador único é apenas indireta.
- **Costuras internas vs costuras externas.** Um módulo profundo pode ter costuras internas (privadas de sua implementação, usadas por seus próprios testes), bem como a costura externa em sua interface. Não exponha costuras internas através da interface só porque os testes as utilizam.

## Estratégia de teste: substitua, não coloque camadas

- Testes unitários antigos em módulos superficiais tornam-se desperdício uma vez que existem testes na interface do módulo aprofundado; exclua-os.
- Escreva novos testes na interface do módulo aprofundado. A **interface é a superfície de teste**.
- Os testes baseiam-se em resultados observáveis ​​através da interface, não no estado interno.
- Os testes devem sobreviver aos refatoradores internos, pois descrevem o comportamento, não a implementação. Se um teste precisar mudar quando a implementação mudar, ele estará testando além da interface.