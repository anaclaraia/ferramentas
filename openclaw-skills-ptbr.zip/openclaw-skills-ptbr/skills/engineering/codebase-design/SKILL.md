---
name: codebase-design
description: Vocabulário compartilhado para projetar módulos profundos. Use quando o usuário quiser projetar ou melhorar a interface de um módulo, encontrar oportunidades de aprofundamento, decidir para onde vai uma costura, tornar o código mais testável ou navegável por IA ou quando outra habilidade precisar do vocabulário profundo do módulo.
---

# Design de base de código

Projete **módulos profundos**: muito comportamento por trás de uma interface pequena, colocada em uma costura limpa, testável por meio dessa interface. Use esta linguagem e estes princípios sempre que o código estiver sendo projetado ou reestruturado. O objetivo é alavancar os chamadores, localidade para os mantenedores e testabilidade para todos.

## Glossário

Use estes termos exatamente: não substitua “componente”, “serviço”, “API” ou “limite”. Linguagem consistente é o ponto principal.

**Módulo**: qualquer coisa com uma interface e uma implementação. Deliberadamente independente de escala: uma função, classe, pacote ou fatia que abrange camadas. _Evitar_: unidade, componente, serviço.

**Interface**: tudo que um chamador deve saber para usar o módulo corretamente: a assinatura do tipo, mas também invariantes, restrições de ordenação, modos de erro, configuração necessária e características de desempenho. _Evitar_: API, assinatura (muito restrita, referem-se apenas à superfície de nível de tipo).

**Implementação**: o que há dentro de um módulo, seu corpo de código. Distinto de **Adaptador**: uma coisa pode ser um adaptador pequeno com uma implementação grande (um repositório Postgres) ou um adaptador grande com uma implementação pequena (uma falsificação na memória). Procure o “adaptador” quando o assunto for a costura; "implementação" caso contrário.

**Profundidade**: alavancagem na interface. A quantidade de comportamento que um chamador (ou teste) pode exercer por unidade de interface que precisa aprender. Um módulo é **profundo** quando uma grande quantidade de comportamento fica por trás de uma interface pequena, **superficial** quando a interface é quase tão complexa quanto a implementação.

**Seam** _(Michael Feathers)_: um local onde você pode alterar o comportamento sem editar naquele local; o *local* onde reside a interface de um módulo. Onde colocar a costura é uma decisão de design própria, distinta do que está por trás dela. _Avoid_: limite (sobrecarregado com o contexto limitado do DDD).

**Adaptador**: uma coisa concreta que satisfaz uma interface em uma costura. Descreve o *papel* (que espaço ele preenche), não a substância (o que está dentro).

**Aproveitamento**: o que os chamadores obtêm em profundidade. Mais capacidade por unidade de interface que eles aprendem. Uma implementação compensa em N sites de chamadas e M testes.

**Localidade**: o que os mantenedores obtêm com profundidade. Mudanças, bugs, conhecimento e verificação concentram-se em um só lugar, em vez de se espalharem pelos chamadores. Corrija uma vez, conserte em todos os lugares.

## Profundo versus raso

**Módulo profundo** = interface pequena + muita implementação:

```
┌─────────────────────┐
│   Small Interface   │  ← Few methods, simple params
├─────────────────────┤
│                     │
│  Deep Implementation│  ← Complex logic hidden
│                     │
└─────────────────────┘
```

**Módulo superficial** = interface grande + pouca implementação (evitar):

```
┌─────────────────────────────────┐
│       Large Interface           │  ← Many methods, complex params
├─────────────────────────────────┤
│  Thin Implementation            │  ← Just passes through
└─────────────────────────────────┘
```

Ao projetar uma interface, pergunte:

- Posso reduzir o número de métodos?
- Posso simplificar os parâmetros?
- Posso esconder mais complexidade por dentro?

## Princípios

- **A profundidade é uma propriedade da interface, não da implementação.** Um módulo profundo pode ser composto internamente de partes pequenas, simuláveis e trocáveis; eles simplesmente não fazem parte da interface. Um módulo pode ter **junções internas** (privadas de sua implementação, usadas por seus próprios testes) bem como a **junção externa** em sua interface.
- **O teste de exclusão.** Imagine excluir o módulo. Se a complexidade desaparecer, foi uma passagem. Se a complexidade reaparecer entre N chamadores, ela estará ganhando seu sustento.
- **A interface é a superfície de teste.** Chamadores e testes cruzam a mesma linha. Se você quiser testar *além* da interface, o módulo provavelmente tem o formato errado.
- **Um adaptador significa uma costura hipotética. Dois adaptadores significam um adaptador real. ** Não introduza uma costura, a menos que algo realmente varie nela.

## Projetando para testabilidade

Boas interfaces tornam os testes naturais:

1. **Aceite dependências, não as crie.**

   ```typescript
   // Testable
   function processOrder(order, paymentGateway) {}

   // Hard to test
   function processOrder(order) {
     const gateway = new StripeGateway();
   }
   ```

2. **Retorna resultados, não produz efeitos colaterais.**

   ```typescript
   // Testable
   function calculateDiscount(cart): Discount {}

   // Hard to test
   function applyDiscount(cart): void {
     cart.total -= discount;
   }
   ```

3. **Pequena área de superfície.** Menos métodos = menos testes necessários. Menos parâmetros = configuração de teste mais simples.

## Relacionamentos

- Um **Módulo** possui exatamente uma **Interface** (a superfície que ele apresenta aos chamadores e testes).
- **Profundidade** é uma propriedade de um **Módulo**, medida em relação à sua **Interface**.
- Uma **Seam** é onde reside a **Interface** de um **Módulo**.
- Um **Adaptador** fica em uma **Costura** e satisfaz a **Interface**.
- **Profundidade** produz **Alavancagem** para chamadores e **Localidade** para mantenedores.

## Enquadramentos rejeitados

- **Profundidade como proporção entre linhas de implementação e linhas de interface** (Ousterhout): recompensas que complementam a implementação. Em vez disso, usamos profundidade como alavancagem.
- **"Interface" como a palavra-chave TypeScript `interface` ou métodos públicos de uma classe**: muito estreito: a interface aqui inclui todos os fatos que um chamador deve saber.
- **"Boundary"**: sobrecarregado com o contexto limitado do DDD. Diga **costura** ou **interface**.

## Indo mais fundo

- **Aprofundando um cluster de acordo com suas dependências**, consulte [DEEPENING.md](DEEPENING.md): categorias de dependência, disciplina de costura e testes de substituição e não camada.
- **Explorando interfaces alternativas**, consulte [DESIGN-IT-TWICE.md](DESIGN-IT-TWICE.md): crie subagentes paralelos para projetar a interface de várias maneiras radicalmente diferentes e, em seguida, compare a profundidade, a localização e o posicionamento da junção.