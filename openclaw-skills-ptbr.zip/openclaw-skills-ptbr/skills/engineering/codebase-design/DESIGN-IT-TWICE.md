# Projete duas vezes

Quando o usuário quiser explorar interfaces alternativas para um candidato de aprofundamento escolhido, use este padrão de subagente paralelo. Baseado em "Design It Twice" (Ousterhout): é improvável que sua primeira ideia seja a melhor.

Usa o vocabulário em [SKILL.md](SKILL.md): **módulo**, **interface**, **costura**, **adaptador**, **alavancagem**.

## Processo

### 1. Enquadre o espaço do problema

Antes de gerar subagentes, escreva uma explicação voltada ao usuário sobre o espaço do problema para o candidato escolhido:

- As restrições que qualquer nova interface precisaria satisfazer
- As dependências nas quais ela dependeria e em qual categoria elas se enquadram (consulte [DEEPENING.md](DEEPENING.md))
- Um esboço de código ilustrativo para fundamentar as restrições, não uma proposta, apenas uma maneira de tornar as restrições concretas

Mostre isso ao usuário e prossiga imediatamente para a Etapa 2. O usuário lê e pensa enquanto os subagentes trabalham em paralelo.

### 2. Gerar subagentes

Gere mais de 3 subagentes em paralelo. Cada um deve produzir uma interface **radicalmente diferente** para o módulo aprofundado.

Solicite a cada subagente um resumo técnico separado (caminhos de arquivo, detalhes de acoplamento, categoria de dependência de [DEEPENING.md](DEEPENING.md), o que fica por trás da costura). O resumo é independente da explicação do espaço do problema voltada para o usuário na Etapa 1. Dê a cada agente uma restrição de design diferente:

- Agente 1: "Minimize a interface: busque no máximo 1–3 pontos de entrada. Maximize a alavancagem por ponto de entrada."
- Agente 2: "Maximizar a flexibilidade: oferecer suporte a muitos casos de uso e extensão."
- Agente 3: "Otimize para o chamador mais comum: torne o caso padrão trivial."
- Agente 4 (se aplicável): "Projete em torno de portas e adaptadores para dependências cruzadas."

Inclua o vocabulário [SKILL.md](SKILL.md) e o vocabulário CONTEXT.md no briefing para que cada subagente nomeie as coisas de forma consistente com a linguagem da arquitetura e a linguagem de domínio do projeto.

Cada subagente gera:

1. Interface (tipos, métodos, parâmetros, além de invariantes, ordenação, modos de erro)
2. Exemplo de uso mostrando como os chamadores o utilizam
3. O que a implementação esconde por trás da costura
4. Estratégia de dependência e adaptadores (consulte [DEEPENING.md](DEEPENING.md))
5. Trade-offs: onde a alavancagem é alta, onde é fraca

### 3. Apresente e compare

Apresente os designs sequencialmente para que o usuário possa absorver cada um deles e depois compare-os em prosa. Compare por **profundidade** (alavancagem na interface), **localidade** (onde a mudança se concentra) e **colocação de costura**.

Depois de comparar, dê sua própria recomendação: qual design você acha mais forte e por quê. Se elementos de designs diferentes combinarem bem, proponha um híbrido. Seja opinativo: o usuário quer uma leitura forte, não um menu.