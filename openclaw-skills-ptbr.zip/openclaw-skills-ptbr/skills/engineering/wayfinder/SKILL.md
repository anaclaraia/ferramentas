---
name: wayfinder
description: planeje uma grande parte do trabalho (mais de uma sessão de agente pode conter) como um mapa compartilhado de tickets de decisão em seu rastreador de problemas e resolva-os um de cada vez até que o caminho para o destino esteja livre.
disable-model-invocation: true
---

Chegou uma ideia vaga, grande demais para uma sessão de agente e envolta em névoa: o caminho daqui até o **destino** ainda não está visível. Wayfinding é encontrar esse caminho, não cobrar no destino. Essa habilidade traça o caminho como um **mapa compartilhado** no rastreador de problemas do repositório e, em seguida, trabalha seus **tíquetes de decisão** (questões cuja resolução é uma decisão, não partes de uma construção a serem executadas), uma de cada vez, até que a rota esteja clara.

O destino varia de acordo com o esforço, e nomeá-lo é o primeiro ato de mapeamento: ele molda cada passagem. Pode ser uma especificação a ser entregue e iterada, uma decisão de bloqueio antes do início do planejamento ou uma mudança feita como uma migração de estrutura de dados. O mapa é independente de domínio: trabalho de engenharia, conteúdo do curso, qualquer que seja o formato.

## Planeje, não faça

O Wayfinder está **planejando** por padrão: cada ticket resolve uma decisão, e o mapa é feito quando o caminho está livre, sem mais nada para decidir antes que alguém vá e faça a coisa. A atração para apenas fazer o trabalho geralmente é o sinal de que você alcançou o limite do mapa e é hora de entregar. Um esforço pode substituir isso em suas **Notas**, transportando a execução para o próprio mapa, mas na ausência disso, produzirá decisões, não resultados.

## Consulte pelo nome

Cada mapa e bilhete é um problema, por isso tem um **nome**: seu título. Em tudo o que o humano lê (narração, as decisões do mapa até agora), refira-se a ele por esse nome, nunca por um simples id, número ou slug. Uma parede de `#42, #43, #44` está ilegível; nomes lidos de relance. O id e o URL não desaparecem; um nome envolve seu link, mas eles andam _dentro_ do nome, nunca o substituem.

## O mapa

O mapa é um problema único no rastreador de problemas deste repositório, denominado `wayfinder:map`, o artefato canônico. Seus tickets são questões filhas do mapa.

O mapa é um **índice**, não uma loja. Ele lista as decisões tomadas e aponta os tickets que contêm seus detalhes; uma decisão reside exatamente em um lugar, seu bilhete, de modo que o mapa nunca a reafirma, apenas a resume e vincula.

**O local onde o mapa, seus tickets secundários, bloqueios e consultas de fronteira residem fisicamente é específico do rastreador.** O rastreador de problemas deveria ter sido fornecido a você. Caso contrário, diga ao usuário para executar `/setup-matt-pocock-skills`. Consulte a seção "Operações de orientação" do documento rastreador para saber como _este_ repositório as expressa. Se nenhum rastreador tiver sido fornecido, o padrão será o rastreador de redução local.

### O corpo do mapa

O mapa inteiro em baixa resolução, carregado uma vez por sessão. Tickets abertos **não** estão listados: são problemas secundários abertos, encontrados por consulta.

```markdown
## Destination

<what reaching the end of this map looks like: the spec, decision, or change this effort is finding its way to. One or two lines; every session orients to it before choosing a ticket.>

## Notes

<domain; skills every session should consult; standing preferences for this effort>

## Decisions so far

<!-- the index: one line per closed ticket, enough to judge relevance, then zoom the link for the detail the ticket holds -->

- [<closed ticket title>](link): <one-line gist of the answer>

## Not yet specified

<!-- see "Fog of war": in-scope fog you can't ticket yet; graduates as the frontier advances -->

## Out of scope

<!-- see "Out of scope": work ruled beyond the destination; closed, never graduates -->
```

### Ingressos

Cada bilhete é uma **edição secundária** do mapa; o ID do problema do rastreador é sua identidade. Seu corpo é a pergunta, dimensionada para uma sessão de agente de token de 100 mil:

```markdown
## Question

<the decision or investigation this ticket resolves>
```

Cada bilhete carrega uma etiqueta `wayfinder:<type>`, uma de `research`, `prototype`, `grilling`, `task` (ver [Ticket Types](#ticket-types)).

Uma sessão **reivindica** um ticket atribuindo-o ao desenvolvedor que dirige o mapa, **primeiro**, antes de qualquer trabalho, portanto, sessões simultâneas o ignoram. Esse destinatário _é_ a reivindicação: um ticket aberto e não atribuído não é reivindicado.

O bloqueio usa o relacionamento de dependência **nativo** do rastreador: essencial porque renderiza a fronteira _visualmente_ na própria interface do rastreador, para que o humano veja o que pode ser obtido sem abrir o mapa. Somente um rastreador que não possui bloqueio nativo recorre a uma convenção corporal. Um ticket é **desbloqueado** quando todos os tickets que o bloqueiam são fechados; a **fronteira** são as crianças abertas, desbloqueadas e não reclamadas, o limite do conhecido.

A resposta não faz parte do corpo; é gravado em resolução (consulte [Work through the map](#work-through-the-map)). Os ativos criados durante a resolução de um ticket são vinculados ao problema e não colados.

## Tipos de ingressos

Cada ticket é **HITL** (humano no circuito, trabalhado _com_ um humano que fala por si) ou **AFK**, conduzido apenas pelo agente. Um ticket HITL só é resolvido por meio dessa troca ao vivo; o agente nunca representa o lado humano (um agente questionador que responde às suas próprias perguntas quebrou isso).

- **Pesquisa** (AFK): leitura de documentação, APIs de terceiros ou recursos locais, como bases de conhecimento, para revelar um fato que uma decisão aguarda. Resolvido por um subagente que chama a ferramenta Skill com “pesquisa”. Use quando for necessário conhecimento fora do diretório de trabalho atual.
- **Protótipo** (HITL): Aumente a fidelidade da discussão criando um artefato barato, bruto e concreto para reagir (um esboço, uma versão aproximada, um esboço ou código UI/lógico) chamando a ferramenta Skill com "protótipo". Vincula o protótipo como um ativo. Use quando "como deveria ser" ou "como deveria se comportar" for a questão principal.
- **Grelhados** (HITL): Conversa. O caso padrão. Sempre ative a skill duas vezes, para "grilling" e "modelagem de domínio".
- **Tarefa** (HITL ou AFK): Trabalho manual que deve acontecer antes que uma _decisão_ possa ser tomada: nada para decidir, prototipar ou pesquisar, mas a discussão fica bloqueada até que seja feita. Inscrever-se em um serviço para que sua API possa ser avaliada, provisionar acesso, mover dados para que seu formato possa ser visto. Este é o tipo que _faz_ em vez de decidir, e ganha o seu lugar ao desbloquear uma decisão e não ao entregar o destino. O agente dirige sozinho onde pode (AFK); caso contrário, entrega ao ser humano uma lista de verificação precisa (HITL). Resolvido quando o trabalho estiver concluído; a resposta registra o que foi feito e quaisquer fatos resultantes (localização de credenciais, novos URLs, contagens de linhas) dos quais os tickets posteriores dependem.

## Névoa de guerra

O mapa está _deliberadamente_ incompleto: não mapeie o que você ainda não pode ver. Além dos ingressos ao vivo está a **névoa da guerra**: a visão turva de decisões e investigações que você pode dizer que estão chegando, mas ainda não consegue definir, porque elas dependem de questões ainda em aberto. A resolução de um bilhete dissipa a névoa à sua frente, graduando o que for agora especificável em novos bilhetes, um de cada vez, até que o caminho para o destino esteja limpo e não restem mais bilhetes.

A seção **Ainda não especificada** do mapa é onde essa visão obscura é anotada: a pergunta suspeita, a área a ser revisitada mais tarde. É a fronteira não descoberta em direção ao destino: tudo aqui está dentro do escopo, mas não é preciso o suficiente para ser multado. Escreva de forma tão livre ou completa quanto a visualização permitir; funciona como uma placa de sinalização para os colaboradores lerem para onde o esforço está indo.

**Nevoeiro ou bilhete?** O teste consiste em saber se você consegue formular a pergunta com precisão agora, _não_ se consegue respondê-la agora.

- **Ticket quando** a pergunta já está afiada, mesmo que esteja bloqueada e você ainda não possa agir.
- **Ainda não especificado quando** você ainda não consegue formular isso de forma tão precisa. Não corte previamente a névoa em pedaços do tamanho de um bilhete: ela é mais grosseira do que um bilhete, e uma mancha pode formar vários bilhetes, ou nenhum, quando a fronteira chegar até ela.

**Ainda não especificado** exclui o que já foi decidido (decisões até agora), o que já é um ticket ativo e o que está fora do escopo (a próxima seção).

## Fora do escopo

A neblina só se acumula _em direção_ ao destino. O destino fixa o escopo, então trabalhar além dele está **fora do escopo**: não é neblina e não pertence a **Ainda não especificado**. Ele recebe sua própria seção **Fora do escopo** no mapa: trabalho que você descartou conscientemente deste esforço. O escopo, não a nitidez, chega aqui.

O trabalho fora do escopo nunca se forma (a fronteira para no destino), portanto ele só retorna se o destino for redesenhado e, então, como um novo esforço, não como uma retomada.

Declarar algo fora do escopo é um ato de definição do escopo, não um passo no caminho. Quando um ticket que já existe passa do destino (com escopo incorreto durante o mapeamento ou exposto por uma resolução), **feche-o** (um ticket fechado está inequivocamente fora da fronteira) e deixe uma linha na seção **Fora do escopo**: a essência e por que está fora do escopo, vinculando o ticket fechado. Fica fora de **Decisões até o momento**, que registra o trajeto efetivamente percorrido; um limite de escopo não é um passo nele.

## Invocação

Dois modos. De qualquer forma, **nunca resolva mais de um ticket por sessão**, com exceção de tickets de pesquisa.

### Trace o mapa

O usuário invoca com uma ideia vaga.

1. **Dê um nome ao destino.** Chame a habilidade duas vezes, para "examinar" e "modelagem de domínio", para definir o que esse mapa está alcançando: a especificação, a decisão ou a mudança. O destino fixa o escopo, então é definido primeiro.
2. **Mapeie a fronteira.** Grelhe novamente, **ampliando primeiro** desta vez: espalhe-se por todo o espaço, em vez de se aprofundar em qualquer tópico, trazendo à tona as decisões abertas e os primeiros passos que podem ser dados agora. **Se não houver neblina** (o caminho para o destino já está livre, a viagem inteira é pequena o suficiente para uma sessão), você não precisa de um mapa. Pare e pergunte ao usuário como ele gostaria de proceder.
3. **Crie o mapa** (etiqueta `wayfinder:map`): Destino e Notas preenchidos, Decisões até agora vazias, a neblina esboçada em **Ainda não especificada**.
4. **Crie os tickets que você pode especificar agora** como problemas secundários do mapa e, em seguida, conecte as bordas de bloqueio em uma **segunda passagem** (os problemas precisam de IDs antes de poderem fazer referência uns aos outros). A fiação os classifica em fronteira e bloqueado; tudo o que você ainda não pode especificar permanece na névoa: a seção **Ainda não especificado**.
5. **Dispare os subagentes de pesquisa.** Para cada ticket `research` que você acabou de criar, acione um subagente que ative a skill com "pesquisa" para resolvê-lo em paralelo, capturando suas descobertas em uma ramificação `research/<name>` descartável com um ponteiro de contexto do ticket.
6. Pare: traçar gráficos é trabalho de uma sessão; não resolve nada manualmente.

### Trabalhe no mapa

O usuário invoca com um mapa (URL ou número). Um ticket é **opcional**: sem ele, você escolhe a próxima decisão, não o usuário.

1. Carregue o **mapa**: a visualização em baixa resolução, não todo o corpo do ticket.
2. Escolha o ingresso. Se o usuário nomeou um, use-o. Caso contrário, pegue o primeiro bilhete de fronteira em ordem. **Reivindicar**: atribua-o a você mesmo antes de qualquer trabalho.
3. Resolva. **Amplie conforme necessário**: obtenha o corpo completo de qualquer ticket relacionado ou fechado sob demanda; chame a habilidade para quaisquer habilidades com os nomes dos blocos `## Notes`. Em caso de dúvida, ative a skill duas vezes, para "grilling" e "modelagem de domínio".
4. Registre a resolução: poste a resposta como um **comentário de resolução**, **feche** o problema e **anexe um ponteiro de contexto** às Decisões até agora do mapa.
5. Adicione tickets recém-surgidos (create-then-wire); graduar qualquer névoa que a resposta tenha tornado especificável, limpando cada patch graduado de **Ainda não especificado** para que ele viva apenas como seu novo ticket. Se a resposta revelar que um bilhete (este ou outro) está além do destino, **descarte-o fora do escopo** em vez de resolvê-lo na rota. Se a decisão invalidar outras partes do mapa, atualize ou exclua esses tickets.

O usuário pode executar tickets desbloqueados em paralelo, portanto, espere que outras sessões editem o rastreador simultaneamente.