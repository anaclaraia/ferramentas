---
name: improve-codebase-architecture
description: analise uma base de código para aprofundar as oportunidades, apresente-as como um relatório HTML visual e, em seguida, analise o que você escolher.
disable-model-invocation: true
---

# Melhorar a arquitetura da base de código

Revele o atrito arquitetônico e proponha **oportunidades de aprofundamento**: refatoradores que transformam módulos superficiais em módulos profundos. O objetivo é testabilidade e navegabilidade por IA.

Este comando é _informado_ pelo modelo de domínio do projeto e construído em um vocabulário de design compartilhado:

- Ative a skill com "codebase-design" para o vocabulário de arquitetura (**módulo**, **interface**, **profundidade**, **seam**, **adapter**, **leverage**, **locality**) e seus princípios (o teste de exclusão, "a interface é a superfície de teste", "um adaptador = costura hipotética, dois = real"). Use esses termos exatamente em todas as sugestões e não se limite a "componente", "serviço", "API" ou "limite".
- A linguagem de domínio em `CONTEXT.md` dá nomes a boas costuras; ADRs em decisões de registro `docs/adr/` este comando não deve litigar novamente.

## Processo

### 1. Explorar

**Escopo antes de digitalizar: YAGNI.** Aprofundar um módulo compensa, pois torna mais fáceis alterações futuras nele, portanto, coloque peso extra nas partes da base de código que foram alteradas recentemente. Decida *onde* procurar antes de olhar:

- Se o usuário nomeou uma direção (um módulo, um subsistema, um ponto problemático), siga-a e pule a inferência abaixo.
- Caso contrário, volte um bom trecho do histórico de commits (`git log --oneline`) para encontrar os pontos de acesso da base de código, os arquivos e áreas que continuam surgindo, e deixe esses caminhos chamarem sua atenção primeiro. Se as mudanças estiverem dispersas sem nenhum ponto de acesso claro, amplie a rede.

Leia primeiro o glossário de domínio do projeto (`CONTEXT.md`) e quaisquer ADRs na área que você está tocando.

Em seguida, crie um subagente para percorrer a base de código. Não siga heurísticas rígidas; explore organicamente e observe onde você experimenta atrito:

- Onde a compreensão de um conceito exige alternar entre vários módulos pequenos?
- Onde estão os módulos **superficiais**, com uma interface quase tão complexa quanto a implementação?
- Onde as funções puras foram extraídas apenas para testabilidade, mas os bugs reais se escondem na forma como são chamadas (sem **localidade**)?
- Onde os módulos fortemente acoplados vazam pelas costuras?
- Quais partes da base de código não foram testadas ou são difíceis de testar por meio da interface atual?

Aplique o **teste de exclusão** a qualquer coisa que você suspeite ser superficial: excluí-lo concentraria a complexidade ou apenas o moveria? Um “sim, concentrado” é o sinal que você deseja.

### 2. Apresente os candidatos como um relatório HTML

Grave um arquivo HTML independente no diretório temporário do sistema operacional para que nada chegue ao repositório. Resolva o diretório temporário de `$TMPDIR`, voltando para `/tmp` (ou `%TEMP%` no Windows) e grave em `<tmpdir>/architecture-review-<timestamp>.html` para que cada execução obtenha um arquivo novo. Abra-o para o usuário (`xdg-open <path>` no Linux, `open <path>` no macOS, `start <path>` no Windows) e informe o caminho absoluto.

O relatório usa **Tailwind via CDN** para layout e estilo, e **Mermaid via CDN** para diagramas onde um gráfico/fluxo/sequência comunica a estrutura de maneira confiável. Misture Mermaid com visuais CSS/SVG feitos à mão: use Mermaid quando os relacionamentos são em forma de gráfico (chamar gráficos, dependências, sequências) e divs/SVG feitos à mão quando quiser algo mais editorial (diagramas de massa, seções transversais, animações de colapso). Cada candidato recebe uma **visualização antes/depois**. Seja visual.

Para cada candidato, renderize um cartão com:

- **Arquivos**: quais arquivos/módulos estão envolvidos
- **Problema**: por que a arquitetura atual está causando atrito
- **Solução**: descrição simples em inglês do que mudaria
- **Benefícios**: explicados em termos de localidade e alavancagem, e como os testes melhorariam
- **Diagrama Antes / Depois**: lado a lado, desenhado sob medida, ilustrando a superficialidade e o aprofundamento
- **Força da recomendação**: um de `Strong`, `Worth exploring`, `Speculative`, renderizado como um emblema

Termine o relatório com uma seção de **Recomendações principais**: qual candidato você abordaria primeiro e por quê.

**Use o vocabulário CONTEXT.md para o domínio e o vocabulário `/codebase-design` para a arquitetura.** Se `CONTEXT.md` definir "Pedido", fale sobre "o módulo de recebimento de pedidos", não sobre "o FooBarHandler" e não sobre "o serviço de pedidos".

**Conflitos de ADR**: se um candidato contradizer um ADR existente, apenas o revele quando o atrito for real o suficiente para justificar a revisão do ADR. Marque claramente no cartão (por exemplo, um aviso: _"contradiz ADR-0007, mas vale a pena reabrir porque…"_). Não liste todos os refatoradores teóricos que uma ADR proíbe.

Consulte [HTML-REPORT.md](HTML-REPORT.md) para obter o andaime HTML completo, padrões de diagrama e orientações de estilo.

NÃO proponha interfaces ainda. Após a gravação do arquivo, pergunte ao usuário: "Qual destes você gostaria de explorar?"

### 3. Loop de grelhar

Assim que o usuário escolher um candidato, ative a skill com "grilling" para percorrer a árvore de decisão com ele: restrições, dependências, a forma do módulo aprofundado, o que fica atrás da costura, quais testes sobrevivem.

Os efeitos colaterais acontecem à medida que as decisões se cristalizam; ative a skill com "modelagem de domínio" para manter o modelo de domínio atualizado conforme você avança:

- **Nomeando um módulo aprofundado com base em um conceito que não está em `CONTEXT.md`?** Adicione o termo a `CONTEXT.md`. Crie o arquivo preguiçosamente se ele não existir.
- **Aprimorando um termo confuso durante a conversa?** Atualize `CONTEXT.md` ali mesmo.
- **O usuário rejeita o candidato com um motivo de suporte?** Ofereça um ADR, enquadrado como: _"Quer que eu registre isso como um ADR para que futuras revisões de arquitetura não o sugiram novamente?"_ Ofereça apenas quando o motivo for realmente necessário para um futuro explorador para evitar sugerir novamente a mesma coisa; pule os motivos efêmeros (“não vale a pena agora”) e os evidentes.
- **Deseja explorar interfaces alternativas para o módulo aprofundado?** Ative a skill com "codebase-design" e use seu padrão de subagente paralelo design-it-twice.