# Formato de relatório HTML

A revisão arquitetural é renderizada como um único arquivo HTML independente no diretório temporário do sistema operacional. Tailwind e Mermaid vêm de CDNs. Mermaid lida com diagramas em formato de gráfico de maneira confiável; divs feitos à mão e SVG embutidos lidam com os visuais mais editoriais (diagramas de massa, seções transversais). Misture os dois: não confie no Mermaid para tudo, vai começar a parecer genérico.

## Andaime

```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Architecture review for {{repo name}}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script type="module">
      import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
      mermaid.initialize({ startOnLoad: true, theme: "neutral", securityLevel: "loose" });
    </script>
    <style>
      /* small custom layer for things Tailwind doesn't cover cleanly:
         dashed seam lines, hand-drawn-feeling arrow heads, etc. */
      .seam { stroke-dasharray: 4 4; }
      .leak { stroke: #dc2626; }
      .deep { background: linear-gradient(135deg, #0f172a, #1e293b); }
    </style>
  </head>
  <body class="bg-stone-50 text-slate-900 font-sans">
    <main class="max-w-5xl mx-auto px-6 py-12 space-y-12">
      <header>...</header>
      <section id="candidates" class="space-y-10">...</section>
      <section id="top-recommendation">...</section>
    </main>
  </body>
</html>
```

## Cabeçalho

Nome do repositório, data e uma legenda compacta: caixa sólida = módulo, linha tracejada = costura, seta vermelha = vazamento, caixa escura grossa = módulo profundo. Nenhum parágrafo de introdução. Direto para os candidatos.

## Cartão de candidato

Os diagramas carregam o peso. A prosa é esparsa, simples e usa os termos do glossário (da habilidade `/codebase-design`) sem cerimônia.

Cada candidato é um `<article>`:

- **Título**: abreviado, nomeia o aprofundamento (ex.: “Recolher o pipeline de recebimento de pedidos”).
- **Linha do selo**: força da recomendação (`Strong` = esmeralda, `Worth exploring` = âmbar, `Speculative` = ardósia), mais uma tag para a categoria de dependência (`in-process`, `local-substitutable`, `ports & adapters`, `mock`).
- **Arquivos**: lista monoespaçada, `font-mono text-sm`.
- **Diagrama Antes / Depois**: a peça central. Duas colunas, lado a lado. Veja os padrões abaixo.
- **Problema**: uma frase. O que dói.
- **Solução**: uma frase. O que muda.
- **Vitórias**: marcadores, ≤6 palavras cada. por exemplo "Os testes atingiram uma interface", "A lógica de preços para de vazar", "Excluir 4 wrappers superficiais".
- **Chamada ADR** (se aplicável): uma linha em uma caixa âmbar.

Sem parágrafos de explicação. Se o diagrama precisar de um parágrafo para ser compreendido, redesenhe-o.

## Padrões de diagrama

Escolha o padrão que se adapta ao candidato. Misture-os. Não faça com que todos os diagramas pareçam iguais. A variedade faz parte da questão.

### Gráfico Mermaid (o carro-chefe para dependências/fluxo de chamadas)

Use uma Sereia `flowchart` ou `graph` quando o ponto for "X chama Y chama Z e veja a bagunça." Embrulhe-o em um cartão estilo Tailwind para que não pareça ter caído de pára-quedas. Estilize com classDef para colorir as bordas de vazamento de vermelho e o módulo profundo de escuro. Os diagramas de sequência funcionam bem para “antes: 6 viagens de ida e volta; depois: 1”.

```html
<div class="rounded-lg border border-slate-200 bg-white p-4">
  <pre class="mermaid">
    flowchart LR
      A[OrderHandler] --> B[OrderValidator]
      B --> C[OrderRepo]
      C -.leak.-> D[PricingClient]
      classDef leak stroke:#dc2626,stroke-width:2px;
      class C,D leak
  </pre>
</div>
```

### Caixas e flechas feitas à mão (quando o layout da Sereia luta contra você)

Módulos como `<div>`s com bordas e etiquetas. Setas como elementos SVG `<line>` ou `<path>` embutidos posicionados absolutamente sobre um contêiner relativo. Use isso quando quiser que o diagrama "depois" pareça um módulo profundo com bordas grossas e partes internas acinzentadas, já que o Mermaid não renderizará isso com o peso certo.

### Seção transversal (boa para camadas superficiais)

Empilhe faixas horizontais (`h-12 border-l-4`) para mostrar as camadas pelas quais uma chamada passa. Antes: 6 camadas finas, cada uma sem fazer nada. Depois: 1 faixa grossa etiquetada com a responsabilidade consolidada.

### Diagrama de massa (bom para "interface tão ampla quanto a implementação")

Dois retângulos por módulo: um para área de superfície de interface e outro para implementação. Antes: o retângulo da interface é quase tão alto quanto o retângulo de implementação (raso). Depois: o retângulo da interface é curto, o retângulo de implementação é alto (profundo).

### Colapso do gráfico de chamadas

Antes: uma árvore de chamadas de função renderizadas como caixas aninhadas. Depois: a mesma árvore desabou em uma caixa, com as chamadas agora internas mostradas desbotadas dentro dela.

## Orientação de estilo

- Editorial enxuto, não painel corporativo. Espaço em branco generoso. Serif opcional para títulos (`font-serif` funciona bem com pedra/ardósia).
- Cor com moderação: um acento (esmeralda ou índigo) mais vermelho para vazamento e âmbar para avisos.
- Mantenha os diagramas com aproximadamente 320 px de altura para que o antes/depois fique confortavelmente lado a lado sem rolar.
- Use `text-xs uppercase tracking-wider` para rótulos de módulos dentro de diagramas, para que sejam lidos como esquemáticos, não como UI.
- Os únicos scripts são o Tailwind CDN e a importação do Mermaid ESM. O relatório é estático: sem código de aplicativo, sem interatividade além da renderização do próprio Mermaid.

## Seção de recomendação principal

Um cartão maior. Nome do candidato, uma frase explicando o motivo, link âncora para seu cartão. É isso.

## Tom

Inglês simples, conciso, mas os substantivos e verbos arquitetônicos vêm direto da habilidade `/codebase-design`. A concisão não é uma desculpa para ficar à deriva.

**Use exatamente:** módulo, interface, implementação, profundidade, profundo, raso, costura, adaptador, alavancagem, localidade.

**Nunca substitua:** componente, serviço, unidade (para módulo) · API, assinatura (para interface) · limite (para costura) · camada, wrapper (para módulo, quando você quer dizer módulo).

**Frases que combinam com o estilo:**

- "O módulo de recebimento de pedidos é superficial: a interface quase corresponde à implementação."
- "O preço vaza pela costura."
- "Aprofundar: uma interface, um lugar para testar."
- "Dois adaptadores justificam a costura: HTTP em produção, na memória em testes."

**Marcadores de vitórias** nomeiam o ganho em termos de glossário: *"localidade: bugs concentrados em um módulo"*, *"alavancagem: uma interface, N sites de chamada"*, *"interface diminui; implementação absorve os wrappers"*. Não escreva *"mais fácil de manter"* ou *"código mais limpo"*, porque esses termos não estão no glossário e não merecem seu lugar.

Sem cobertura, sem pigarro, sem “vale a pena notar que…”. Se uma frase pode ser uma bala, faça dela uma bala. Se uma bala pudesse ser cortada, corte-a. Se um termo não estiver no glossário `/codebase-design`, procure um que esteja antes de inventar um novo.