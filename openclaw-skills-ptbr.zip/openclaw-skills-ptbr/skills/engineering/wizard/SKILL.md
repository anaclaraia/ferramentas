---
name: wizard
description: Gere um assistente bash interativo que orienta um humano nas etapas que somente ele pode executar. Use ao provisionar infraestrutura, configurar credenciais ou segredos de CI, percorrer um painel de terceiros desconhecido ou executar uma migração ou transferência única. Não invoque isso para etapas que o próprio agente pode executar.
---

# Assistente

Um **assistente** é um script bash que orienta um humano, passo a passo, através de um procedimento manual que é tedioso de fazer manualmente e tedioso de reexplicar para uma IA todas as vezes. Ele abre cada URL, diz exatamente o que clicar e copiar, captura os valores, escreve onde eles pertencem (`.env`, segredos do GitHub), confirma em cada estágio e mostra quantos estágios faltam. Pode configurar serviços de terceiros, executar uma migração única ou mover o projeto de um estado para outro.

A deliciosa UX já foi resolvida por [template.sh](template.sh): progresso estágio por estágio, portas de confirmação, abertura de URL de plataforma cruzada (incluindo WSL), entrada secreta oculta, upserts `.env` idempotentes, gravações `gh secret`/`gh variable` e um resumo final. **Seu trabalho é apenas definir o escopo do procedimento e criar seus estágios.** A biblioteca acima do marcador `STAGES` é idêntica em todos os assistentes; essa consistência é o ponto: nunca edite-o manualmente.

Um assistente é efêmero por padrão: construído para uma execução, salvo em um caminho temporário ou `scripts/`, excluído quando o trabalho é concluído. Confirme-o apenas quando o usuário desejar um caminho de configuração repetível que deve estar no repositório.

## Processo

### 1. Escopo do procedimento

Elabore cada passo manual que o ser humano deve realizar e cada valor que é capturado ao longo do caminho. Leia o repositório primeiro, não pergunte friamente:

- Para configuração: `.env`, `.env.example`, `.env.*`, `README`, `docker-compose*`, configuração de estrutura e `.github/workflows/*` (cada referência `secrets.*` / `vars.*` é um valor que o assistente deve produzir).
- Para uma migração ou transição: o estado atual, o estado alvo e as ações irreversíveis entre eles.

Em seguida, mostre ao usuário a lista ordenada de estágios e os valores que cada um produz e confirme: eles podem adicionar, descartar ou reordenar.

**Feito quando:** cada estágio é nomeado em ordem, e para cada valor capturado você sabe (a) onde o humano o obtém, (b) onde está escrito (`.env`, um segredo do GitHub, ambos, ou nenhum lugar; alguns estágios são ações puras) e (c) se é secreto (entrada oculta) ou público.

### 2. Mapeie a jornada de cada etapa

Para cada estágio, escreva o caminho preciso que um ser humano segue: qual URL abrir, o que fazer lá, onde um valor é mostrado, qual variável ele preenche: por exemplo. "Painel → Desenvolvedores → Chaves de API → Revelar chave de teste → copiar". Se você realmente não conhece a IU atual ou o comando exato, diga-o e pergunte ao usuário ou verifique a documentação: nunca invente etapas que podem não existir.

**Feito quando:** cada estágio segue instruções concretas que um estranho poderia seguir.

### 3. Crie o assistente

Copie `template.sh` para o caminho de destino. Substitua o estágio de exemplo por um `stage` por etapa, em ordem de dependência. Use os auxiliares de biblioteca: `stage`, `say`/`step`, `open_url`, `ask`/`ask_secret`, `write_env`, `set_secret`/`set_var`, `pause`/`confirm`. Defina `TOTAL_STAGES` com o número de estágios que você escreveu.

Segure a barra que o modelo define: abra a URL antes de solicitar seu valor, use `ask_secret` para qualquer coisa secreta, `write_env` para todos os valores persistentes, `set_secret` apenas para os valores que CI realmente precisa e `confirm` antes de qualquer ação irreversível. Cada `stage` limpa a tela para que apenas a etapa atual fique visível: mantenha um estágio em uma tarefa focada para que nada que o ser humano precise seja eliminado. Não toque na biblioteca acima do marcador.

### 4. Verifique e entregue

- `bash -n <script>`; execute `shellcheck` se disponível.
- `chmod +x <script>`.
- Não execute você mesmo de ponta a ponta: ele abre navegadores e bloqueia a entrada humana. Em vez disso, rastreie-o estaticamente: cada valor da etapa 1 é capturado e chega onde a etapa 1 disse, e cada nome `set_secret` corresponde exatamente a uma referência `secrets.*` no CI.
- Diga ao usuário como executá-lo. Se for um caminho de configuração repetível, confirme-o e vincule-o no README para que a próxima pessoa execute o script em vez de solicitar a uma IA.