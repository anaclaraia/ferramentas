---
name: grill-with-docs
description: Uma entrevista incansável para aprimorar um plano ou design, que também cria documentos (ADR e glossário) à medida que avançamos.
disable-model-invocation: true
---

Ative a skill duas vezes, para "grilling" e "modelagem de domínio".