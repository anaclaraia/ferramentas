---
name: research
description: investigue uma questão em fontes primárias de alta confiança e capture as descobertas como um arquivo Markdown no repositório. Use quando o usuário deseja que um tópico seja pesquisado, documentos ou fatos de API coletados ou leitura de trabalho braçal delegado a um agente em segundo plano.
---

Contrate um **agente de apoio** para fazer a pesquisa, para que você continue trabalhando enquanto lê.

Seu trabalho:

1. Investigue a questão em relação a **fontes primárias** (documentos oficiais, código-fonte, especificações, APIs próprias), e não a um relato secundário delas. Siga cada reivindicação até a fonte que a possui.
2. Escreva as descobertas em um único arquivo Markdown, citando a fonte de cada afirmação.
3. Salve onde o repo já guarda essas notas; corresponda à convenção existente e, se não houver nenhuma, coloque-a em algum lugar sensato e diga onde.