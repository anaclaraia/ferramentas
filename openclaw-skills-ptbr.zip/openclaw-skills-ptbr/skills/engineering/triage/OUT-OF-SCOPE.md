# Base de conhecimento fora do escopo

O diretório `.out-of-scope/` em um repositório armazena registros persistentes de solicitações de recursos rejeitadas. Serve a dois propósitos:

1. **Memória institucional**: por que um recurso foi rejeitado, para que o raciocínio não se perca quando o problema for encerrado
2. **Desduplicação**: quando surge um novo problema que corresponde a uma rejeição anterior, a habilidade pode trazer à tona a decisão anterior em vez de litigá-la novamente

## Estrutura de diretório

```
.out-of-scope/
├── dark-mode.md
├── plugin-system.md
└── graphql-api.md
```

Um arquivo por **conceito**, não por edição. Vários problemas que solicitam a mesma coisa são agrupados em um arquivo.

## Formato do arquivo

O arquivo deve ser escrito em um estilo descontraído e legível, mais parecido com um pequeno documento de design do que com uma entrada de banco de dados. Use parágrafos, exemplos de código e exemplos para tornar o raciocínio claro e útil para alguém que o encontra pela primeira vez.

```markdown
# Dark Mode

This project does not support dark mode or user-facing theming.

## Why this is out of scope

The rendering pipeline assumes a single color palette defined in
`ThemeConfig`. Supporting multiple themes would require:

- A theme context provider wrapping the entire component tree
- Per-component theme-aware style resolution
- A persistence layer for user theme preferences

This is a significant architectural change that doesn't align with the
project's focus on content authoring. Theming is a concern for downstream
consumers who embed or redistribute the output.

```ts
// A interface ThemeConfig atual não foi projetada para alternância de tempo de execução:
interface ThemeConfig {
  cores: ColorPalette; // paleta única, resolvida em tempo de construção
  fontes: FontStack;
}
```

## Prior requests

- #42: "Add dark mode support"
- #87: "Night theme for accessibility"
- #134: "Dark theme option"
```

### Nomeando o arquivo

Use um nome curto e descritivo para o conceito: `dark-mode.md`, `plugin-system.md`, `graphql-api.md`. O nome deve ser reconhecível o suficiente para que alguém que esteja navegando no diretório entenda o que foi rejeitado sem abrir o arquivo.

### Escrevendo o motivo

A razão deve ser substantiva: não “não queremos isto”, mas porquê. Referência de bons motivos:

- Escopo ou filosofia do projeto ("Este projeto se concentra em X; o tema é uma preocupação posterior")
- Restrições técnicas ("Apoiar isto exigiria Y, o que entra em conflito com a nossa arquitetura Z")
- Decisões estratégicas ("Optamos por usar A em vez de B porque...")

A razão deve ser duradoura. Evite fazer referência a circunstâncias temporárias (“estamos muito ocupados agora”); essas não são rejeições reais, são adiamentos.

## Quando verificar `.out-of-scope/`

Durante a triagem (Etapa 1: coletar contexto), leia todos os arquivos em `.out-of-scope/`. Ao avaliar um novo problema:

- Verifique se a solicitação corresponde a um conceito existente fora do escopo
- A correspondência é feita por semelhança de conceito, não por palavra-chave: "tema noturno" corresponde a `dark-mode.md`
- Se houver uma correspondência, mostre ao mantenedor: "Isso é semelhante a `.out-of-scope/dark-mode.md`. Rejeitamos isso antes porque [motivo]. Você ainda sente o mesmo?"

O mantenedor pode:

- **Confirmar**: o novo problema é adicionado à lista de "Solicitações anteriores" do arquivo existente e depois fechado
- **Reconsiderar**: o arquivo fora do escopo é excluído ou atualizado, e o problema prossegue pela triagem normal
- **Discordo**: os problemas estão relacionados, mas distintos, prossiga com a triagem normal

## Quando escrever em `.out-of-scope/`

Somente quando uma **melhoria** (não um bug) é *rejeitada* como `wontfix`. Isso se aplica aos PRs de aprimoramento exatamente como aos problemas: um PR rejeitado é registrado aqui para que a mesma solicitação não retorne como código novo.

**Não** escreva aqui quando algo estiver fechado como `wontfix` porque **já está implementado**. Esse é um recurso construído, não rejeitado; registrá-lo envenenaria as verificações de desduplicação com falsas rejeições. Em vez disso, o comentário final aponta para onde o recurso já existe.

O fluxo:

1. O mantenedor decide que uma solicitação de recurso está fora do escopo
2. Verifique se já existe um arquivo `.out-of-scope/` correspondente
3. Se sim: anexe o novo problema à lista "Solicitações anteriores"
4. Se não: crie um novo arquivo com o nome do conceito, decisão, motivo e primeira solicitação prévia
5. Poste um comentário sobre o assunto explicando a decisão e mencionando o arquivo `.out-of-scope/`
6. Encerre o problema com o rótulo `wontfix`

## Atualizando ou removendo arquivos fora do escopo

Se o mantenedor mudar de ideia sobre um conceito anteriormente rejeitado:

- Exclua o arquivo `.out-of-scope/`
- A habilidade não necessita reabrir questões antigas; são registros históricos
- A nova questão que desencadeou a reconsideração prossegue através da triagem normal