---
name: prototype
description: Construa um protótipo descartável para responder a uma questão de design. Use quando o usuário quiser verificar se um modelo de estado ou lógica parece correto ou explorar a aparência de uma IU.
---

# Protótipo

Um protótipo é um **código descartável que responde a uma pergunta**. A questão decide a forma.

## Escolha um ramo

Identifique qual pergunta está sendo respondida usando o prompt do usuário, o código ao redor ou perguntando se o usuário está por perto:

- **"Este modelo lógico/estado parece correto?"** → [LOGIC.md](LOGIC.md). Crie um único arquivo HTML compartilhável (botões de reprodução gratuita e orientações guiadas com guias) que conduza a máquina de estado através de casos difíceis de raciocinar no papel e que um não-desenvolvedor pode conduzir.
- **"Como deve ser isso?"** → [UI.md](UI.md). Gere diversas variações de UI radicalmente diferentes em uma única rota, alternáveis ​​por meio de um parâmetro de pesquisa de URL e uma barra inferior flutuante.

Os dois ramos produzem artefatos muito diferentes, então errar desperdiça todo o protótipo. Se a pergunta for genuinamente ambígua e o usuário não estiver acessível, use como padrão o branch que melhor corresponda ao código circundante (um módulo de back-end → lógica; uma página ou componente → UI) e indique a suposição na parte superior do protótipo.

## Regras que se aplicam a ambos

1. **Descartável desde o primeiro dia e claramente marcado como tal.** Localize o código do protótipo próximo de onde ele realmente será usado (ao lado do módulo ou página para o qual está sendo prototipado) para que o contexto seja óbvio, mas nomeie-o para que um leitor casual possa ver que é um protótipo, não uma produção. Para rotas de UI descartáveis, obedeça a qualquer convenção de roteamento que o projeto já use; não invente uma nova estrutura de nível superior.
2. **Trivial de executar.** Um protótipo de UI inicia a partir de um comando no executor de tarefas do projeto: `pnpm <name>`, `python <path>`, `bun <path>`, etc. Uma demonstração lógica é um único arquivo HTML no qual o usuário clica duas vezes. De qualquer forma, não é necessário pensar para iniciá-lo.
3. **Sem persistência por padrão.** O estado reside na memória. Persistência é o que o protótipo está _verificando_, não algo de que deveria depender. Se a pergunta envolver explicitamente um banco de dados, acesse um banco de dados temporário ou um arquivo local com um nome claro "PROTÓTIPO, limpe-me".
4. **Esqueça o polimento.** Sem testes, sem tratamento de erros além do que torna o protótipo _executável_, sem abstrações. O objetivo é aprender algo rápido.
5. **Exiba o estado.** Após cada ação (lógica) ou em cada opção de variante (IU), imprima ou renderize o estado relevante completo para que o usuário possa ver o que mudou.
6. **Capture-o quando terminar.** Dobre qualquer decisão validada no código real e, em seguida, capture o próprio protótipo como uma **fonte primária**: envie-o para um branch descartável, fora do principal, e deixe um ponteiro de contexto para esse branch no problema de implementação. Capture a resposta também (o veredicto e a questão resolvida) no problema ou em um commit. A ramificação principal mantém apenas a decisão validada.