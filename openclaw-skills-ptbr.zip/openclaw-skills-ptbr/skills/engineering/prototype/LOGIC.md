# Protótipo Lógico

Um arquivo HTML único e independente (uma **demonstração compartilhável**) que permite que qualquer pessoa conduza um modelo de estado clicando em botões. Use isso quando a pergunta for sobre **lógica de negócios, transições de estado ou formato de dados**: o tipo de coisa que parece razoável no papel, mas só parece errada quando você passa por casos reais.

Como é um arquivo sem nada para instalar, você pode entregá-lo a um não-desenvolvedor (um designer, um PM, um especialista em domínio) e deixá-lo sentir o modelo por si mesmo. Portanto, ele fala a língua deles, não a do código.

## Quando esta é a forma certa

- "Não tenho certeza se esta máquina de estado lida com o caso extremo onde X e depois Y."
- "Este modelo de dados realmente me permite representar o caso em que..."
- "Quero sentir como deve ser a API antes de escrevê-la."
- Qualquer coisa em que alguém queira **pressionar botões e observar a mudança de estado**.

Se a pergunta for "como deveria ser isso", este é o ramo errado. Utilize [UI.md](UI.md).

## Processo

### 1. Faça a pergunta

Antes de escrever o código, anote qual modelo de estado e qual pergunta você está prototipando. Um parágrafo, no topo da demonstração (em uma introdução visível, não apenas em um comentário). Um protótipo lógico que responde à pergunta errada é puro desperdício, então deixe a pergunta explícita para que ela possa ser verificada mais tarde, esteja o usuário assistindo agora ou retornando a ela AFK.

### 2. Isole a lógica em um módulo portátil

Coloque a lógica real (o bit que responde à pergunta) em um único bloco `<script>` escrito como um módulo pequeno e puro que pode ser retirado e colocado na base de código real posteriormente. A página ao redor é descartável; este módulo não é.

A forma correta depende da pergunta:

- **Um redutor puro**: `(state, action) => state`. Bom quando as ações são eventos discretos e o estado é um valor único.
- **Uma máquina de estados**: estados e transições explícitas. Bom quando "quais ações são legais no momento" faz parte da questão.
- **Um pequeno conjunto de funções puras** sobre um tipo de dados simples. Bom quando não há estado atual implícito, apenas transformações.
- **Uma classe ou módulo com uma superfície de método clara** quando a lógica possui genuinamente o estado interno contínuo.

Escolha o formato que melhor se adapta à pergunta feita, *não* o que for mais fácil de conectar a uma página. Mantenha-o puro: sem DOM, sem `document`, sem manipuladores de botões chegando dentro dele. A página chama isso; nada flui na outra direção. Isso é o que torna o protótipo útil após sua própria vida útil: uma vez respondida a pergunta, o conjunto redutor/máquina/função validado passa sozinho para o módulo real.

### 3. Crie o arquivo HTML compartilhável

Um arquivo, HTML/CSS/JS simples: sem estrutura, sem bundler, sem servidor, tudo embutido para que ele abra com um clique duplo e sobreviva ao envio por e-mail. Qualquer pessoa deve ser capaz de executá-lo abrindo-o.

Escreva para um não desenvolvedor. Cada rótulo está em **linguagem de domínio**, não em código: os botões e o estado são lidos como o negócio, não como o redutor. Explique em palavras simples o que está acontecendo.

Organize tudo com uma hierarquia limpa, de cima para baixo:

1. **Título e explicação em uma linha** do que esta demonstração permite explorar (a pergunta da etapa 1).
2. **Estado atual**: o estado relevante completo, renderizado como um painel legível (campos rotulados, não um despejo JSON bruto), renderizado novamente após cada clique para que a alteração fique visível. Onde ajudar um não-desenvolvedor a seguir, diga o que acabou de mudar.
3. **Botões de jogo grátis**: um botão por ação, sempre disponível, para que qualquer pessoa possa cutucar o modelo em qualquer ordem. Cada clique despacha sua ação e renderiza novamente o estado.
4. **Instruções guiadas**: um conjunto de **cenários**, um por guia. Cada guia contém uma breve descrição em linguagem simples do cenário (a situação que ele configura e o que observar) e abaixo dela, os **botões ordenados a serem pressionados** para esse cenário. Cada etapa é um botão real: clicar nele executa essa ação e passa para a próxima etapa. Iniciar um percurso virtual redefine para um estado inicial conhecido para que o cenário seja sempre executado da mesma maneira.

Escolha cenários que demonstrem os casos embaraçosos, aqueles difíceis de raciocinar no papel: o caminho feliz, um caso extremo complicado, uma tentativa de algo que deveria ser ilegal.

Mantenha-o bonito, mas contido: tipografia limpa, espaçamento generoso, uma cor de destaque. Sem animações, sem truques: nada que concorra com o estado e os botões.

### 4. Entregue

Envie-lhes o arquivo ou abra-o para eles. Eles clicarão nas orientações e jogarão gratuitamente sempre que chegarem; os momentos interessantes são quando dizem “espere, isso não deveria ser possível” ou “huh, presumi que X seria diferente”; esses são os bugs da _ideia_, que é o ponto principal. Se quiserem novas ações ou um novo cenário, adicione-os. Os protótipos evoluem.

### 5. Capture a resposta e o protótipo

Depois que o protótipo tiver respondido à sua pergunta, capture a resposta e, em seguida, capture o protótipo da maneira que o [SKILL](SKILL.md) descreve. O mapeamento específico da lógica: o conjunto redutor/máquina/função validado é elevado ao módulo real (a decisão, absorvida); o shell HTML segue até o branch descartável que mantém o protótipo como fonte primária e, sendo um arquivo independente, ele permanece trivialmente reexecutável lá.

## Antipadrões

- **Não adicione testes.** Um protótipo que precisa de testes não é mais um protótipo.
- **Não conecte-o ao banco de dados real.** Use o estado na memória, a menos que a questão seja especificamente sobre persistência.
- **Não generalize.** Não "e se quiséssemos oferecer suporte ao X mais tarde." O protótipo responde a uma pergunta.
- **Não misture a lógica e a página.** Se o módulo puro fizer referência ao DOM, `document` ou manipuladores de botão, ele não poderá mais ser levantado. Mantenha a página como uma casca fina sobre um módulo puro.
- **Não procure uma estrutura, empacotador ou servidor.** Um arquivo no qual o destinatário clica duas vezes; um aplicativo React ou um servidor de desenvolvimento anula o "compartilhável".
- **Não envie o shell HTML para produção.** A página é otimizada para ser clicada manualmente. O módulo lógico por trás dele é o que vale a pena manter.