# Protótipo de IU

Gere **várias variações de UI radicalmente diferentes** em uma única rota, alternável a partir de uma barra inferior flutuante. O usuário alterna entre as variantes no navegador, escolhe uma (ou rouba pedaços de cada uma) e joga o resto fora.

Se a questão for sobre lógica/estado e não sobre a aparência de algo, este é o ramo errado. Utilize [LOGIC.md](LOGIC.md).

## Quando esta é a forma certa

- "Como deve ser esta página?"
- "Quero ver algumas opções para este painel antes de confirmar."
- "Tente um layout diferente para a tela de configurações."
- Sempre que o usuário passaria um dia escolhendo entre três maquetes vagas em sua cabeça.

## Duas subformas: prefira fortemente a subforma A

Um protótipo de UI é muito mais fácil de julgar quando ele **se choca com o resto do aplicativo**: cabeçalho real, barra lateral real, dados reais, densidade real. Uma rota descartável por si só é um vácuo: cada variante parece bem isoladamente. O padrão é a subforma A sempre que houver uma página plausível para hospedar as variantes. Alcance a subforma B apenas se o protótipo realmente não tiver uma casa próxima.

### Subforma A: ajuste a uma página existente (preferencial)

A rota já existe. As variantes são renderizadas **na mesma rota**, controladas por um parâmetro de pesquisa de URL `?variant=`. A busca de dados, parâmetros e autenticação existentes permanecem. Apenas as trocas de renderização. Este é o padrão; escolha-o, a menos que haja um motivo específico para não fazê-lo.

Se o protótipo for para algo que ainda não tem uma página, mas *viveria naturalmente dentro de uma* (uma nova seção do painel, um novo cartão na tela de configurações, uma nova etapa em um fluxo existente), ainda será a subforma A. Monte as variantes dentro da página host.

### Subforma B: uma nova página (último recurso)

Use isso apenas quando o protótipo realmente não tiver nenhuma página existente para residir (por exemplo, uma superfície de nível superior totalmente nova ou um fluxo que não possa ser incorporado em qualquer lugar sensato).

Crie uma **rota descartável** seguindo qualquer convenção de roteamento que o projeto já usa. Não invente uma nova estrutura de nível superior. Dê um nome para que seja obviamente um protótipo (por exemplo, inclua a palavra `prototype` no caminho ou nome do arquivo). Mesmo padrão `?variant=`.

Antes de se comprometer com a subforma B, verifique a sanidade: não existe realmente nenhuma página na qual ela possa ser incorporada? Uma rota vazia esconde problemas de design que uma rota preenchida exporia.

Em ambas as subformas a barra inferior flutuante é idêntica.

## Processo

### 1. Faça a pergunta e escolha N

O padrão é **3 variantes**. Mais de 5 paradas são radicalmente diferentes e começam a ser barulhentas, então limite aí.

Escreva o plano em uma linha, na localização do protótipo ou em um comentário no topo do arquivo:

> "Três variantes da página de configurações, alternáveis via `?variant=`, na rota `/settings` existente."

Isso funciona quer o usuário esteja aqui para reagir ou não.

### 2. Gere variantes radicalmente diferentes

Elabore cada variante. Segure cada um para:

- A finalidade da página e os dados a que tem acesso.
- A biblioteca de componentes/sistema de estilo do projeto (TailwindCSS, shadcn, MUI, CSS simples, qualquer que seja).
- Um nome claro do componente exportado, por ex. `VariantA`, `VariantB`, `VariantC`.

As variantes devem ser **estruturalmente diferentes**: layout diferente, hierarquia de informações diferente, recursos primários diferentes, e não apenas cores diferentes. Três grades de cartão ligeiramente ajustadas não são um protótipo de IU, são um papel de parede. Se dois rascunhos forem muito semelhantes, refaça um com a orientação explícita de “não use uma grade de cartões”.

### 3. Conecte-os juntos

Crie um único componente switcher na rota:

```tsx
// pseudo-code, adapt to the project's framework
const variant = searchParams.get('variant') ?? 'A';
return (
  <>
    {variant === 'A' && <VariantA {...data} />}
    {variant === 'B' && <VariantB {...data} />}
    {variant === 'C' && <VariantC {...data} />}
    <PrototypeSwitcher variants={['A','B','C']} current={variant} />
  </>
);
```

Para a subforma A (página existente): mantenha todos os dados existentes buscando acima do switcher; apenas a subárvore renderizada muda por variante.

Para subforma B (nova página): a rota descartável em `/prototype/<name>` monta o mesmo switcher.

### 4. Construa o switcher flutuante

Uma pequena barra de posição fixa na parte inferior central da tela com três peças:

- **Seta para a esquerda**: alterna para a variante anterior (contorna).
- **Rótulo da variante**: mostra a chave da variante atual e, se a variante exportar um nome, esse nome também. por exemplo `B (Sidebar layout)`.
- **Seta para a direita**: avança (dá a volta).

Comportamento:

- Clicar em uma seta atualiza o parâmetro de pesquisa de URL (use o roteador da estrutura, por exemplo, `router.replace` no Next, `navigate` no React Router, etc) para que a variante seja compartilhável e estável para recarga.
- Teclado: as teclas de seta `←` e `→` também alternam. Não intercepte as teclas de seta quando um `<input>`, `<textarea>` ou `[contenteditable]` estiver em foco.
- Visualmente distinto da página (por exemplo, pílula de alto contraste, sombra sutil), portanto obviamente não faz parte do design que está sendo avaliado.
- Oculto em compilações de produção: gate em `process.env.NODE_ENV !== 'production'` ou uma verificação equivalente, para que uma fusão de protótipos perdidos não possa enviar a barra aos usuários.

Coloque o switcher em um único componente compartilhado para que ambas as subformas possam reutilizá-lo. Localize-o onde quer que a UI compartilhada esteja no projeto.

### 5. Entregue

Mostre o URL (e as chaves `?variant=`). O usuário irá folheá-lo sempre que chegar lá. O feedback interessante geralmente é **"Quero o cabeçalho de B com a barra lateral de C"**, que é o design real que eles desejam.

### 6. Capture a resposta e limpe

Depois que uma variante vencer, capture a resposta (qual variante e por quê) e, em seguida, capture o protótipo da maneira que [SKILL](SKILL.md) descreve. Dobre o vencedor no código real e mova o restante para o galho descartável, não para o principal:

- **Subforma A**: dobrar o vencedor na página existente; retire as variantes perdedoras e o switcher do main.
- **Subforma B**: promove a variante vencedora para uma rota real; retire a rota descartável e o switcher do principal.

O conjunto completo de variantes é a fonte primária, portanto, ele cai na ramificação descartável, não na lixeira, já que os componentes das variantes e o switcher deixados na ramificação principal apodrecem rapidamente e confundem o próximo leitor.

## Antipadrões

- **Variantes que diferem apenas na cor ou na cópia.** Isso é um ajuste, não um protótipo. Variantes reais discordam sobre a estrutura.
- **Compartilhar muito código entre variantes.** Um `<Header>` compartilhado é adequado; um `<Layout>` compartilhado anula o ponto. Cada variante deve ser livre para descartar o layout.
- **Variantes de fiação para mutações reais.** Protótipos somente leitura são adequados. Se uma variante precisar sofrer mutação, aponte-a para um esboço: a pergunta é "como deveria ser isso", não "o back-end funciona".
- **Promover o protótipo diretamente para produção.** O código da variante foi escrito sob restrições de protótipo (sem testes, tratamento mínimo de erros). Reescreva-o corretamente ao dobrá-lo.