---
name: code-review
description: 'Revise as alterações desde um ponto fixo (commit, branch, tag ou merge-base) ao longo de dois eixos: Standards (o código segue os padrões de codificação documentados deste repositório?) e Spec (o código corresponde ao que o problema/especificação de origem solicitou?). Executa ambas as revisões em subagentes paralelos e os relata lado a lado. Use quando o usuário deseja revisar uma ramificação, um PR, alterações de trabalho em andamento ou pede para "revisar desde X".'
---

Revisão em dois eixos da diferença entre `HEAD` e um ponto fixo fornecido pelo usuário:

- **Padrões**: o código está em conformidade com os padrões de codificação documentados deste repositório?
- **Especificações**: o código implementa fielmente o problema/especificação de origem?

Ambos os eixos funcionam como **subagentes paralelos** para que não poluam o contexto um do outro, então essa habilidade agrega suas descobertas.

O rastreador de problemas deveria ter sido fornecido a você. Se `docs/agents/issue-tracker.md` estiver faltando, diga ao usuário para executar `/setup-matt-pocock-skills`.

## Processo

### 1. Fixe o ponto fixo

Tudo o que o usuário disse é o ponto fixo (um commit SHA, nome da ramificação, tag, `main`, `HEAD~5`, etc.). Se eles não especificaram um, peça.

Capture o comando diff uma vez: `git diff <fixed-point>...HEAD` (três pontos, portanto a comparação é com a base de mesclagem). Observe também a lista de commits via `git log <fixed-point>..HEAD --oneline`.

Antes de prosseguir, confirme se o ponto fixo é resolvido (`git rev-parse <fixed-point>`) e se o diferencial não está vazio. Uma referência incorreta ou uma comparação vazia devem falhar aqui, não dentro de dois subagentes paralelos.

### 2. Identifique a fonte das especificações

Procure a especificação de origem, nesta ordem:

1. Emita referências nas mensagens de commit (`#123`, `Closes #45`, GitLab `!67`, etc.), obtidas por meio do fluxo de trabalho em `docs/agents/issue-tracker.md`.
2. Um caminho que o usuário passou como argumento.
3. Um arquivo de especificação em `docs/`, `specs/` ou `.scratch/` correspondente ao nome ou recurso da ramificação.
4. Se nada for encontrado, pergunte ao usuário onde está a especificação. Se eles disserem que não há, o subagente **Spec** irá ignorar e reportar "nenhuma especificação disponível".

### 3. Identifique as fontes dos padrões

Qualquer coisa no repositório que documente como o código deve ser escrito, como `CODING_STANDARDS.md` ou `CONTRIBUTING.md`.

Além de quaisquer documentos do repositório, o eixo Padrões sempre carrega a **linha de base do cheiro** abaixo: um conjunto fixo de cheiros de código Fowler (_Refactoring_, cap.3) que se aplica mesmo quando um repositório não documenta nada. Duas regras o vinculam:

- **O repo substitui.** Um padrão de repo documentado sempre vence; onde endossa algo que a linha de base sinalizaria, suprimiria o cheiro.
- **Sempre um julgamento.** Cada cheiro é uma heurística rotulada ("possível inveja de recursos"), nunca uma violação grave. Como qualquer padrão aqui, pule qualquer coisa que as ferramentas já apliquem.

Cada cheiro diz *o que é* → *como consertar*; combine-o com o diff:

- **Nome misterioso**: uma função, variável ou tipo cujo nome não revela o que faz ou contém. → renomeá-lo; se nenhum nome honesto aparecer, o design será obscuro.
- **Código Duplicado**: a mesma forma lógica aparece em mais de um pedaço ou arquivo na alteração. → extraia a forma compartilhada, chame-a de ambas.
- **Feature Envy**: um método que alcança mais os dados de outro objeto do que os seus próprios. → mova o método para os dados que ele inveja.
- **Grupos de dados**: os mesmos campos ou parâmetros continuam viajando juntos (um tipo querendo nascer). → agrupe-os em um tipo, passe isso.
- **Obsessão Primitiva**: um primitivo ou string que representa um conceito de domínio que merece seu próprio tipo. → dê ao conceito seu próprio tipo pequeno.
- **Switches repetidas**: a mesma cascata `switch`/`if` no mesmo tipo ocorre durante a mudança. → substitua por polimorfismo ou um mapa compartilhado por ambos os sites.
- **Shotgun Surgery**: uma mudança lógica força edições dispersas em muitos arquivos no diff. → reúna o que muda em um módulo.
- **Alteração Divergente**: um arquivo ou módulo é editado por vários motivos não relacionados. → dividir para que cada módulo mude por um motivo.
- **Generalidade especulativa**: abstração, parâmetros ou ganchos adicionados para necessidades que a especificação não possui. → exclua-o; inline de volta até que uma necessidade real apareça.
- **Cadeias de mensagens**: navegação `a.b().c().d()` longa da qual o chamador não deveria depender. → ocultar o passeio atrás de um método no primeiro objeto.
- **Middle Man**: uma classe ou função que geralmente apenas delega adiante. → corte, chame o alvo real de direto.
- **Legado Recusado**: uma subclasse ou implementador que ignora ou substitui a maior parte do que herda. → abandone a herança, use composição.

### 4. Gere os dois subagentes em paralelo

**O prompt do subagente padrão** deve incluir:

- O comando diff completo e a lista de commits.
- A lista de arquivos de origem de padrões que você encontrou na etapa 3, **mais a linha de base do cheiro da etapa 3** colada por completo (o subagente não tem outro acesso a ela).
- O resumo: "Relate, por arquivo/pedaço, quando relevante, (a) cada lugar em que a comparação viola um padrão documentado: cite o padrão (arquivo + a regra); e (b) qualquer cheiro de linha de base que você detectar: ​​nomeie-o e cite o pedaço. Distinguir violações graves de decisões de julgamento: violações de padrões documentados podem ser difíceis, mas cheiros de linha de base são sempre decisões de julgamento, e um padrão de recompra documentado substitui a linha de base. Ignore qualquer aplicação de ferramentas. Menos de 400 palavras. "

**O prompt do subagente de especificações** deve incluir:

- O comando diff e a lista de commits.
- O caminho ou conteúdo obtido da especificação.
- O resumo: "Relatório: (a) requisitos que a especificação solicitada está ausente ou parcial; (b) comportamento na comparação que não foi solicitado (aumento de escopo); (c) requisitos que parecem implementados, mas onde a implementação parece errada. Cite a linha de especificação para cada descoberta. Menos de 400 palavras."

Se a especificação estiver faltando, ignore o subagente Spec e anote isso no relatório final.

### 5. Agregado

Apresente os dois relatórios sob os títulos `## Standards` e `## Spec`, literalmente ou levemente limpos. **Não** mescle ou reclassifique as descobertas, porque os dois eixos são deliberadamente separados (consulte _Por que dois eixos_).

Termine com um resumo de uma linha: total de resultados por eixo e o pior problema _dentro de cada eixo_ (se houver). Não escolha um único vencedor entre os eixos: essa é a reclassificação que a separação existe para evitar.

## Por que dois eixos

Uma mudança pode passar em um eixo e falhar no outro:

- Código que segue todos os padrões, mas implementa a coisa errada → **Padrões aprovados, especificações falhadas.**
- Código que faz exatamente o que o problema pediu, mas quebra as convenções do projeto → **Aprovação nas especificações, falha nos padrões.**

Reportá-los separadamente impede que um eixo mascare o outro.
