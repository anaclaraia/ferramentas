# Documentos de domínio

Como as habilidades de engenharia devem consumir a documentação de domínio deste repositório ao explorar a base de código.

## Antes de explorar, leia estes

- **`CONTEXT.md`** na raiz do repositório ou
- **`CONTEXT-MAP.md`** na raiz do repositório, se existir: aponta para um `CONTEXT.md` por contexto. Leia cada um relevante para o tópico.
- **`docs/adr/`**: leia ADRs que afetam a área em que você está prestes a trabalhar. Em repositórios multicontexto, verifique também `src/<context>/docs/adr/` para decisões com escopo de contexto.

Se algum desses arquivos não existir, **prossiga silenciosamente**. Não sinalize sua ausência; não sugira criá-los antecipadamente. A habilidade `/domain-modeling` (alcançada por meio de `/grill-with-docs` e `/improve-codebase-architecture`) os cria preguiçosamente quando os termos ou decisões são realmente resolvidos.

## Estrutura do arquivo

Repositório de contexto único (a maioria dos repositórios):

```
/
├── CONTEXT.md
├── docs/adr/
│   ├── 0001-event-sourced-orders.md
│   └── 0002-postgres-for-write-model.md
└── src/
```

Repositório multicontexto (presença de `CONTEXT-MAP.md` na raiz):

```
/
├── CONTEXT-MAP.md
├── docs/adr/                          ← system-wide decisions
└── src/
    ├── ordering/
    │   ├── CONTEXT.md
    │   └── docs/adr/                  ← context-specific decisions
    └── billing/
        ├── CONTEXT.md
        └── docs/adr/
```

## Use o vocabulário do glossário

Quando sua saída nomear um conceito de domínio (em um título de problema, uma proposta de refatoração, uma hipótese, um nome de teste), use o termo conforme definido em `CONTEXT.md`. Não se prenda a sinônimos que o glossário evita explicitamente.

Se o conceito que você precisa ainda não está no glossário, isso é um sinal: ou você está inventando uma linguagem que o projeto não usa (reconsidere) ou há uma lacuna real (observe para `/domain-modeling`).

## Sinalizar conflitos de ADR

Se sua saída contradizer um ADR existente, exponha-o explicitamente, em vez de substituí-lo silenciosamente:

> _Contradiz ADR-0007 (pedidos originados em eventos), mas vale a pena reabrir porque…_