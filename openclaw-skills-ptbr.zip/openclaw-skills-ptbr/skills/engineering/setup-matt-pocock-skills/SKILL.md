---
name: setup-matt-pocock-skills
description: "Configure este repositório para as habilidades de engenharia: configure seu rastreador de problemas, vocabulário de rótulo de triagem e layout de documento de domínio. Execute uma vez antes de usar as outras habilidades de engenharia pela primeira vez."
disable-model-invocation: true
---

# Configure as habilidades de Matt Pocock

Estruture a configuração por repositório que as habilidades de engenharia assumem:

- **Issue Tracker**: onde os problemas residem (GitHub por padrão; markdown local também é compatível imediatamente)
- **Rótulos de triagem**: as strings usadas para as cinco funções canônicas de triagem
- **Documentos de domínio**: onde residem `CONTEXT.md` e ADRs e as regras do consumidor para lê-los

Esta é uma habilidade orientada por prompt, não um script determinístico. Explore, apresente o que encontrou, confirme com o usuário e depois escreva.

## Processo

### 1. Explorar

Observe o repositório atual para entender seu estado inicial. Leia tudo o que existe; não assuma:

- `git remote -v` e `.git/config`: este é um repositório GitHub? Qual deles?
- `AGENTS.md` e `CLAUDE.md` na raiz do repositório: algum deles existe? Já existe uma seção `## Agent skills` em algum deles?
- `CONTEXT.md` e `CONTEXT-MAP.md` na raiz do repositório
- `docs/adr/` e quaisquer diretórios `src/*/docs/adr/`
- `docs/agents/`: a saída anterior desta habilidade já existe?
- `.scratch/`: um sinal de que uma convenção de rastreador de problemas de redução local já está em uso
- A habilidade `triage` está instalada? (uma pasta de habilidade `triage` ao lado desta, ou `triage` em suas habilidades disponíveis.) Isso decide se a Seção B será executada.
- Sinais Monorepo: um campo `pnpm-workspace.yaml`, um campo `workspaces` em `package.json` ou um `packages/*` preenchido com seu próprio `src/`. Eles estão presentes apenas em um repositório de vários pacotes genuinamente grande; sua ausência significa contexto único, que ocorre em quase todos os repositórios.

### 2. Apresente descobertas e pergunte

Resuma o que está presente e o que está faltando. Em seguida, pegue as seções em ordem. Uma seção, uma resposta e depois a próxima.

Conduza cada seção com a resposta recomendada para que o usuário possa aceitá-la em uma palavra. Forneça um explicador de uma linha somente quando a escolha realmente se ramificar; pule totalmente a seção quando a exploração já estiver resolvida (Seção B quando `triage` não estiver instalado, Seção C quando não houver monorepo).

**Seção A: Rastreador de problemas.**

> Explicador: O "rastreador de problemas" é onde residem os problemas deste repositório. Habilidades como `to-tickets`, `triage` e `to-spec` leem e gravam nele. Eles precisam saber se devem chamar `gh issue create`, gravar um arquivo markdown em `.scratch/` ou seguir algum outro fluxo de trabalho que você descreve. Escolha o local onde você realmente monitora o trabalho deste repositório.

Postura padrão: essas habilidades foram projetadas para GitHub. Se um `git remote` apontar para GitHub, proponha isso. Se um `git remote` apontar para o GitLab (`gitlab.com` ou um host auto-hospedado), proponha o GitLab. Caso contrário (ou se o usuário preferir), ofereça:

- **GitHub**: os problemas residem nos problemas do GitHub do repositório (usa a CLI `gh`)
- **GitLab**: os problemas residem no GitLab Issues do repositório (usa a CLI [`glab`](https://gitlab.com/gitlab-org/cli))
- **Marcação local**: problemas ao vivo como arquivos em `.scratch/<feature>/` neste repositório (bom para projetos individuais ou repositórios sem controle remoto)
- **Outros** (Jira, Linear, etc.): peça ao usuário para descrever o fluxo de trabalho em um parágrafo; a habilidade irá gravá-lo como prosa de forma livre

Registre a escolha em `docs/agents/issue-tracker.md`. Os modelos GitHub e GitLab carregam um sinalizador "PRs como superfície de solicitação", com padrão **off**. Deixe de lado e não aumente: um usuário que deseja PRs externos na fila de triagem pode inverter o sinalizador no arquivo posteriormente.

**Seção B: Vocabulário de rótulos de triagem.** Ignore esta seção completamente se a habilidade `triage` não estiver instalada (a exploração lhe disse), pois uma habilidade desinstalada não precisa de rótulos.

Se estiver instalado, faça exatamente uma pergunta:

> Deseja manter os rótulos de triagem padrão? (recomendado: **sim**)

Os padrões são as cinco funções canônicas, cada sequência de rótulo igual ao seu nome: `needs-triage`, `needs-info`, `ready-for-agent`, `ready-for-human`, `wontfix`. Em **sim**, escreva-os como estão. Somente se o usuário disser não, geralmente porque seu rastreador já usa outros nomes (por exemplo, `bug:triage` para `needs-triage`), colete as substituições para que `triage` aplique rótulos existentes em vez de criar duplicatas.

**Seção C: Documentos de domínio.** Padrão para **contexto único** (um `CONTEXT.md` + `docs/adr/` na raiz do repositório). Isso se aplica a quase todos os repositórios; escreva sem perguntar.

Oferece **multicontexto** (uma raiz `CONTEXT-MAP.md` apontando para arquivos `CONTEXT.md` por contexto) somente quando a exploração encontrou sinais monorepo. Em seguida, confirme qual layout eles desejam.

### 3. Confirme e edite

Mostre ao usuário um rascunho de:

- O bloco `## Agent skills` a ser adicionado a qualquer `CLAUDE.md` / `AGENTS.md` que esteja sendo editado (consulte a etapa 4 para regras de seleção)
- O conteúdo de `docs/agents/issue-tracker.md`, `docs/agents/domain.md` e `docs/agents/triage-labels.md` (o último somente quando `triage` estiver instalado)

Deixe-os editar antes de escrever.

### 4. Escreva

**Escolha o arquivo para editar:**

- Se `CLAUDE.md` existir, edite-o.
- Caso contrário, se `AGENTS.md` existir, edite-o.
- Caso não exista, pergunte ao usuário qual criar; não escolha por eles.

Nunca crie `AGENTS.md` quando `CLAUDE.md` já existir (ou vice-versa); sempre edite aquele que já está lá.

Se um bloco `## Agent skills` já existir no arquivo escolhido, atualize seu conteúdo no local em vez de anexar uma duplicata. Não substitua as edições do usuário nas seções vizinhas.

O bloco:

```markdown
## Agent skills

### Issue tracker

[one-line summary of where issues are tracked]. See `docs/agents/issue-tracker.md`.

### Triage labels

[one-line summary of the label vocabulary]. See `docs/agents/triage-labels.md`.

### Domain docs

[one-line summary of layout: "single-context" or "multi-context"]. See `docs/agents/domain.md`.
```

Inclua o subbloco `### Triage labels` e escreva `docs/agents/triage-labels.md` somente quando `triage` estiver instalado e a Seção B for executada. Quando não é, ambos são omitidos.

Em seguida, escreva os arquivos de documentação usando os modelos iniciais nesta pasta de habilidades como ponto de partida:

- [issue-tracker-github.md](./issue-tracker-github.md): rastreador de problemas do GitHub
- [issue-tracker-gitlab.md](./issue-tracker-gitlab.md): rastreador de problemas do GitLab
- [issue-tracker-local.md](./issue-tracker-local.md): rastreador de problemas de redução local
- [triage-labels.md](./triage-labels.md): mapeamento de rótulos (somente se `triage` estiver instalado)
- [domain.md](./domain.md): regras do consumidor do documento de domínio + layout

Para "outros" rastreadores de problemas, escreva `docs/agents/issue-tracker.md` do zero usando a descrição do usuário.

### 5. Concluído

Informe ao usuário que a configuração foi concluída e quais habilidades de engenharia irão agora ler esses arquivos. Mencione que eles podem editar `docs/agents/*.md` diretamente mais tarde; reexecutar essa habilidade só será necessário se eles quiserem trocar os rastreadores de problemas ou reiniciar do zero.