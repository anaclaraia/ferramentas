# Rastreador de problemas: GitHub

Os problemas e especificações deste repositório são apresentados como problemas do GitHub. Use a CLI `gh` para todas as operações.

## Convenções

- **Crie um problema**: `gh issue create --title "..." --body "..."`. Use um heredoc para corpos multilinhas.
- **Leia um problema**: `gh issue view <number> --comments`, filtrando comentários por `jq` e também buscando rótulos.
- **Listar problemas**: `gh issue list --state open --json number,title,body,labels,comments --jq '[.[] | {number, title, body, labels: [.labels[].name], comments: [.comments[].body]}]'` com filtros `--label` e `--state` apropriados.
- **Comente um problema**: `gh issue comment <number> --body "..."`
- **Aplicar/remover rótulos**: `gh issue edit <number> --add-label "..."` / `--remove-label "..."`
- **Fechar**: `gh issue close <number> --comment "..."`

Inferir o repositório de `git remote -v`; `gh` faz isso automaticamente quando executado dentro de um clone.

## Solicitações pull como superfície de triagem

**PRs como uma superfície de solicitação: não.** _(Definido como `yes` se este repositório tratar PRs externos como solicitações de recurso; `/triage` lê este sinalizador.)_

Quando definido como `yes`, os PRs passam pelos mesmos rótulos e estados dos problemas, usando os equivalentes `gh pr`:

- **Leia um PR**: `gh pr view <number> --comments` e `gh pr diff <number>` para o diff.
- **Liste PRs externos para triagem**: `gh pr list --state open --json number,title,body,labels,author,authorAssociation,comments` e mantenha apenas `authorAssociation` de `CONTRIBUTOR`, `FIRST_TIME_CONTRIBUTOR` ou `NONE` (descarte `OWNER`/`MEMBER`/`COLLABORATOR`).
- **Comentário/rótulo/fechamento**: `gh pr comment`, `gh pr edit --add-label`/`--remove-label`, `gh pr close`.

O GitHub compartilha um espaço numérico entre problemas e PRs, portanto, um `#42` simples pode ser: resolver com `gh pr view 42` e voltar para `gh issue view 42`.

## Quando uma habilidade diz "publicar no rastreador de problemas"

Crie um problema no GitHub.

## Quando uma habilidade diz "buscar o ticket relevante"

Execute `gh issue view <number> --comments`.

## Operações de orientação

Usado por `/wayfinder`. O **mapa** é um problema único com problemas **filhos** como tickets.

- **Mapa**: uma única edição chamada `wayfinder:map`, contendo o corpo Notas / Decisões até agora / Nevoeiro. `gh issue create --label wayfinder:map`.
- **Tíquete filho**: um problema vinculado ao mapa como um subproblema do GitHub (`gh api` no endpoint de subproblemas). Onde os subproblemas não estiverem habilitados, adicione o filho a uma lista de tarefas no corpo do mapa e coloque `Part of #<map>` na parte superior do corpo filho. Etiquetas: `wayfinder:<type>` (`research`/`prototype`/`grilling`/`task`). Depois de reivindicado, o tíquete é atribuído ao desenvolvedor que dirige.
- **Bloqueio**: **dependências de problemas nativos** do GitHub, a representação canônica visível na interface do usuário. Adicione uma vantagem com `gh api --method POST repos/<owner>/<repo>/issues/<child>/dependencies/blocked_by -F issue_id=<blocker-db-id>`, onde `<blocker-db-id>` é o **id do banco de dados** numérico do bloqueador (`gh api repos/<owner>/<repo>/issues/<n> --jq .id`, _não_ o `#number` ou `node_id`). GitHub relata `issue_dependencies_summary.blocked_by` (somente bloqueadores abertos, o portão ativo). Onde as dependências não estiverem disponíveis, volte para uma linha `Blocked by: #<n>, #<n>` na parte superior do corpo filho. Um ticket é desbloqueado quando todos os bloqueadores são fechados.
- **Consulta de fronteira**: liste os filhos abertos do mapa (`gh issue list --state open`, com escopo nos subproblemas/lista de tarefas do mapa), descarte qualquer um com um bloqueador aberto (`issue_dependencies_summary.blocked_by > 0`, ou um problema aberto na linha `Blocked by`) ou um cessionário; o primeiro na ordem do mapa vence.
- **Reivindicação**: `gh issue edit <n> --add-assignee @me`, a primeira gravação da sessão.
- **Resolver**: `gh issue comment <n> --body "<answer>"`, depois `gh issue close <n>` e, em seguida, anexe um ponteiro de contexto (essencial + link) às Decisões até agora do mapa.