# Rastreador de problemas: GitLab

Os problemas e especificações deste repositório são apresentados como problemas do GitLab. Use a CLI [`glab`](https://gitlab.com/gitlab-org/cli) para todas as operações.

## Convenções

- **Crie um problema**: `glab issue create --title "..." --description "..."`. Use um heredoc para descrições multilinhas. Passe `--description -` para abrir um editor.
- **Leia um problema**: `glab issue view <number> --comments`. Use `-F json` para saída legível por máquina.
- **Listar problemas**: `glab issue list -F json` com filtros `--label` apropriados.
- **Comente um problema**: `glab issue note <number> --message "..."`. O GitLab chama os comentários de "notas".
- **Aplicar/remover rótulos**: `glab issue update <number> --label "..."` / `--unlabel "..."`. Vários rótulos podem ser separados por vírgula ou repetindo o sinalizador.
- **Fechar**: `glab issue close <number>`. `glab issue close` não aceita comentários finais, então poste a explicação primeiro com `glab issue note <number> --message "..."` e depois feche.
- **Solicitações de mesclagem**: o GitLab chama PRs de "solicitações de mesclagem". Use `glab mr create`, `glab mr view`, `glab mr note`, etc., o mesmo formato de `gh pr ...` com `mr` no lugar de `pr` e `note`/`--message` no lugar de `comment`/`--body`.

Inferir o repositório de `git remote -v`; `glab` faz isso automaticamente quando executado dentro de um clone.

## Mesclar solicitações como uma superfície de triagem

**MRs como uma superfície de solicitação: não.** _(Definido como `yes` se este repositório tratar solicitações de mesclagem externas como solicitações de recursos; `/triage` lê este sinalizador.)_

Quando definido como `yes`, os MRs passam pelos mesmos rótulos e estados dos problemas, usando os equivalentes `glab mr`:

- **Leia um MR**: `glab mr view <number> --comments` e `glab mr diff <number>` para o diff.
- **Listar MRs externos para triagem**: `glab mr list -F json` e, em seguida, manter apenas MRs cujo autor não seja membro/proprietário do projeto (MR de um contribuidor, não um trabalho em andamento de um mantenedor).
- **Comentário/rótulo/fechamento**: `glab mr note`, `glab mr update --label`/`--unlabel`, `glab mr close`.

Ao contrário do GitHub, o GitLab numera problemas e MRs separadamente, portanto `#42` é inequívoco quando você sabe a qual superfície o mantenedor se refere.

## Quando uma habilidade diz "publicar no rastreador de problemas"

Crie um problema no GitLab.

## Quando uma habilidade diz "buscar o ticket relevante"

Execute `glab issue view <number> --comments`.

## Operações de orientação

Usado por `/wayfinder`. O **mapa** é um problema único com problemas **filhos** como tickets.

- **Mapa**: uma única edição denominada `wayfinder:map`, contendo o corpo Notas / Decisões até agora / Nevoeiro. `glab issue create --label wayfinder:map`. (Nas camadas do GitLab com épicos nativos, um épico pode conter o mapa; um problema rotulado funciona em qualquer lugar.)
- **Bilhete infantil**: uma edição com `Part of #<map>` no topo de sua descrição e rótulos `wayfinder:<type>` (`research`/`prototype`/`grilling`/`task`). Depois de reivindicado, o tíquete é atribuído ao desenvolvedor que dirige.
- **Bloqueio**: **link de bloqueio nativo** do GitLab, a representação canônica visível na UI. Adicione-o com a ação rápida `/blocked_by #<n>`, publicada como uma nota (`glab issue note <child> --message "/blocked_by #<blocker>"`). Links de bloqueio nativos são um recurso Premium/Ultimate; no nível gratuito (ou onde não estiver disponível), retorne para uma linha `Blocked by: #<n>, #<n>` no topo da descrição. Um ticket é desbloqueado quando todos os bloqueadores são fechados.
- **Consulta de fronteira**: `glab issue list -F json` com escopo para os filhos do mapa, descarte qualquer um com um bloqueador aberto: um link `blocked_by` nativo para um problema aberto (`glab api projects/:id/issues/:iid/links`), ou um problema aberto na linha `Blocked by`, ou um cessionário; o primeiro na ordem do mapa vence.
- **Reivindicação**: `glab issue update <n> --assignee @me`, a primeira gravação da sessão.
- **Resolver**: `glab issue note <n> --message "<answer>"`, depois `glab issue close <n>` e, em seguida, anexe um ponteiro de contexto (essencial + link) às Decisões até agora do mapa.