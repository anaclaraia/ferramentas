# Rastreador de problemas: Markdown local

Os problemas e especificações deste repositório estão disponíveis como arquivos markdown em `.scratch/`.

## Convenções

- Um recurso por diretório: `.scratch/<feature-slug>/`
- A especificação é `.scratch/<feature-slug>/spec.md`
- Os problemas de implementação são um arquivo por ticket em `.scratch/<feature-slug>/issues/<NN>-<slug>.md`, numerado a partir de `01`, nunca um único arquivo de tickets combinado
- O estado de triagem é registrado como uma linha `Status:` próxima ao topo de cada arquivo de problema (consulte `triage-labels.md` para as strings de função)
- Comentários e histórico de conversas são anexados à parte inferior do arquivo sob o título `## Comments`

## Quando uma habilidade diz "publicar no rastreador de problemas"

Crie um novo arquivo em `.scratch/<feature-slug>/` (criando o diretório se necessário).

## Quando uma habilidade diz "buscar o ticket relevante"

Leia o arquivo no caminho referenciado. O usuário normalmente passará o caminho ou o número do problema diretamente.

## Operações de orientação

Usado por `/wayfinder`. O **mapa** é um arquivo com um arquivo **filho** por ticket.

- **Mapa**: `.scratch/<effort>/map.md` (Notas / Decisões até agora / Corpo de neblina).
- **Tíquete criança**: `.scratch/<effort>/issues/NN-<slug>.md`, numerado a partir de `01`, com pergunta no corpo. Uma linha `Type:` registra o tipo de ticket (`research`/`prototype`/`grilling`/`task`); uma linha `Status:` registra `claimed`/`resolved`.
- **Bloqueio**: uma linha `Blocked by: NN, NN` próxima ao topo. Um ticket é desbloqueado quando cada arquivo listado é `resolved`.
- **Frontier**: verifica `.scratch/<effort>/issues/` em busca de arquivos abertos, desbloqueados e não reivindicados; o primeiro por número vence.
- **Reivindicação**: defina `Status: claimed` e salve antes de qualquer trabalho.
- **Resolver**: anexe a resposta sob um cabeçalho `## Answer`, defina `Status: resolved` e, em seguida, anexe um ponteiro de contexto (essencial + link) às Decisões até agora do mapa em `map.md`.