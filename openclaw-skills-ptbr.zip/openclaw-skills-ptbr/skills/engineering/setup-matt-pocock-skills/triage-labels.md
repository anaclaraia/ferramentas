# Etiquetas de triagem

As habilidades falam em termos de cinco funções canônicas de triagem. Este arquivo mapeia essas funções para as strings de rótulo reais usadas no rastreador de problemas deste repositório.

| Etiqueta em mattpocock/habilidades | Etiqueta em nosso rastreador | Significado |
| -------------------------- | -------------------- | ---------------------------------------- |
| `needs-triage` | `needs-triage` | O mantenedor precisa avaliar esse problema |
| `needs-info` | `needs-info` | Aguardando repórter para mais informações |
| `ready-for-agent` | `ready-for-agent` | Totalmente especificado, pronto para um agente AFK |
| `ready-for-human` | `ready-for-human` | Requer implementação humana |
| `wontfix` | `wontfix` | Não será acionado |

Quando uma habilidade menciona uma função (por exemplo, "aplicar o rótulo de triagem pronto para AFK"), use a sequência de rótulo correspondente desta tabela.

Edite a coluna da direita para corresponder ao vocabulário que você realmente usa.