# Formato CONTEXTO.md

## Estrutura

```md
# {Context Name}

{One or two sentence description of what this context is and why it exists.}

## Language

**Order**:
{A one or two sentence description of the term}
_Avoid_: Purchase, transaction

**Invoice**:
A request for payment sent to a customer after delivery.
_Avoid_: Bill, payment request

**Customer**:
A person or organization that places orders.
_Avoid_: Client, buyer, account
```

## Regras

- **Seja opinativo.** Quando existirem várias palavras para o mesmo conceito, escolha a melhor e liste as outras em `_Avoid_`.
- **Mantenha as definições restritas.** Uma ou duas frases no máximo. Defina o que É, não o que faz.
- **Inclua apenas termos específicos ao contexto deste projeto.** Conceitos gerais de programação (tempos limite, tipos de erros, padrões de utilidade) não pertencem, mesmo que o projeto os utilize extensivamente. Antes de adicionar um termo, pergunte: este é um conceito exclusivo deste contexto ou um conceito geral de programação? Apenas o primeiro pertence.
- **Termos de grupo em subtítulos** quando surgem clusters naturais. Se todos os termos pertencerem a uma única área coesa, uma lista simples é adequada.

## Repositórios únicos e multicontexto

**Contexto único (a maioria dos repositórios):** Um `CONTEXT.md` na raiz do repositório.

**Vários contextos:** Um `CONTEXT-MAP.md` na raiz do repositório lista os contextos, onde eles residem e como se relacionam entre si:

```md
# Context Map

## Contexts

- [Ordering](./src/ordering/CONTEXT.md): receives and tracks customer orders
- [Billing](./src/billing/CONTEXT.md): generates invoices and processes payments
- [Fulfillment](./src/fulfillment/CONTEXT.md): manages warehouse picking and shipping

## Relationships

- **Ordering → Fulfillment**: Ordering emits `OrderPlaced` events; Fulfillment consumes them to start picking
- **Fulfillment → Billing**: Fulfillment emits `ShipmentDispatched` events; Billing consumes them to generate invoices
- **Ordering ↔ Billing**: Shared types for `CustomerId` and `Money`
```

A habilidade infere qual estrutura se aplica:

- Se `CONTEXT-MAP.md` existir, leia-o para encontrar contextos
- Se existir apenas uma raiz `CONTEXT.md`, contexto único
- Se nenhum deles existir, crie uma raiz `CONTEXT.md` preguiçosamente quando o primeiro termo for resolvido

Quando existirem vários contextos, inferir a qual deles o tópico atual se refere. Se não estiver claro, pergunte.