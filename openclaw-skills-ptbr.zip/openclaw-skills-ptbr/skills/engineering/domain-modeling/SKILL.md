---
name: domain-modeling
description: Construa e aprimore o modelo de domínio de um projeto. Use ao discutir a terminologia da base de código, escrever ou editar um CONTEXT.md ou gravar ou editar um ADR.
---

# Modelagem de Domínio

Crie e aprimore ativamente o modelo de domínio do projeto à medida que você projeta. Esta é a disciplina *ativa*: desafiar termos, inventar cenários extremos e escrever o glossário e as decisões no momento em que se cristalizam. (Apenas *ler* `CONTEXT.md` para vocabulário não é essa habilidade: é um hábito de uma linha que qualquer habilidade pode fazer. Essa habilidade é para quando você está mudando o modelo, não apenas consumindo-o.)

## Estrutura do arquivo

A maioria dos repositórios tem um único contexto:

```
/
├── CONTEXT.md
├── docs/
│   └── adr/
│       ├── 0001-event-sourced-orders.md
│       └── 0002-postgres-for-write-model.md
└── src/
```

Se existir um `CONTEXT-MAP.md` na raiz, o repositório terá vários contextos. O mapa aponta onde cada um mora:

```
/
├── CONTEXT-MAP.md
├── docs/
│   └── adr/                          ← system-wide decisions
├── src/
│   ├── ordering/
│   │   ├── CONTEXT.md
│   │   └── docs/adr/                 ← context-specific decisions
│   └── billing/
│       ├── CONTEXT.md
│       └── docs/adr/
```

Crie arquivos preguiçosamente: somente quando tiver algo para escrever. Se não existir nenhum `CONTEXT.md`, crie um quando o primeiro termo for resolvido. Se não existir nenhum `docs/adr/`, crie-o quando o primeiro ADR for necessário.

## Durante a sessão

### Desafio contra o glossário

Quando o usuário usar um termo que entre em conflito com o idioma existente em `CONTEXT.md`, chame-o imediatamente. "Seu glossário define 'cancelamento' como X, mas você parece querer dizer Y. Qual é?"

### Aprimore a linguagem difusa

Quando o usuário utilizar termos vagos ou sobrecarregados, proponha um termo canônico preciso. "Você está dizendo 'conta': você quer dizer o Cliente ou o Usuário? Essas são coisas diferentes."

### Discuta cenários concretos

Quando os relacionamentos de domínio estiverem sendo discutidos, teste-os com cenários específicos. Invente cenários que investiguem casos extremos e forcem o usuário a ser preciso sobre os limites entre os conceitos.

### Referência cruzada com código

Quando o usuário indicar como algo funciona, verifique se o código está de acordo. Se você encontrar uma contradição, revele-a: "Seu código cancela pedidos inteiros, mas você acabou de dizer que o cancelamento parcial é possível. O que está certo?"

### Atualizar CONTEXT.md embutido

Quando um prazo for resolvido, atualize `CONTEXT.md` ali mesmo. Não os agrupe: capture-os à medida que acontecem. Use o formato em [CONTEXT-FORMAT.md](./CONTEXT-FORMAT.md).

`CONTEXT.md` deve ser totalmente desprovido de detalhes de implementação. Não trate `CONTEXT.md` como uma especificação, um bloco de rascunho ou um repositório para decisões de implementação. É um glossário e nada mais.

### Ofereça ADRs com moderação

Apenas ofereça a criação de um ADR quando todos os três forem verdadeiros:

1. **Difícil de reverter**: o custo de mudar de ideia mais tarde é significativo
2. **Surpreendente sem contexto**: um futuro leitor se perguntará "por que eles fizeram isso dessa maneira?"
3. **O resultado de uma troca real**: havia alternativas genuínas e você escolheu uma por razões específicas

Se algum dos três estiver faltando, ignore o ADR. Use o formato em [ADR-FORMAT.md](./ADR-FORMAT.md).