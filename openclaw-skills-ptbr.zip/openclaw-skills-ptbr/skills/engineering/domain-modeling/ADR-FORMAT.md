# Formato ADR

Os ADRs residem em `docs/adr/` e usam numeração sequencial: `0001-slug.md`, `0002-slug.md`, etc.

Crie o diretório `docs/adr/` preguiçosamente: somente quando o primeiro ADR for necessário.

## Modelo

```md
# {Short title of the decision}

{1-3 sentences: what's the context, what did we decide, and why.}
```

É isso. Um ADR pode ser um único parágrafo. O valor está em registrar *que* uma decisão foi tomada e *por que*, não em preencher seções.

## Seções opcionais

Inclua-os apenas quando agregarem valor genuíno. A maioria dos ADRs não precisará deles.

- **Status** frontmatter (`proposed | accepted | deprecated | superseded by ADR-NNNN`): útil quando as decisões são revisadas
- **Opções consideradas**: somente quando vale a pena lembrar as alternativas rejeitadas
- **Consequências**: somente quando efeitos posteriores não óbvios precisam ser destacados

## Numeração

Digitalize `docs/adr/` para obter o maior número existente e aumente em um.

## Quando oferecer um ADR

Todos os três devem ser verdadeiros:

1. **Difícil de reverter**: o custo de mudar de ideia mais tarde é significativo
2. **Surpreendente sem contexto**: um futuro leitor olhará para o código e se perguntará "por que diabos eles fizeram isso dessa maneira?"
3. **O resultado de uma troca real**: havia alternativas genuínas e você escolheu uma por razões específicas

Se for fácil reverter uma decisão, pule-a: você simplesmente a reverterá. Se não for surpreendente, ninguém se perguntará porquê. Se não houvesse alternativa real, não haveria nada para registrar além de “fizemos o óbvio”.

### O que se qualifica

- **Forma arquitetônica.** "Estamos usando um monorepo." "O modelo de gravação é originado de eventos, o modelo de leitura é projetado no Postgres."
- **Padrões de integração entre contextos.** "O pedido e o faturamento se comunicam por meio de eventos de domínio, não por HTTP síncrono."
- **Opções de tecnologia que são aprisionadas.** Banco de dados, barramento de mensagens, provedor de autenticação, destino de implantação. Nem todas as bibliotecas: apenas aquelas que levariam um quarto para serem trocadas.
- **Decisões de limite e escopo.** "Os dados do cliente pertencem ao contexto do cliente; outros contextos fazem referência a eles apenas por ID." Os não explícitos são tão valiosos quanto os sim.
- **Desvios deliberados do caminho óbvio.** "Estamos usando SQL manual em vez de um ORM por causa do X." Qualquer coisa em que um leitor razoável presumiria o contrário. Isso impede o próximo engenheiro de “consertar” algo que foi deliberado.
- **Restrições não visíveis no código.** "Não podemos usar a AWS devido a requisitos de conformidade." "Os tempos de resposta devem ser inferiores a 200 ms devido ao contrato da API do parceiro."
- **Alternativas rejeitadas quando a rejeição não é óbvia.** Se você considerou GraphQL e escolheu REST por motivos sutis, registre-o; caso contrário, alguém irá sugerir o GraphQL novamente em seis meses.