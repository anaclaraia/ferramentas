---
name: to-tickets
description: divida um plano, especificação ou conversa atual em um conjunto de tickets tracer-bullet, cada um declarando suas bordas de bloqueio, publicadas no rastreador configurado (bordas como texto em um arquivo por ticket localmente ou links de bloqueio nativos em um rastreador real).
disable-model-invocation: true
---

# Para ingressos

Divida um plano, especificação ou conversa em um conjunto de **tickets**: fatias verticais de marcadores rastreadores, cada uma declarando os tickets que o **bloqueiam**.

O vocabulário do rastreador de problemas e do rótulo de triagem deveria ter sido fornecido a você. Caso contrário, diga ao usuário para executar `/setup-matt-pocock-skills`.

## Processo

### 1. Reúna o contexto

Trabalhe a partir de tudo o que já está no contexto da conversa. Se o usuário passar uma referência (um caminho de especificação, um número de problema ou URL) como argumento, busque-a e leia seu corpo completo e comentários.

### 2. Explore a base de código (opcional)

Se você ainda não explorou a base de código, faça-o para entender o estado atual do código. Os títulos e descrições dos tickets devem usar o vocabulário do glossário de domínio do projeto e respeitar as ADRs na área que você está abordando.

Procure oportunidades de pré-fatorar o código para facilitar a implementação. "Faça a mudança fácil e depois faça a mudança fácil."

### 3. Rascunho de fatias verticais

Divida o trabalho em tickets **tracer bullet**.

<regras de fatia vertical>

- Cada fatia corta um caminho estreito, mas COMPLETO, através de cada camada (esquema, API, UI, testes): vertical, NÃO uma fatia horizontal de uma camada
- Uma fatia concluída é demonstrável ou verificável por si só
- Cada fatia é dimensionada para caber em uma única janela de contexto nova
- Qualquer pré-fatoração deve ser feita primeiro

</vertical-slice-rules>

Dê a cada ticket suas **bordas de bloqueio**: os outros tickets que devem ser concluídos antes de começar. Um ticket sem bloqueadores pode ser iniciado imediatamente.

**Refatores amplos são a exceção ao fatiamento vertical.** Um **refator amplo** é uma mudança mecânica (renomear uma coluna, redigitar um símbolo compartilhado) cujo **raio de explosão** se espalha por toda a base de código, de modo que uma única edição quebra milhares de sites de chamada de uma vez e nenhuma fatia vertical pode ficar verde. Não force uma bala traçadora; sequencie-o como **expandir-contrair**. Primeiro expanda: adicione o novo formulário ao lado do antigo para que nada quebre. Em seguida, migre os sites de chamada em lotes dimensionados por raio de explosão (por pacote, por diretório), cada lote com seu próprio ticket bloqueado pela expansão, mantendo CI verde lote a lote porque o formato antigo ainda existe. Finalmente contrato: exclua o formulário antigo quando não houver mais chamador, em um ticket bloqueado a cada lote de migração. Quando nem mesmo os lotes conseguem permanecer verdes sozinhos, mantenha a sequência, mas deixe-os compartilhar uma ramificação de integração que bloqueia um ticket final de integração e verificação; o verde é prometido apenas lá.

### 4. Questione o usuário

Apresente a repartição proposta como uma lista numerada. Para cada ingresso, mostre:

- **Título**: nome descritivo curto
- **Bloqueado por**: quais outros tickets (se houver) devem ser concluídos primeiro
- **O que ele oferece**: o comportamento de ponta a ponta que esse ticket faz funcionar

Pergunte ao usuário:

- A granularidade parece correta? (muito grosso/muito fino)
- As bordas de bloqueio estão corretas: cada ticket depende apenas dos tickets que realmente o bloqueiam?
- Algum ticket deve ser mesclado ou dividido ainda mais?

Itere até que o usuário aprove o detalhamento.

### 5. Publique os tickets no rastreador configurado

Publique os tickets aprovados. **Como** depende do rastreador `/setup-matt-pocock-skills` configurado; os tickets são iguais de qualquer maneira, apenas o formato das bordas de bloqueio muda:

- **Arquivos locais** → grave um arquivo por ticket em `.scratch/<feature-slug>/issues/<NN>-<slug>.md`, numerado a partir de `01` em ordem de dependência (bloqueadores primeiro). O "Bloqueado por" de cada arquivo lista os números/títulos dos quais ele depende. Use o modelo de arquivo por ticket abaixo: um ticket por arquivo, nunca um único arquivo combinado.
- **Um rastreador de problemas real (GitHub, Linear, …)** → publique um problema por ticket em ordem de dependência (bloqueadores primeiro) para que as bordas de bloqueio de cada ticket possam fazer referência a identificadores reais. Utilizar a relação de bloqueio/subquestão nativa da plataforma onde houver; caso contrário, defina o "Bloqueado por" de cada ticket para os problemas de bloqueio. Aplique o rótulo de triagem `ready-for-agent`, a menos que seja instruído de outra forma; os ingressos podem ser adquiridos pelo agente pela construção.

Trabalhe a **fronteira**: qualquer ticket cujos bloqueadores estejam todos concluídos. Para uma cadeia puramente linear, isso significa de cima para baixo.

NÃO feche ou modifique nenhum problema pai.

<modelo de ingresso local>

# <NN>: <Título do ticket>

**O que construir:** o comportamento de ponta a ponta que esse ticket faz funcionar, da perspectiva do usuário, e não uma lista de implementação camada por camada.

**Bloqueado por:** os números/títulos dos ingressos que bloqueiam este, ou "Nenhum (pode começar imediatamente)".

**Status:** pronto para agente

- [ ] Critério de aceitação 1
- [ ] Critério de aceitação 2

</local-ticket-template>

<modelo de problema>

## Pai

Uma referência ao problema pai no rastreador (se a origem for um problema existente, caso contrário, omita esta seção).

## O que construir

O comportamento ponta a ponta desse ticket funciona, da perspectiva do usuário, e não da implementação camada por camada.

## Critérios de aceitação

- [ ] Critério 1
- [ ] Critério 2

## Bloqueado por

- Uma referência a cada ticket de bloqueio, ou “Nenhum (pode iniciar imediatamente)”.

</issue-template>

De qualquer forma, evite caminhos de arquivo ou trechos de código específicos: eles ficam obsoletos rapidamente. Exceção: se um protótipo produziu um trecho que codifica uma decisão com mais precisão do que a prosa (máquina de estado, redutor, esquema, forma de tipo), incorpore-o e observe brevemente que ele veio de um protótipo. Corte para as partes ricas em decisões, não para uma demonstração funcional, apenas para as partes importantes.