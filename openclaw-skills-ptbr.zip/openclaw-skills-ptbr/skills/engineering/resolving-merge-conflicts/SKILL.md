---
name: resolving-merge-conflicts
description: "Use quando você precisar resolver um conflito de mesclagem/rebase do git em andamento."
---

1. **Veja o estado atual** da mesclagem/rebase. Verifique o histórico do git e os arquivos conflitantes.

2. **Encontre as fontes primárias** de cada conflito. Entenda profundamente por que cada mudança foi feita e qual era a intenção original. Leia as mensagens de commit, verifique os PRs, verifique os problemas/tickets originais.

3. **Resolva cada problema.** Preserve ambas as intenções sempre que possível. Quando incompatível, escolha aquele que corresponda ao objetivo declarado da fusão e observe a compensação. **Não** invente novos comportamentos. Sempre resolva; nunca `--abort`.

4. Descubra as **verificações automatizadas** do projeto e execute-as, normalmente typecheck, depois testes e depois formate. Corrija tudo o que a mesclagem quebrou.

5. **Conclua a mesclagem/rebase.** Prepare tudo e confirme. Se estiver fazendo rebase, continue o processo de rebase até que todos os commits sejam rebaseados.