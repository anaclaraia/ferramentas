---
name: diagnosing-bugs
description: Loop de diagnóstico para bugs graves e regressões de desempenho. Use quando o usuário disser "diagnosticar"/"depurar isto" ou relatar algo quebrado/lançando/falhando/lento.
---

# Diagnosticando Erros

Uma disciplina para bugs difíceis. Pule fases apenas quando explicitamente justificado.

Ao explorar a base de código, leia `CONTEXT.md` (se existir) para obter um modelo mental claro dos módulos relevantes e verifique os ADRs na área que você está tocando.

## Redigir

Esta habilidade permite mostrar comandos, saídas e artefatos capturados. **Edite cada segredo primeiro**: escreva `<REDACTED>` em seu lugar. Crie loops contra env vars, para que a credencial permaneça no ambiente e não no que você mostra. Os artefatos capturados carregam cabeçalhos de autenticação: cite apenas as linhas que carregam o sinal.

Se a saída redigida não for suficiente para diagnosticar o bug, diga isso e pergunte ao usuário.

## Fase 1: Construa um ciclo de feedback

**Esta é a habilidade.** Todo o resto é mecânico. Se você tiver um sinal de aprovação/reprovação **firme** para o bug (um que fica vermelho neste bug), você encontrará a causa; bissecção, teste de hipóteses e instrumentação apenas o consomem. Se você não tiver um, nenhuma quantidade de código irá salvá-lo.

Gaste um esforço desproporcional aqui. ** Seja agressivo. Seja criativo. Recuse-se a desistir.**

### Maneiras de construir um, aproximadamente nesta ordem

1. **Falha no teste** em qualquer costura que atinja o bug: unidade, integração, e2e.
2. **Script Curl/HTTP** em um servidor de desenvolvimento em execução.
3. **Invocação CLI** com uma entrada de fixture, comparando stdout com um snapshot em bom estado.
4. **Script de navegador sem cabeça** (Playwright / Puppeteer) que orienta a IU e afirma no DOM/console/rede.
5. **Reproduza um rastreamento capturado.** Salve uma solicitação de rede/carga útil/log de eventos reais no disco; reproduza-o através do caminho do código isoladamente.
6. **Armazenamento descartável.** Crie um subconjunto mínimo do sistema (um serviço, dependências simuladas) que exercite o caminho do código do bug com uma única chamada de função.
7. **Loop de propriedade/fuzz.** Se o bug for "saída às vezes errada", execute 1000 entradas aleatórias e procure o modo de falha.
8. **Arnês de biseção.** Se o bug apareceu entre dois estados conhecidos (confirmação, conjunto de dados, versão), automatize "inicializar no estado X, verificar, repetir" para que você possa `git bisect run`.
9. **Loop diferencial.** Execute a mesma entrada por meio da versão antiga versus nova versão (ou duas configurações) e saídas diff.
10. **Script bash HITL.** Último recurso. Se um humano precisar clicar, conduza _eles_ com `scripts/hitl-loop.template.sh` para que o loop ainda esteja estruturado. A saída capturada é enviada de volta para você.

Crie o ciclo de feedback correto e o bug será 90% corrigido.

### Aperte o laço

Trate o loop como um produto. Depois de ter _um_ loop, **aperte**:

- Posso fazer isso mais rápido? (Configuração do cache, pule a inicialização não relacionada, restrinja o escopo do teste.)
- Posso deixar o sinal mais nítido? (Afirme o sintoma específico, não "não travou".)
- Posso torná-lo mais determinístico? (Definir hora, semear RNG, isolar sistema de arquivos, congelar rede.)

Um loop instável de 30 segundos é pouco melhor do que nenhum loop; um determinístico de 2 segundos é rígido, uma superpotência de depuração.

### Bugs não determinísticos

O objetivo não é uma reprodução limpa, mas uma **taxa de reprodução mais alta**. Faça um loop no gatilho 100×, paralelize, adicione estresse, estreite as janelas de tempo, injete sonos. Um bug de 50% é depurável; 1% não é, então continue aumentando a taxa até que seja depurável.

### Quando você realmente não consegue construir um loop

Pare e diga isso explicitamente. Liste o que você tentou. Solicite ao usuário: (a) acesso a qualquer ambiente que o reproduza, (b) um artefato capturado editado (arquivo HAR, dump de log, dump principal, gravação de tela com carimbos de data e hora) ou (c) permissão para adicionar instrumentação de produção temporária. **Não** prossiga com hipóteses sem um loop.

### Critério de conclusão: um loop apertado que fica vermelho

A fase 1 é concluída quando o loop é **apertado** e **com capacidade para vermelho**: você pode nomear **um comando** (um caminho de script, uma invocação de teste, um curl) que você **já executou pelo menos uma vez** (mostrar a invocação e sua saída, redigida), e isso é:

- [ ] **Compatível com vermelho**: direciona o caminho real do código do bug e afirma o **sintoma exato do usuário**, para que possa ficar vermelho nesse bug e verde depois de corrigido. Não "executa sem erros"; ele deve ser capaz de _capturar esse bug específico_.
- [ ] **Determinístico**: mesmo veredicto a cada execução (bugs esquisitos: uma alta taxa de reprodução fixa, conforme acima).
- [ ] **Rápido**: segundos, não minutos.
- [ ] **Executável por agente**: você pode executá-lo sem supervisão; um humano no circuito apenas via `scripts/hitl-loop.template.sh`.

Se você se pegar lendo código para construir uma teoria antes que esse comando exista, **pare: pular direto para uma hipótese é a falha exata que essa habilidade evita.** Sem comando com capacidade vermelha, sem Fase 2.

## Fase 2: Reproduzir + minimizar

Execute o loop. Observe-o ficar vermelho quando o bug aparecer.

Confirme:

- [ ] O loop produz o modo de falha que o **usuário** descreveu, e não uma falha diferente que esteja próxima. Bug errado = correção errada.
- [ ] A falha é reproduzível em múltiplas execuções (ou, para bugs não determinísticos, reproduzível em uma taxa alta o suficiente para depuração).
- [ ] Você capturou o sintoma exato (mensagem de erro, saída errada, tempo lento) para que as fases posteriores possam verificar se a correção realmente resolve o problema.

### Minimizar

Quando estiver vermelho, reduza a reprodução para o **menor cenário que ainda fica vermelho**. Corte entradas, chamadores, configuração, dados e etapas **uma de cada vez**, executando novamente o loop após cada corte e mantenha apenas o que suporta a falha.

Por que se preocupar: uma reprodução mínima reduz o espaço de hipóteses na Fase 3 (menos partes móveis restantes para suspeitar) e se torna o teste de regressão limpo na Fase 5.

Feito quando **todos os elementos restantes suportam carga**: remover qualquer um deles faz com que o loop fique verde.

Não prossiga até ter reproduzido **e** minimizado.

## Fase 3: Hipótese

Gere **3–5 hipóteses classificadas** antes de testar qualquer uma delas. A geração de hipótese única ancora-se na primeira ideia plausível.

Cada hipótese deve ser **falsificável**: declare a previsão que ela faz.

> Formato: "Se <X> for a causa, então <alterar Y> fará com que o bug desapareça / <alterar Z> irá piorá-lo."

Se você não consegue afirmar a previsão, a hipótese é uma vibração: descarte-a ou aprimore-a.

**Mostre a lista classificada ao usuário antes de testar.** Eles geralmente têm conhecimento de domínio que reclassifica instantaneamente ("acabamos de implantar uma mudança para o número 3") ou conhecem hipóteses que já descartaram. Posto de controle barato, grande economia de tempo. Não bloqueie isso; prossiga com sua classificação se o usuário for AFK.

## Fase 4: Instrumento

Cada sonda deve ser mapeada para uma previsão específica da Fase 3. **Altere uma variável de cada vez.**

Preferência de ferramenta:

1. **Inspeção do depurador/REPL** se o ambiente suportar. Um ponto de interrupção supera dez logs.
2. **Registros direcionados** nos limites que distinguem as hipóteses.
3. Nunca "registre tudo e grep".

**Marque cada log de depuração** com um prefixo exclusivo, por exemplo `[DEBUG-a4f2]`. A limpeza no final torna-se um único grep. Os logs não marcados sobrevivem; logs marcados morrem.

**ramificação de desempenho.** Para regressões de desempenho, os logs geralmente estão errados. Em vez disso: estabeleça uma medida de linha de base (equipamento de tempo, `performance.now()`, criador de perfil, plano de consulta) e, em seguida, divida. Meça primeiro, corrija depois.

## Fase 5: Correção + teste de regressão

Escreva o teste de regressão **antes da correção**, mas somente se houver uma **junção correta** para ele.

Uma costura correta é aquela em que o teste exercita o **padrão de bug real** conforme ocorre no site da chamada. Se a única costura disponível for muito superficial (teste de chamador único quando o bug precisa de vários chamadores, teste de unidade que não pode replicar a cadeia que acionou o bug), um teste de regressão fornece falsa confiança.

**Se não existir nenhuma costura correta, essa é a descoberta.** Observe. A arquitetura da base de código está evitando que o bug seja bloqueado. Sinalize isso para a próxima fase.

Se existir uma costura correta:

1. Transforme a reprodução minimizada em um teste com falha nessa costura.
2. Observe o fracasso.
3. Aplique a correção.
4. Observe passar.
5. Execute novamente o ciclo de feedback da Fase 1 em relação ao cenário original (não minimizado).

## Fase 6: Limpeza

Obrigatório antes de declarar concluído:

- [] A reprodução original não é mais reproduzida (execute novamente o loop da Fase 1)
- [] Teste de regressão aprovado (ou ausência de costura documentada)
- [] Toda a instrumentação `[DEBUG-...]` removida (`grep` o prefixo)
- [] Protótipos descartáveis excluídos (ou movidos para um local de depuração claramente marcado)
- [] A hipótese que deu certo é declarada na mensagem de commit/PR, para que o próximo depurador aprenda