---
name: claude-handoff
description: Passe a conversa atual para um novo agente em segundo plano que iniciará o trabalho imediatamente.
argument-hint: "Para que será usada a próxima sessão?"
disable-model-invocation: true
---

Escreva um resumo da transferência da conversa atual para que um novo agente possa continuar o trabalho. Em vez de salvá-lo, inicie um agente em segundo plano propagado com o resumo como prompt: `claude --bg --name "<descriptive name>" "<handoff summary>"`. Inicia no diretório de trabalho atual e retorna imediatamente; o usuário gerencia-o com `claude agents`.

Passe sempre `-n`/`--name` com um nome descritivo (ex.: `--name "Fix login bug"`); ele define o nome de exibição mostrado na lista de tarefas, no seletor de sessão e no título do terminal.

Inclua uma seção de “habilidades sugeridas” no resumo, nomeando quais habilidades o próximo agente deve chamar a habilidades.

Não duplique conteúdo já capturado em outros artefatos (especificações, planos, ADRs, problemas, commits, diffs). Referencie-os por caminho ou URL.

Edite quaisquer informações confidenciais, como chaves de API, senhas ou informações de identificação pessoal, já que o resumo se torna o prompt do agente.

Se o usuário passou argumentos, trate-os como uma descrição do foco da próxima sessão e adapte o resumo de acordo.