# Em andamento

Beta. Essas habilidades são públicas de propósito: experimente-as e diga-me o que funciona. Eles são excluídos do plug-in e do README de nível superior até que passem para um intervalo estável, não recebam páginas de documentos e possam mudar ou desaparecer sem aviso prévio.

O plugin não fornecerá isso. Instale um diretamente:

```bash
npx skills@latest add mattpocock/skills --skill=<name>
```

- **[loop-me](./loop-me/SKILL.md)**: conheça as especificações de fluxo de trabalho implementáveis em diversas sessões, usando o diretório atual como um espaço de trabalho com estado. Invocado pelo usuário.
- **[writing-beats](./writing-beats/SKILL.md)**: Molde um artigo como uma jornada de batidas, escolha seu próprio estilo de aventura. Escolha uma batida inicial, escreva apenas essa batida e depois passe para a próxima, até que o artigo chegue a um final natural.
- **[writing-fragments](./writing-fragments/SKILL.md)**: Sessão de grelha que explora fragmentos (pepitas heterogêneas de escrita) e os anexa a um único documento como matéria-prima para um artigo futuro.
- **[writing-shape](./writing-shape/SKILL.md)**: Pegue um arquivo markdown de matéria-prima e molde-o em um artigo, parágrafo por parágrafo, discutindo as opções de formato em cada etapa.
- **[claude-handoff](./claude-handoff/SKILL.md)**: transfere a conversa atual para um novo agente em segundo plano que assume o trabalho imediatamente, propagado com um resumo de transferência via `claude --bg`. Invocado pelo usuário.
- **[setup-ts-deep-modules](./setup-ts-deep-modules/SKILL.md)**: conecte o dependency-cruiser a um repositório TypeScript para que cada pacote seja um módulo profundo: implementação oculta em subpastas, acessível apenas por meio de seus arquivos de ponto de entrada, testes exercitando-o por meio deles. Invocado pelo usuário.
- **[implement-spec](./implement-spec/SKILL.md)**: Implemente uma especificação completa em uma ramificação. Funciona os tickets como um gráfico de tarefas em vez de uma lista, executando subagentes do implementador através da fronteira pronta para máxima simultaneidade e obtendo o resultado como um único PR. Invocado pelo usuário.
- **[pr](./pr/SKILL.md)**: Referência para a forma que um corpo de pull request deve assumir: um resumo da fonte primária (não a diferença), o menor visual que mostra a mudança, um par de evidências antes/depois, o que foi deixado de fora propositalmente e uma chamada de porta unidirecional/bidirecional. Invocado por modelo.
- **[retro](./retro/SKILL.md)**: Sugira melhorias no ambiente do agente de codificação (arquivos de direção, padrões de codificação, verificações automatizadas, ferramentas) após uma sessão. STUB: apenas notas de design, ainda não funcionais. Invocado pelo usuário.