---
name: writing-shape
description: "Escrever, explorar: transformar a matéria-prima em um artigo, parágrafo por parágrafo."
disable-model-invocation: true
---

<o que fazer>

O usuário passou (ou passará) por um arquivo markdown de matéria-prima. Trate-o como uma pilha de entrada: qualquer coisa, desde uma lista organizada de fragmentos até uma parede de prosa não estruturada e uma transcrição. O formato não importa. Leia-o de ponta a ponta antes de fazer qualquer outra coisa.

Em seguida, execute uma sessão de modelagem que produza um documento de artigo separado. Isso é **explorar**: a exploração está feita, a pilha está consertada: comprometa-se com uma estrutura e minere a pilha para preenchê-la. Não edite o arquivo de matéria-prima: ele é somente leitura para esta habilidade.

Caso o usuário não tenha informado onde salvar o artigo, pergunte uma vez e lembre-se do caminho.

</o que fazer>

<informações de suporte>

## O ciclo

1. **Leia a pilha.** Leia o arquivo de entrada na íntegra. Forme uma noção do que há nele.
2. **Estabeleça os pré-requisitos.** Defina com o usuário o que o leitor sabe ao entrar: os conceitos que estão **fundamentados** desde o início. Todo o resto deve ser aterrado por um bloco antes que um bloco posterior possa se apoiar nele. Consulte [Grounding](#grounding).
3. **Rascunho de 2 a 3 vagas para candidatos.** Cada vaga deve implicar uma tese ou ângulo diferente para o artigo. Mostre todos eles. Force o usuário a escolher ou compor um híbrido. A abertura escolhida define o que o restante do artigo deve fazer.
4. **Aumente parágrafo por parágrafo.** Após a abertura, pergunte "dada esta abertura, o que o leitor precisa ouvir a seguir?" Retire o material da pilha para responder. O próximo bloco pode apoiar-se apenas em conceitos fundamentados e fundamentar novos à medida que chega. Discuta sobre a forma que o próximo bloco assume: um parágrafo, uma lista, uma tabela, um texto explicativo, uma citação, um bloco de código. Cada escolha de formato deve ser deliberada e defensável.
5. **Anexar ao arquivo do artigo conforme você avança.** Não faça lote. Escreva cada parágrafo ou bloco acordado imediatamente para que o usuário possa ver o artigo tomando forma.
6. **Repita a etapa 4 até que o artigo seja concluído.** O usuário decide quando terminar.

## Aterramento

Cada **conceito** tem que ser **fundamentado** antes que um bloco possa se apoiar nele: o leitor entrou sabendo disso ou o encontrou em um bloco anterior. Um bloco que busca um conceito infundado perde o leitor. A unidade é o conceito, não a palavra para ele: um bloco pode se apoiar em uma ideia que falta ao leitor, mesmo sem nenhum jargão à vista. Quando um conceito tem um nome (um **termo**), fundamentá-lo significa unir a ideia e o termo.

Um conceito é fundamentado de duas maneiras:

- **Pré-requisito**: aterramento antes da abertura. O leitor traz isso. Corrigido no início.
- **Introduzido**: um bloco o estabelece e a partir daí é fundamentado para o restante do artigo.

Mantenha uma lista contínua do que está fundamentado. Quando você pergunta "o que o leitor precisa ouvir a seguir?", um conceito infundado que o próximo movimento precisa é em si a resposta: fixe-o primeiro (aqui ou em um bloco anterior) ou você não poderá realizar o movimento. Esta é a nomenclatura da lacuna de [Pulling from the pile](#pulling-from-the-pile) um nível acima: ali falta material na pilha; aqui o artigo está faltando uma base.

A alavanca é o que você considera um pré-requisito versus o que você fundamenta no artigo. Exija muito antecipadamente e você excluirá os leitores; aterramos muito por dentro e a abertura se afoga em definições. Acerte isso com o usuário ao estabelecer pré-requisitos.

## Sensação de conversação

Esta é uma sessão de grelhados invertida. Na idealização, a pergunta era "o que você está realmente percebendo?" Aqui está "o que este artigo está realmente argumentando e em que ordem o leitor precisa ouvi-lo?" Empurre para trás. Recuse-se a deixar passar transições fracas. Se um parágrafo não merecer o seu lugar, corte-o.

Movimentos específicos para continuar usando:

- "O que este parágrafo faz pelo leitor que o anterior não fez?"
- "Se eu cortar isso, o que quebra?"
- "Isso é prosa ou deveria ser uma lista? Por que prosa?"
- "Esta frase tem duas funções: divida-a ou escolha uma."
- "A abertura prometida X. Nós mudamos para Y. Reenfie ou mude a abertura."

## Tirando da pilha

Trate a matéria-prima como uma pedreira e não como um roteiro. Puxe um fragmento, refaça-o para caber no parágrafo circundante e posicione-o. Um fragmento pode ser dividido em vários parágrafos, mesclado com outro ou parafraseado. A função da pilha é ser minerada; a função do artigo é ser lida em uma só voz.

Se a pilha não tiver algo que o artigo precisa, nomeie a lacuna explicitamente: "Precisamos de um exemplo aqui e a pilha não tem. Dê-me um agora ou cortaremos esta seção."

## Formate argumentos para realmente ter

Ao escolher como renderizar um bloco, avalie essas compensações em voz alta com o usuário, e não silenciosamente:

- **Prosa vs. lista.** A prosa carrega argumentos; listas carregam itens paralelos. Se os itens não forem verdadeiramente paralelos, a prosa é melhor. Se estiverem, uma lista será mais rápida de verificar.
- **Inline vs. callout.** Dicas, avisos e apartes vão em callouts (`> [!TIP]`, `> [!NOTE]`), mas apenas se eles realmente atrapalharem o argumento principal inline. Caso contrário, deixe-os alinhados.
- **Tabela vs. estrutura repetida.** Se a mesma forma se repetir mais de 3 vezes com os mesmos campos, uma tabela. Caso contrário, prosa com pistas ousadas.
- **Citação vs. paráfrase.** Cite quando o texto original for o ponto. Parafraseie quando apenas a ideia importa.
- **Bloco de código vs. código embutido.** Multilinha, executável ou ilustrativo → bloco. Token ou identificador único → embutido.

## Ritmo de escrita

Anexe ao arquivo do artigo conforme cada bloco for acordado. Releia o arquivo do disco antes de cada gravação: o usuário pode ter editado entre turnos. Nunca substitua cegamente. Se o usuário quiser reescrever um parágrafo, edite esse parágrafo específico; deixe o resto em paz.

## Fora do escopo

- Mineração de novos fragmentos que não estão na pilha (lidar com as lacunas como em "Puxar da pilha").
- Edição do arquivo de matéria prima.
- Publicar, formatar para uma plataforma específica ou adicionar frontmatter que o usuário não solicitou.

</supporting-info>