---
name: pr
description: "Use ao escrever um corpo de relações públicas."
metadata:
  credits:
    skill: mostre-me
    author: Dex Horthy
    organisation: Humanlayer
    url: "https://github.com/humanlayer/skills/blob/main/plugins/show-me/skills/show-me/SKILL.md"
---

Use este modelo para escrever o corpo de relações públicas:

```markdown
## Summary

<diagram, diff-sketch, or tree>

## Evidence

- **Before:** <screenshot/output/failing test run>
  **After:** <screenshot/output/passing test run>

## Merge Danger

**Door:** <one-way or two-way>

<optional: description>

**Blast Radius:** <one-word description>

<optional: potential ramifications of merge>
```

## Seções

Pule todos os preâmbulos e mantenha a prosa breve. Use o idioma de domínio do usuário de `CONTEXT.md`.

### Resumo

Escolha a menor visualização que deixe claro o ponto-chave.

- Mostrar lógica ou algoritmo como pseudocódigo:

```text
on(save)
  if content is unchanged
    return cached result
  write new content
  return fresh result
```

- Mostrar fluxo de controle de tempo de execução como uma árvore de chamadas:

```text
submitForm
  createSession
    persistPrompt
    launchAgent
  navigateToSession
```

- Mostre a estrutura da UI como uma árvore de componentes, incluindo limites de estado e módulo importantes:

```tsx
<SessionPage>(apps / example / src / routes / session.tsx);
useSessionEvents() < SessionToolbar > <RunSkillButton>(packages / ui);
```

- Mostre a responsabilidade do arquivo ou uma refatoração ampla como uma árvore de arquivos superficial:

```text
src/
├── commands/       # parses user actions
├── sessions/       # owns session state
└── transport/      # sends API requests
```

- Mostre interação de componentes, fluxo de controle ou fluxo de dados com Mermaid:

```mermaid
sequenceDiagram
    participant User
    participant UI
    participant Daemon
    User->>UI: choose command
    UI->>Daemon: send expanded prompt
    Daemon-->>UI: stream result
```

- Use `diff` quando o ponto é o que muda e a forma circundante já existe. Combine a forma diferente com o tópico.

Para uma alteração de componente:

```diff
 <SessionPage>
   useSessionEvents()
   <SessionToolbar>
+    <RunSkillButton />
   <SessionTimeline>
+    <SkillResultCard />
```

Para uma alteração no layout do arquivo:

```diff
 src/
 ├── commands/
+│   └── show-me.ts       # expands the slash command
 ├── sessions/
-└── transport.ts
+└── transport/
+    ├── client.ts
+    └── stream.ts
```

Para uma mudança na árvore de chamadas ou na pilha de chamadas:

```diff
 submitForm
   createSession
     persistPrompt
+    expandSkillMention
     launchAgent
-  navigateToSession
+  navigateToSession
+    subscribeToEvents
```

Para uma mudança de estado ou fluxo de controle:

```diff
 on(save)
-  write content
+  if content is unchanged
+    return cached result
+  write new content
+  invalidate cache
```

- Mostrar o bloco inteiro quando a maior parte dele for nova, quando o contexto omitido ocultaria a propriedade ou a ordem ou quando o usuário precisar de uma forma de destino copiável:

```ts
function expandSkill(command: string): string {
  const skillName = command.slice(1);
  return `use the ${skillName} skill`;
}
```

#### Orientação

Coloque cada visual próximo ao texto curto que ele suporta. Mantenha apenas as chamadas, arquivos, adereços, estados e limites necessários para responder à pergunta atual do usuário ou às opções para resolver o ponto de discussão atual.

Você pode usar um deles, pode usar vários, é improvável que use todos eles. Use seu julgamento e não sobrecarregue o usuário.

### Evidência

Evidências concretas de que a mudança funciona. Mostre um antes e depois.

As capturas de tela são de nível S - quando o ambiente está configurado para isso e a mudança é visual.

A evidência baseada em execução é de nível A. Resultados do teste, saída do console. Mostre o teste exato que agora falhou e foi aprovado, usando pseudocódigo.

### Mesclar Perigo

Descreva se é uma porta unidirecional ou bidirecional. Você pode voltar por portas de mão dupla, mas não por portas de mão única. Um PR barato para reverter apresenta menor risco. Mudanças que envolvem ações destrutivas ou decisões difíceis de reverter são portas de mão única.

O raio da explosão é o impacto potencial ou o escopo das alterações introduzidas por esta PR. Considere todas as possibilidades. Exemplos são mudança de layout, interrupções para consumidores, capacidade de resposta móvel, etc.