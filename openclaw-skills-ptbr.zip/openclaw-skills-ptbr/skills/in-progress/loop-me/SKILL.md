---
name: loop-me
description: Pergunte-me sobre as especificações dos fluxos de trabalho que desejo construir neste espaço de trabalho.
disable-model-invocation: true
argument-hint: "Um fluxo de trabalho para projetar ou nada para encontrar um"
---

Execute uma sessão `/grilling` com estado cuja única saída são especificações de **fluxo de trabalho**. Use a disciplina de grelhar (incansável, uma rodada de perguntas por vez, uma resposta recomendada anexada a cada uma) visando o vocabulário e o objetivo abaixo. Crie, edite e exclua especificações enquanto o grelhador resolve as coisas.

## A lente circular

Um **loop** é um padrão recorrente na vida do usuário: sua carreira, sua semana, sua manhã, uma única atividade repetida. Retratar uma vida como loops dentro de loops revela o quão previsíveis suas atividades realmente são, e é isso que faz com que valha a pena **delegá-las**. Use a lente para encontrar loops que valem a pena especificar e proponha aqueles que o usuário não percebeu.

Um **fluxo de trabalho** é a especificação de um loop, tornado real. Você executa um fluxo de trabalho em um loop: o loop é sua instanciação em execução. Os fluxos de trabalho residem em `workflows/*.md` e são a fonte da verdade.

## Vocabulário

Uma linguagem compartilhada, acessível apenas quando um fluxo de trabalho exige: nunca uma lista de verificação. **Não exija nada estrutural**: um fluxo de trabalho não precisa de IA, de ponto de verificação e de cronograma, a menos que o interrogatório mostre que sim.

- **Gatilho**: o que aciona cada execução, um **evento** (um novo e-mail, um novo problema) ou um **agendamento** (todas as manhãs). O acionamento de eventos geralmente é o mais eficiente.
- **Ponto de verificação**: um ponto humano no circuito onde o usuário é solicitado a verificar ou decidir. Alguns fluxos de trabalho não possuem nenhum e são executados de forma autônoma; alguns não usam IA.
- **Empurre para a direita**: adie o ponto de verificação até onde for possível. Faça o trabalho máximo antes de envolver o humano, para que seja solicitado uma vez, tarde, com tudo preparado.
- **Breve**: o que um ponto de verificação apresenta, um resumo preciso e pronto para decisão (o que foi produzido, por que e um link para o ativo em si), nunca o resultado bruto. O usuário lê um resumo, não um rascunho. A velocidade da revisão é fundamental.

## Definição de pronto

Uma especificação de fluxo de trabalho é feita quando um agente implementador pode construí-lo sem fazer uma única pergunta. Grelhe até então; nada é feito enquanto permanece uma questão.

## O espaço de trabalho

- `workflows/*.md`: uma especificação por fluxo de trabalho.
- `NOTES.md`: notas brutas sobre o mundo do usuário, as ferramentas que ele utiliza, os canais que processa e sua própria terminologia para ambos. Quando estiver vazio ou escasso, entreviste-os sobre seu mundo antes de especificar qualquer coisa. Transforme os termos difusos em termos canônicos à medida que surgem e registre-os aqui.