---
name: setup-ts-deep-modules
description: conecte o dependency-cruiser a um repositório TypeScript para que cada pacote seja um módulo profundo, com implementação oculta em subpastas e acessível apenas por meio de seus arquivos de ponto de entrada. Invocado pelo usuário.
disable-model-invocation: true
---

# Configurar módulos profundos do TS

Faça de cada pacote neste repositório um **módulo profundo**: muito comportamento por trás de uma interface pequena. A superfície pública de um pacote são seus **pontos de entrada** (os arquivos na raiz do pacote), e tudo em suas subpastas fica oculto. Esta habilidade instala [dependency-cruiser](https://github.com/sverweij/dependency-cruiser) e as regras que tornam os pontos de entrada a única maneira de entrar e, em seguida, prova que as regras funcionam.

Para o vocabulário (módulo profundo, interface, costura, profundidade), ative a skill com "codebase-design" e use sua linguagem por toda parte.

## A forma que isso impõe

```
src/packages/
  <name>/
    index.ts        ← an entry point (public). Import this from outside.
    client.ts       ← another entry point. Packages may expose SEVERAL.
    lib/            ← implementation: hidden from outside, free to import each other.
    tests/          ← co-located tests + fixtures (a subfolder, so private).
```

A superfície pública são os **arquivos raiz** do pacote, e não um `index.ts` designado. Por convenção, a implementação reside em `lib/` e os testes em `tests/`, dando a cada pacote o mesmo formato de duas pastas. A regra em si é geral: *qualquer coisa* em *qualquer* subpasta é privada, então você nunca estende a configuração para adicionar uma pasta.

Quatro regras, todas `error`:

1. **Limite do ponto de entrada**: o código fora de um pacote (código do aplicativo ou outro pacote) pode importar apenas os pontos de entrada desse pacote (seus arquivos raiz), nunca nada em suas subpastas.
2. **Liberdade dentro do pacote**: os próprios arquivos de um pacote importam uns aos outros livremente.
3. **Testes através dos pontos de entrada**: os arquivos em `<pkg>/tests/` podem importar os pontos de entrada de qualquer pacote e seus próprios fixtures `tests/`, mas nunca os internos de qualquer subpasta do pacote (nem mesmo os seus próprios). Os testes de integração entre pacotes são adequados; importações profundas não são.
4. **Sem ciclos**: sem ciclos de dependência.

**Pontos de entrada, não um barril.** Como a superfície pública é *cada* arquivo raiz, um pacote pode expor vários pontos de entrada pequenos (`index.ts`, `client.ts`, `server.ts`) em vez de canalizar tudo através de um `index.ts` gigante. Arquivos barril que reexportam uma subárvore inteira são desencorajados; mantenha os pontos de entrada pequenos e oculte a implementação em subpastas.

A disposição em camadas (quais pacotes podem depender de quais) é uma preocupação *diferente* e é deixada como um esboço comentado na configuração para este repositório preencher.

## Etapas

### 1. Detecte o ambiente

- **Gerenciador de pacotes**: `pnpm-lock.yaml` → pnpm, `yarn.lock` → fio, `bun.lockb` → coque, senão npm. Use-o para cada comando abaixo (`pnpm`/`yarn`/`npm run`/`bunx`).
- **Pacotes raiz**: se `src/` existir, use `src/packages`, caso contrário, `packages`. Confirme a escolha com o usuário se o repositório já tiver uma convenção óbvia diferente.
- **Configuração existente**: verifique se há um arquivo `.dependency-cruiser.*`. Se existir, **não** sobrescreva-o: mescle as quatro regras e as opções e informe ao usuário o que você adicionou.

**Feito quando:** o gerenciador de pacotes, a raiz dos pacotes e o status da configuração existente são todos conhecidos.

### 2. Instale o cruzador de dependência

Instale `dependency-cruiser` como devDependency com o gerenciador de pacotes detectado.

**Feito quando:** `dependency-cruiser` está em `devDependencies`.

### 3. Escreva a configuração

Copie [`dependency-cruiser.config.cjs`](./dependency-cruiser.config.cjs) para a raiz do repositório como `.dependency-cruiser.cjs`. Defina `PACKAGES_ROOT` para a raiz detectada na etapa 1. As regras são baseadas na profundidade do caminho e independentes de extensão, portanto, nada mais precisa de adaptação.

**Feito quando:** `.dependency-cruiser.cjs` existir com o `PACKAGES_ROOT` correto e as quatro regras proibidas estiverem presentes.

### 4. Conecte-o aos cheques

- Adicione um script `lint:boundaries`: `depcruise <packages-root>` (ou `depcruise src`).
- Dobre-o no comando de verificação abrangente do repositório, aquele que já executa o typecheck (por exemplo, um script `check` / `ci` / `validate`). **Não** toque em `tsconfig` ou adicione aliases de caminho.
- Se não houver um script abrangente, adicione `lint:boundaries` e diga ao usuário para incluí-lo no CI.

**Feito quando:** `lint:boundaries` existe e é executado como parte do mesmo comando que typecheck.

### 5. Crie o pacote de exemplo

Crie um `<packages-root>/example/` confirmado como um modelo copie-me:

- `index.ts` é um ponto de entrada. Exporte uma função que delega para um arquivo interno (para que o pacote seja visivelmente *profundo*, não uma passagem).
- `lib/impl.ts`: um arquivo interno em uma **subpasta**, importado por `index.ts`, não acessível de fora.
- `tests/example.test.ts` importa **apenas** `../index` (um ponto de entrada) e afirma contra a função pública.

Diga ao usuário que este é um modelo inicial para copiar ou excluir.

**Feito quando:** o pacote de exemplo existe, expõe seu comportamento por meio de um ponto de entrada raiz e oculta `impl` em uma subpasta.

### 6. Prove que as regras são válidas

Este é o critério de conclusão para toda a habilidade: uma configuração que não falha em uma violação não vale nada.

1. Execute `lint:boundaries`. Deve **passar** no exemplo limpo.
2. Adicione temporariamente uma importação profunda a `tests/example.test.ts` (por exemplo, `import { thing } from "../lib/impl"`). Execute `lint:boundaries` novamente; deve **falhar** com `tests-through-entrypoints`.
3. Reverta a importação profunda. Execute mais uma vez e deverá **passar**.

**Feito quando:** você observou uma aprovação, depois uma falha na importação profunda e, em seguida, uma aprovação novamente. Se a etapa 2 não falhar, as regras não estão conectadas corretamente, então corrija antes de terminar.

### 7. Documente a convenção

Escreva um `README.md` **na pasta de pacotes** (`<packages-root>/README.md`, próximo aos pacotes que ele governa) cobrindo: o layout `src/packages/<name>/` (pontos de entrada na raiz, `lib/` para implementação, `tests/` para testes), "importar apenas através dos pontos de entrada de um pacote (seus arquivos raiz)" e como executar `lint:boundaries`. **Desencoraje arquivos barril** explicitamente: exponha vários pontos de entrada pequenos em vez de reexportar uma subárvore inteira por meio de um índice. Limite-se ao trecho copie-me mais as quatro regras em um parágrafo cada.

Em seguida, adicione um **ponteiro de contexto** a ele a partir do arquivo de instruções do agente do repositório (`CLAUDE.md` se presente, caso contrário, `AGENTS.md`, criando `AGENTS.md` se nenhum existir). Uma linha é suficiente, por ex. `Packages are deep modules: see [src/packages/README.md](./src/packages/README.md) before adding or importing one.` É isso que faz um agente descobrir a regra de limite em vez de tropeçar nela.

**Feito quando:** `<packages-root>/README.md` existe e desencoraja barris, e o `CLAUDE.md`/`AGENTS.md` do repositório está vinculado a ele.

## Notas

- As referências anteriores `$1` da configuração (correspondência de grupo do cruzador de dependência) são o que permite que um pacote alcance seus próprios internos, enquanto estranhos não podem. Não os nivele em regras separadas por pacote.
- Público versus privado é decidido pela **profundidade**: os arquivos raiz de um pacote são pontos de entrada; qualquer coisa em uma subpasta é privada. As subpastas convencionais são `lib/` (implementação) e `tests/`, mas a regra não as codifica: qualquer subpasta é privada, portanto, uma nova pasta nunca precisa de uma alteração na configuração. Adicionar um ponto de entrada é apenas adicionar um arquivo raiz (sem barril).
- Os pacotes são **planos**: uma camada de filhos imediatos sob a raiz. Os componentes internos de um pacote podem aninhar-se tão profundamente quanto você desejar; um pacote não pode conter outro pacote.
- Use `.cjs` (não `.js`) para que o `module.exports` da configuração funcione mesmo em repositórios `"type": "module"`.