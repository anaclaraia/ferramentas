---
name: implement-spec
description: "Implementar uma especificação no código."
disable-model-invocation: true
---

Você recebeu uma especificação. Esta especificação deve ter tickets associados a ela, descrevendo como implementar a especificação.

O objetivo é um PR que implemente todas as especificações em um único branch.

Os tickets não são uma lista de etapas. Eles são um **gráfico de tarefas** com relacionamentos de bloqueio entre eles. Isso significa que sempre há uma **fronteira** de ingressos prontos para serem adquiridos.

A comunicação de e para os subagentes deve ser escassa. Comunique-se principalmente por meio de **indicadores de contexto**: especificações, tickets, notas de pesquisa e commits anteriores. Não duplique informações já disponíveis por meio de ponteiros.

**Os subagentes do implementador** devem ser executados em segundo plano sempre que possível para **simultaneidade máxima**.

## Etapas

1. Leia as especificações e os tickets. Leia o suficiente para entender o gráfico da tarefa.

2. (opcional) Use um **subagente de exploração** para conduzir qualquer exploração exigida pelos tickets - arquivos de base de código relevantes ou documentação externa. Certifique-se de que o subagente de exploração possa salvar arquivos – ele deve salvar suas notas de remarcação em um diretório fora do repositório, acessível a todos os subagentes futuros. Isso permite que os **subagentes implementadores** se concentrem na implementação e não na exploração.

3. Crie uma filial e um rascunho de PR. O PR deve ser marcado como 'fechando' o problema de especificações e os tickets.

4. Use **subagentes implementadores** para implementar cada ticket. Cada subagente implementador deve trabalhar em sua própria árvore de trabalho, em sua própria ramificação.

5. Depois que um **subagente implementador** for concluído, mescle seu trabalho na ramificação PR com um **subagente de fusão**.

6. Se isso alterar a **fronteira** de tickets disponíveis, inicie mais **subagentes implementadores** para trabalhar nos novos tickets. Isso permite a simultaneidade máxima.

7. Assim que todos os tickets forem concluídos, execute /code-review na filial PR. Corrija todos os problemas levantados pela revisão de código em um único **subagente do implementador**.

8. Marque o PR como pronto para revisão.

9. Limpe todas as árvores de trabalho do **subagente do implementador**.