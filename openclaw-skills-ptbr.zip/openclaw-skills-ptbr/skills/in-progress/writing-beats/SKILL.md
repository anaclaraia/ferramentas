---
name: writing-beats
description: Escrever, explorar; reúna a matéria-prima em uma jornada de batidas, fundamentando cada termo antes que uma batida se apoie nele.
disable-model-invocation: true
---

<o que fazer>

O usuário passou (ou passará) por um arquivo markdown de matéria-prima. Isso é **exploração**: a exploração está feita, a pilha está consertada. Comprometa-se com um caminho através dele e explore a pilha para preencher cada batida.

Caso o usuário não tenha informado onde salvar o artigo, pergunte uma vez e lembre-se do caminho.

Em seguida, faça uma jornada passo a passo, escolha seu próprio estilo de aventura:

1. **Estabeleça os pré-requisitos.** Antes de qualquer batida, defina com o usuário o que o público já sabe ao entrar: os conceitos que estão **fundamentados** desde o início. Todo o resto deve ser fundamentado por uma batida antes que uma batida posterior possa utilizá-lo. Consulte [Grounding](#grounding).
2. Escreva 2–3 candidatos **batidas iniciais**, extraídas da matéria-prima. Cada um é um ponto de entrada diferente no artigo. Cada um só pode apoiar-se em conceitos fundamentados; observe quais novos conceitos cada um fundamenta. Mostre ao usuário as batidas antes de gravar no arquivo do artigo. O usuário escolhe um. Visualize o que é melhor que aquela escolha desbloqueia, como se o usuário estivesse vendo um pouco do caminho.
3. Depois que o usuário escolher uma batida inicial, escreva **apenas essa batida** no arquivo do artigo. Uma batida pode ser uma frase ou vários parágrafos, qualquer que seja essa batida naturalmente. Pare aí.
4. Leia novamente o arquivo do artigo no disco. Em seguida, ofereça 2 a 3 candidatos **próximas batidas**: diferentes direções para as quais a jornada pode girar a partir de onde o artigo está agora. Cada um deve ser acessível a partir do conjunto aterrado atual; observe o que cada um fundamenta.
5. Repita as etapas 3 a 5 até que o artigo chegue ao fim natural.

</o que fazer>

<informações de suporte>

## Aterramento

Cada **conceito** tem que ser **fundamentado** antes que uma batida possa se apoiar nele: o público ou entrou sabendo disso ou conheceu-o em uma batida anterior. Uma batida que busca um conceito infundado perde o leitor; esse é o único movimento que a jornada não pode fazer. A unidade é o conceito, não a palavra para descrevê-lo: uma batida pode se basear em uma ideia que falta ao leitor, mesmo sem nenhum jargão à vista. Quando um conceito tem um nome (um **termo**), fundamentá-lo significa unir a ideia e o termo.

Um conceito é fundamentado de duas maneiras:

- **Pré-requisito**: aterrado antes da primeira batida. O público traz isso. Corrigido no início.
- **Introduzido**: uma batida estabelece isso e, a partir de então, é a base para cada batida posterior.

Portanto, cada batida faz duas tarefas: **requer** conceitos que já estão fundamentados e **fundamenta** novos. Mantenha uma lista contínua do que está fundamentado até agora e atualize-a sempre que uma batida chegar.

É isso que molda a escolha da sua própria aventura. Uma batida candidata só é alcançável se tudo o que ela exige já estiver fundamentado; escolher uma batida que aterra o conceito X desbloqueia todas as batidas que estavam esperando em X. Quando você oferece as próximas batidas, todas elas devem ser acessíveis a partir do conjunto aterrado atual e dizer o que cada uma ancora, para que o usuário possa ver quais caminhos ele abre.

A grande alavanca é o que você torna um pré-requisito versus o que você fundamenta dentro da peça. Exija muito antecipadamente e você excluirá leitores que não o possuem; aterra muito por dentro e as primeiras batidas se afogam em definições. Resolva isso com o usuário ao estabelecer pré-requisitos e revise-o sempre que uma batida tentadora exigir um conceito que ainda não foi fundamentado: a solução é uma batida de base antes dela ou promover o conceito a um pré-requisito.

## O que é uma batida

Uma batida é um movimento na jornada. Ele faz uma coisa: cria uma cena, acerta um ponto, faz uma pergunta, deixa de lado, distorce o ângulo. Então ele para, deixando o leitor em um ponto onde a próxima batida pode girar.

Uma batida é dimensionada de acordo com o que precisa:

- Uma única frase, se isso for tudo ("E então nada aconteceu por três semanas.").
- Um pequeno parágrafo se a mudança precisar de configuração.
- Vários parágrafos se a batida for uma vinheta, argumento ou exemplo independente.

Se um “beat” precisa de cinco parágrafos e três subtítulos, não é um beat; são duas batidas coladas. Divida.

## Tirando da pilha

Retire o material da pilha bruta para preencher cada batida. Você pode parafrasear, dividir, recombinar ou citar. A pilha é uma pedreira.

## Terminando a jornada

O artigo termina quando a jornada termina, não quando a pilha está vazia. A maioria das pilhas terá fragmentos restantes que não entram. Tudo bem; esse é o objetivo de ter mais matéria-prima do que você precisa.

## Ritmo de escrita

- Adicione uma batida de cada vez. Nunca escreva adiante.
- Releia o arquivo do artigo no disco antes de cada gravação. Preservar totalmente as edições do usuário.
- Se o usuário editar substancialmente uma batida anterior, deixe-o alterar o que vem a seguir.
- Se o usuário disser “reescreva aquela batida” ou “volte e tente uma batida 3 diferente”, faça: edite no lugar, deixe o resto como está.

</supporting-info>