---
name: writing-fragments
description: "Escrever, explorar: extrair fragmentos brutos, sem estrutura ainda."
disable-model-invocation: true
---

<o que fazer>

Isso é puro **explorar**: ampliar o espaço do que poderia ser escrito sem se comprometer com a estrutura. Comprometer-se é _explorar_, um trabalho de habilidade separado. Faça uma sessão de interrogatório que produza fragmentos, entrevistando incansavelmente o usuário sobre o que ele deseja escrever. A imposição de fases, contornos ou estrutura do artigo está fora do escopo aqui.

À medida que fragmentos emergem de ambos os lados da conversa, anexe-os a um único arquivo markdown.

Se o usuário não passou por um caminho, pergunte uma vez onde salvar o documento e lembre-se dele pelo resto da sessão.

Capture fragmentos da primeira coisa que o usuário disser, incluindo o prompt inicial.

Na primeira escrita, coloque um único H1 no topo com um título provisório (pode mudar mais tarde) e nada mais: sem metadados, sem TOC, sem data.

</o que fazer>

<informações de suporte>

## O que é um fragmento

Um fragmento é qualquer pedaço de texto que possa sobreviver no artigo final. Deve ser _legível pelo autor_ (o autor pode dizer o que significa), mas não precisa definir seus termos ou ser compreensível para um leitor frio. A barreira é "este é um bom texto?", e não "este é um argumento independente?"

Os fragmentos são deliberadamente heterogêneos. Exemplos do que poderia ser um fragmento:

- Uma frase contundente que você gostaria de implantar em algum lugar, mas ainda não sabe onde.
- Uma reclamação com justificativa de uma linha.
- Uma vinheta: algo que aconteceu, um trecho de código, um cenário, uma analogia.
- Um meio pensamento: "algo sobre como X se parece com Y, resolva isso mais tarde."
- Uma citação, um diálogo, uma frase ouvida.
- Uma lista de observações relacionadas que se unem por sentimento.
- Uma reclamação, uma confissão, uma piada.
- Uma **palavra principal**: uma metáfora compacta ou cunhagem que toda a peça pode sustentar (um termo que nomeia a ideia, da mesma forma que _balas traçadoras_ ou _névoa de guerra_ nomeiam um padrão completo).

Destes, a palavra principal é o fragmento mais valioso para pousar. É pesado: nomeie o caminho certo na exploração e ele moldará a estrutura, as transições e o título posteriormente, pagando dividendos durante toda a fase de exploração. Quando a conversa gira em torno de uma ideia recorrente, pressione para cunhar uma palavra para ela.

O diário do romancista é o modelo: anos de anotações não estruturadas que mais tarde são exploradas em busca de matéria-prima. Fragmentos são avisos.

## Formato do arquivo

```markdown
# Working title

A first fragment lives here.

It can be multiple paragraphs. It can include lists, code, quotes: whatever
shape the fragment naturally takes.

---

A second fragment.

---

> A quoted line that the user wants to keep around.

A reaction to it.

---

- A cluster of related observations
- That hang together by feel
- And want to be near each other
```

Os fragmentos são separados por uma régua horizontal (`\n---\n`). Sem títulos dentro do corpo. Sem tags. Nenhuma ordem além da ordem em que foram adicionadas.

## Ritmo de escrita

Anexe silenciosamente. Não peça permissão para cada fragmento. Mencione o que você adicionou de passagem ("adicionando isso"), mas não interrompa a conversa com caixas de diálogo para salvar.

Antes de cada gravação: releia o arquivo do disco. O usuário pode ter editado, reordenado ou excluído fragmentos entre turnos, portanto preserve suas alterações. Nunca sobrescreva o arquivo; apenas anexe (ou, se o usuário solicitar, edite um fragmento específico no local).

O usuário pode dizer "cortar o último", "reescrever aquele com mais nitidez", "mesclar os dois" a qualquer momento. Trate-as como instruções de primeira classe.

</supporting-info>