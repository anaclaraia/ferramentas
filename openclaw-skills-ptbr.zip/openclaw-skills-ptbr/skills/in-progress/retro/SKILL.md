---
name: retro
description: "Conduza uma retrospectiva de uma sessão de codificação."
disable-model-invocation: true
---

O usuário solicitou uma **retrospectiva**. Você está sugerindo melhorias no **ambiente** do agente de codificação para melhorar execuções futuras.

## Etapas

1. Ative a skill com `writing-for-agents` para obter o guia de estilo de escrita.

2. Leia as fontes primárias da sessão especificada pelo usuário. Isso pode significar pesquisar nos logs de sessão nesta máquina. Se o usuário não especificar uma sessão, o padrão será a atual.

3. Procure candidatos para melhoria nestas categorias.

- **Navegação**: quão fácil foi para o agente encontrar os arquivos certos? Existem dependências ocultas entre arquivos? Um **ponteiro de navegação** tornaria isso mais fácil? _Use quando_ a sessão demorou muito para encontrar uma informação.
- **Verificações automatizadas**: existem verificações automatizadas que podem detectar erros cometidos pelo agente? Linting, digitação, testes, linters de sistema de arquivos? Leia primeiro o comando de verificação do próprio repositório (seus scripts `package.json`/build-tool `lint`/`check`, seu fluxo de trabalho de CI), portanto, uma verificação que já existe, mas permanece desconectada ou silenciosamente quebrada, é a descoberta, não uma reinvenção. Um repositório sem **guardrail** (sem gancho de pré-confirmação e nenhum trabalho de CI executando seu comando lint/typecheck/test) é em si uma descoberta: um repositório sem linted é uma oportunidade perdida permanente, não um padrão neutro. _Use quando_ o agente cometeu um erro que uma verificação automatizada poderia ter detectado ou o repo não tem nenhuma proteção.
- **Padrões de codificação**: o **agente revisor** deve receber uma nova regra para aplicar? Uma regra existente deve ser removida ou esclarecida? Classifique a violação primeiro: uma violação **mecânica** (um padrão sintático fixo, uma API banida, uma forma de importação, uma regra de localização de arquivo) recebe uma verificação determinística, ponto final: uma regra personalizada no próprio linter do repositório, um novo gancho de pré-confirmação ou um novo trabalho de CI, qualquer que seja o idioma do repositório e a proteção existente que tornem mais barato. O padrão é construir o cheque em vez de escrever a regra. Reserve `CODING_STANDARDS.md` para **chamadas de julgamento** genuínas (consistência entre arquivos, "combina com o estilo circundante", qualquer coisa que nenhuma proteção possa substituir). _Use quando_ o agente revisor não conseguiu detectar um erro.
- **Global AGENTS.md**: há alguma instrução de orientação que deveria ser movida para padrões de codificação (ou verificações automatizadas)? _Use quando_ o arquivo AGENTS.md for particularmente grande - no repositório OU no escopo global do usuário.
- **Economia de ferramentas**: o agente fez chamadas de ferramentas caras que poderiam ser simplificadas? Existe alguma ferramenta personalizada (CLI, MCP) que seja particularmente ineficiente em termos de token? _Use quando_ o agente fez uma chamada de ferramenta cara.
- **No-ops**: procure instruções nos arquivos de direção que não modifiquem o comportamento do agente. _Use quando_ as limas de direção forem grandes e difíceis de manejar.
- **Acesso à informação**: procure oportunidades para aumentar o acesso do agente à informação. Logs do servidor de desenvolvimento, acesso somente leitura a serviços de terceiros. _Use quando_ uma informação crucial não estava disponível para o agente.

4. Apresente esses candidatos ao usuário, em ordem de gravidade.

## Referência

### Implementação vs Revisão

Lembre-se que todo trabalho passa por duas etapas: implementação e revisão. O agente de implementação tem a maior **pressão de contexto**. Eles são responsáveis ​​pela exploração, escrita de código e depuração de falhas.

O agente de revisão tem a menor pressão de contexto - ele recebe uma comparação, portanto não é necessária nenhuma exploração. Muitas vezes não é necessário escrever código ou depurar.

Isto significa que o agente revisor deve ser responsável pela imposição dos padrões de codificação, e não o agente de implementação.

### Arquivos

Você tem acesso a vários arquivos no repositório:

- `CLAUDE.md`/`AGENTS.md`: esses arquivos são enviados para a janela de contexto de qualquer agente trabalhando neste repo. Eles devem ser usados ​​com muita moderação, geralmente apenas para **ponteiros de navegação** para outros arquivos.
- `CODING_STANDARDS.md`: este arquivo é lido durante a revisão, não na implementação. Adicione **ponteiros de navegação** às pastas de documentos se o arquivo de padrões tiver mais de 1.000 linhas.
- Documentos: utilize documentos como arquivos de referência, apontados por outros arquivos. Procure os documentos existentes antes de escrever novos.
- Habilidades: use habilidades para documentos (já que sua descrição vai para a janela de contexto do agente) ou para comandos invocados pelo usuário. Siga os conselhos da habilidade `writing-for-agents`.