# Diversos

Ferramentas que mantenho por perto, mas raramente uso, não promovidas no plugin.

- **[git-guardrails-claude-code](./git-guardrails-claude-code/SKILL.md)**: Configure ganchos do Claude Code para bloquear comandos git perigosos (push, reset --hard, clean, etc.) antes de serem executados.
- **[migrate-to-shoehorn](./migrate-to-shoehorn/SKILL.md)**: migre arquivos de teste de asserções do tipo `as` para @total-typescript/shoehorn.
- **[scaffold-exercises](./scaffold-exercises/SKILL.md)**: Crie estruturas de diretórios de exercícios com seções, problemas, soluções e explicadores.
- **[setup-pre-commit](./setup-pre-commit/SKILL.md)**: Configure ganchos de pré-confirmação do Husky com lint-staged, Prettier, verificação de tipo e testes.