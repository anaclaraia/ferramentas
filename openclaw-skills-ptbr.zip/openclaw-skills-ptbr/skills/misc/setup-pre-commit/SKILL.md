---
name: setup-pre-commit
description: Configure ganchos de pré-confirmação do Husky com lint-staged (Prettier), verificação de tipo e testes no repositório atual. Use quando o usuário deseja adicionar ganchos de pré-confirmação, configurar o Husky, configurar o lint-staged ou adicionar formatação/verificação de tipo/teste no momento da confirmação.
---

# Configurar ganchos de pré-commit

## O que isso configura

- **Husky** gancho de pré-confirmação
- **lint-staged** executando o Prettier em todos os arquivos testados
- Configuração **mais bonita** (se estiver faltando)
- Scripts **typecheck** e **test** no gancho de pré-confirmação

## Etapas

### 1. Detectar gerenciador de pacotes

Verifique `package-lock.json` (npm), `pnpm-lock.yaml` (pnpm), `yarn.lock` (fio), `bun.lockb` (coque). Use o que estiver presente. O padrão é npm se não estiver claro.

### 2. Instale dependências

Instale como devDependencies:

```
husky lint-staged prettier
```

### 3. Inicialize o Husky

```bash
npx husky init
```

Isso cria o diretório `.husky/` e adiciona `prepare: "husky"` ao package.json.

### 4. Crie `.husky/pre-commit`

Escreva este arquivo (não é necessário nada para Husky v9 +):

```
npx lint-staged
npm run typecheck
npm run test
```

**Adaptar**: Substitua `npm` pelo gerenciador de pacotes detectado. Se o repositório não tiver nenhum script `typecheck` ou `test` em package.json, omita essas linhas e informe ao usuário.

### 5. Crie `.lintstagedrc`

```json
{
  "*": "prettier --ignore-unknown --write"
}
```

### 6. Crie `.prettierrc` (se estiver faltando)

Crie apenas se não existir nenhuma configuração mais bonita. Use estes padrões:

```json
{
  "useTabs": false,
  "tabWidth": 2,
  "printWidth": 80,
  "singleQuote": false,
  "trailingComma": "es5",
  "semi": true,
  "arrowParens": "always"
}
```

### 7. Verifique

- [] `.husky/pre-commit` existe e é executável
- [] `.lintstagedrc` existe
- [] O script `prepare` em package.json é `"husky"`
- [] A configuração `prettier` existe
- [] Execute `npx lint-staged` para verificar se funciona

### 8. Comprometa-se

Prepare todos os arquivos alterados/criados e confirme com a mensagem: `Add pre-commit hooks (husky + lint-staged + prettier)`

Isso será executado nos novos ganchos de pré-confirmação: um bom teste de fumaça para verificar se tudo funciona.

## Notas

- Husky v9 + não precisa de shebangs em arquivos de gancho
- `prettier --ignore-unknown` pula arquivos que o mais bonito não consegue analisar (imagens, etc.)
- O pré-commit executa primeiro o lint-staged (rápido, somente stage), depois a verificação completa e os testes