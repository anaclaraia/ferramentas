---
name: scaffold-exercises
description: Crie estruturas de diretório de exercícios com seções, problemas, soluções e explicadores que passam pelo linting. Use quando o usuário quiser criar exercícios, criar esboços de exercícios ou configurar uma nova seção do curso.
---

# Exercícios de andaime

Crie estruturas de diretório de exercícios que passem `pnpm ai-hero-cli internal lint` e, em seguida, confirme com `git commit`.

## Nomeação de diretório

- **Seções**: `XX-section-name/` dentro de `exercises/` (por exemplo, `01-retrieval-skill-building`)
- **Exercícios**: `XX.YY-exercise-name/` dentro de uma seção (por exemplo, `01.03-retrieval-with-bm25`)
- Número da seção = `XX`, número do exercício = `XX.YY`
- Os nomes são travessões (minúsculas, hífens)

## Variantes de exercícios

Cada exercício precisa de pelo menos uma destas subpastas:

- `problem/` - espaço de trabalho do aluno com TODOs
- `solution/` - implementação de referência
- `explainer/` - material conceitual, sem TODOs

Ao fazer stub, o padrão é `explainer/`, a menos que o plano especifique o contrário.

## Arquivos necessários

Cada subpasta (`problem/`, `solution/`, `explainer/`) precisa de um `readme.md` que:

- **não está vazio** (deve ter conteúdo real, até mesmo uma única linha de título funciona)
- Não possui links quebrados

Ao fazer stub, crie um leia-me mínimo com um título e uma descrição:

```md
# Exercise Title

Description here
```

Se a subpasta tiver código, ela também precisará de um `main.ts` (>1 linha). Mas para stubs, um exercício somente leia-me é adequado.

## Fluxo de trabalho

1. **Analisar o plano** - extrair nomes de seções, nomes de exercícios e tipos de variantes
2. **Crie diretórios** - `mkdir -p` para cada caminho
3. **Crie leia-mes de stub** - um `readme.md` por pasta de variante com um título
4. **Execute lint** - `pnpm ai-hero-cli internal lint` para validar
5. **Corrija quaisquer erros** - itere até que o lint passe

## Resumo das regras do Lint

O linter (`pnpm ai-hero-cli internal lint`) verifica:

- Cada exercício possui subpastas (`problem/`, `solution/`, `explainer/`)
- Existe pelo menos um dos `problem/`, `explainer/` ou `explainer.1/`
- `readme.md` existe e não está vazio na subpasta primária
- Nenhum arquivo `.gitkeep`
- Nenhum arquivo `speaker-notes.md`
- Sem links quebrados nos leia-mes
- Nenhum comando `pnpm run exercise` nos leia-mes
- `main.ts` necessário por subpasta, a menos que seja somente leia-me

## Exercícios de movimentação/renomeação

Ao renumerar ou mover exercícios:

1. Use `git mv` (não `mv`) para renomear diretórios - preserva o histórico do git
2. Atualize o prefixo numérico para manter a ordem
3. Execute novamente o lint após movimentos

Exemplo:

```bash
git mv exercises/01-retrieval/01.03-embeddings exercises/01-retrieval/01.04-embeddings
```

## Exemplo: stub de um plano

Dado um plano como:

```
Section 05: Memory Skill Building
- 05.01 Introduction to Memory
- 05.02 Short-term Memory (explainer + problem + solution)
- 05.03 Long-term Memory
```

Criar:

```bash
mkdir -p exercises/05-memory-skill-building/05.01-introduction-to-memory/explainer
mkdir -p exercises/05-memory-skill-building/05.02-short-term-memory/{explainer,problem,solution}
mkdir -p exercises/05-memory-skill-building/05.03-long-term-memory/explainer
```

Em seguida, crie stubs leia-me:

```
exercises/05-memory-skill-building/05.01-introduction-to-memory/explainer/readme.md -> "# Introduction to Memory"
exercises/05-memory-skill-building/05.02-short-term-memory/explainer/readme.md -> "# Short-term Memory"
exercises/05-memory-skill-building/05.02-short-term-memory/problem/readme.md -> "# Short-term Memory"
exercises/05-memory-skill-building/05.02-short-term-memory/solution/readme.md -> "# Short-term Memory"
exercises/05-memory-skill-building/05.03-long-term-memory/explainer/readme.md -> "# Long-term Memory"
```