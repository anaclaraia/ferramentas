---
name: migrate-to-shoehorn
description: Migrar arquivos de teste de asserções do tipo `as` para @total-typescript/shoehorn. Use quando o usuário menciona calçadeira, deseja substituir `as` em testes ou precisa de dados de teste parciais.
---

# Migrar para Calçadeira

## Por que calçadeira?

`shoehorn` permite passar dados parciais em testes enquanto mantém o TypeScript satisfeito. Ele substitui asserções `as` por alternativas de tipo seguro.

**Somente código de teste.** Nunca use calçadeira em código de produção.

Problemas com `as` em testes:

- Treinado para não usá-lo
- Deve especificar manualmente o tipo de destino
- Duplo como (`as unknown as Type`) para dados intencionalmente errados

## Instalar

```bash
npm i @total-typescript/shoehorn
```

## Padrões de migração

### Objetos grandes com poucas propriedades necessárias

Antes:

```ts
type Request = {
  body: { id: string };
  headers: Record<string, string>;
  cookies: Record<string, string>;
  // ...20 more properties
};

it("gets user by id", () => {
  // Only care about body.id but must fake entire Request
  getUser({
    body: { id: "123" },
    headers: {},
    cookies: {},
    // ...fake all 20 properties
  });
});
```

Depois:

```ts
import { fromPartial } from "@total-typescript/shoehorn";

it("gets user by id", () => {
  getUser(
    fromPartial({
      body: { id: "123" },
    }),
  );
});
```

### `as Type` → `fromPartial()`

Antes:

```ts
getUser({ body: { id: "123" } } as Request);
```

Depois:

```ts
import { fromPartial } from "@total-typescript/shoehorn";

getUser(fromPartial({ body: { id: "123" } }));
```

### `as unknown as Type` → `fromAny()`

Antes:

```ts
getUser({ body: { id: 123 } } as unknown as Request); // wrong type on purpose
```

Depois:

```ts
import { fromAny } from "@total-typescript/shoehorn";

getUser(fromAny({ body: { id: 123 } }));
```

## Quando usar cada

| Função | Caso de uso |
| --------------- | -------------------------------------------------- |
| `fromPartial()` | Passe dados parciais que ainda verificam o tipo |
| `fromAny()` | Passa dados intencionalmente errados (mantém preenchimento automático) |
| `fromExact()` | Forçar objeto completo (trocar com fromPartial mais tarde) |

## Fluxo de trabalho

1. **Reúna os requisitos** - pergunte ao usuário:
   - Quais arquivos de teste têm asserções `as` causando problemas?
   - Eles estão lidando com objetos grandes onde apenas algumas propriedades importam?
   - Eles precisam passar dados intencionalmente errados para testes de erros?

2. **Instalar e migrar**:
   - [] Instalar: `npm i @total-typescript/shoehorn`
   - [] Encontre arquivos de teste com asserções `as`: `grep -r " as [A-Z]" --include="*.test.ts" --include="*.spec.ts"`
   - [] Substitua `as Type` por `fromPartial()`
   - [] Substitua `as unknown as Type` por `fromAny()`
   - [] Adicionar importações de `@total-typescript/shoehorn`
   - [] Execute a verificação de tipo para verificar