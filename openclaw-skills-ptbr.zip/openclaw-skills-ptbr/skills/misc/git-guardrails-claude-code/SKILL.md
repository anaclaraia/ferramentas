---
name: git-guardrails-claude-code
description: Configure ganchos do Claude Code para bloquear comandos git perigosos (push, reset --hard, clean, branch -D, etc.) antes de serem executados. Use quando o usuário quiser evitar operações destrutivas do git, adicionar ganchos de segurança do git ou bloquear git push/reset no Claude Code.
---

# Configurar guarda-corpos do Git

Configura um gancho PreToolUse que intercepta e bloqueia comandos git perigosos antes que Claude os execute.

## O que é bloqueado

- `git push` (todas as variantes incluindo `--force`)
- `git reset --hard`
- `git clean -f` / `git clean -fd`
- `git branch -D`
-`git checkout .` / `git restore .`

Quando bloqueado, Claude vê uma mensagem informando que não tem autoridade para acessar esses comandos.

## Etapas

### 1. Pergunte ao escopo

Pergunte ao usuário: instalar **apenas este projeto** (`.claude/settings.json`) ou **todos os projetos** (`~/.claude/settings.json`)?

### 2. Copie o script do gancho

O script incluído está em: [scripts/block-dangerous-git.sh](scripts/block-dangerous-git.sh)

Copie-o para o local de destino com base no escopo:

- **Projeto**: `.claude/hooks/block-dangerous-git.sh`
- **Global**: `~/.claude/hooks/block-dangerous-git.sh`

Torne-o executável com `chmod +x`.

### 3. Adicionar gancho às configurações

Adicione ao arquivo de configurações apropriado:

**Projeto** (`.claude/settings.json`):

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "\"$CLAUDE_PROJECT_DIR\"/.claude/hooks/block-dangerous-git.sh"
          }
        ]
      }
    ]
  }
}
```

**Global** (`~/.claude/settings.json`):

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "~/.claude/hooks/block-dangerous-git.sh"
          }
        ]
      }
    ]
  }
}
```

Se o arquivo de configurações já existir, mescle o gancho na matriz `hooks.PreToolUse` existente. Não substitua outras configurações.

### 4. Pergunte sobre personalização

Pergunte se o usuário deseja adicionar ou remover algum padrão da lista de bloqueados. Edite o script copiado adequadamente.

### 5. Verifique

Faça um teste rápido:

```bash
echo '{"tool_input":{"command":"git push origin main"}}' | <path-to-script>
```

Deve sair com o código 2 e imprimir uma mensagem BLOQUEADA para stderr.